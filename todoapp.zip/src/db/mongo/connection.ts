import mongoose,{ConnectionOptions} from 'mongoose';
import app from '../../app';
class MongoConnection{
    private mongoUrl:string;
    private connectionOptions: ConnectionOptions = {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        useCreateIndex: true,
        useFindAndModify: true,
      };
    constructor(mongoUrl:string){
       this.mongoUrl=mongoUrl;
       mongoose.connection.on("error",this.onError);
       mongoose.connection.on('connected',this.onConnected);

    }
    public connect(){
        mongoose.connect(this.mongoUrl,this.connectionOptions);
       
    }
    private onError(){
        console.log("unable to connect to monogo db ");
    }
    private onConnected(){
        console.log("mongo db connected succesfully :)");
        app.emit('ready');
    }
}

export default MongoConnection