import express, { Request, Response } from 'express';
const app = express();
app.set('port',3000);
app.get("/",(req: Request,res: Response)=>{
res.send("Hello");
res.end();
});
app.on('ready',()=>{
    app.listen(app.get('port'),()=>{
        console.log('app started');
    });
});
export default app;


