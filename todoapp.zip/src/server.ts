import MongoConnection from './db/mongo/connection';

const url ='mongodb://localhost:27017/test';
const mongoconnection = new MongoConnection(url);
mongoconnection.connect();