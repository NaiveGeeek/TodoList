import React from "react";
import "./App.css";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Login from "./components/Login/Login";
import Signup from "./components/Signup/Signup";
import ForgotPassword from "./components/ForgotPassword/ForgotPassword";
import Home from "./components/Home/Home";
import { Provider } from "react-redux";
import store from "./Store/index";
import ModalContainer from "./Container/ModalContainer";

function App() {
  return (
    <Provider store={store}>
      <Router>
        <Switch>
          <Route exact path="/login" component={Login}></Route>
          <Route exact path="/signup" component={Signup}></Route>
          <Route
            exact
            path="/forgot_password"
            component={ForgotPassword}
          ></Route>
          <Route path="/" component={Home}></Route>
        </Switch>
      </Router>
      <ModalContainer></ModalContainer>
    </Provider>
  );
}

export default App;
