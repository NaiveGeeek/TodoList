import React, { Component} from 'react'
import CandidateSidebar from './CandidateSidebar'
import CandidateOverview from './CandidateOverview'

 class Candidates extends Component {
    render() {
        return (
            <div className="page">
                <div className="clearfix equal-height-content">
               <CandidateSidebar></CandidateSidebar>
               <CandidateOverview></CandidateOverview>
           </div>
           </div>
        )
    }
}

export default Candidates