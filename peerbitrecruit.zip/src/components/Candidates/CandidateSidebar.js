import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import { FaUser } from "react-icons/fa"
import "./CandidateSideBar.css"
import { Dropdown } from 'react-bootstrap'

class CandidateSidebar extends Component {
    render() {
        return (
            <div className="sidebar sidebar-colored">
                <aside className="sidebar-item list-sidebar-create">
                    <Link to="/add_candidate" className="btn btn-default btn-create btn-with-icon">
                        <FaUser style={{ marginRight: "6px", opacity: "0.4" }}></FaUser> Add Candidate
            </Link>
                </aside>
                <aside className="sidebar-item">
                    <h3 className="sidebar-item-header">OPENINGS</h3>
                    <ul className="sidebar-list sidebar-nav list-unstyled">
                        <li className="li-selected">
                            <Link to="candidates.php">
                                <div className="sidebar-filter-label">Overview</div>
                                <div className="sidebar-filter-count">2</div>
                            </Link>
                        </li>
                        <li>
                            <Link to="#">
                                <div className="sidebar-filter-label">Assigned to me</div>
                                <div className="sidebar-filter-count">0</div>
                            </Link>
                        </li>
                        <li>
                            <Link to="#">
                                <div className="sidebar-filter-label">Android</div>
                                <div className="sidebar-filter-count">0</div>
                            </Link>
                        </li>
                        <li>
                            <Link to="#">
                                <div className="sidebar-filter-label">Android Developer</div>
                                <div className="sidebar-filter-count">0</div>
                            </Link>
                        </li>
                        <li>
                            <Link to="#">
                                <div className="sidebar-filter-label">Not in any opening</div>
                                <div className="sidebar-filter-count">0</div>
                            </Link>
                        </li>
                    </ul>
                </aside>
                <aside className="sidebar-item">
                    <h3 className="sidebar-item-header">QUICK LINKS</h3>
                    <ul className="sidebar-list sidebar-nav list-unstyled">
                        <li>
                            <Link to="#">
                                <div className="sidebar-filter-label">My upcoming interviews</div>
                                <div className="sidebar-filter-count">0</div>
                            </Link>
                        </li>
                        <li>
                            <Link to="#">
                                <div className="sidebar-filter-label">Evaluations pending on me</div>
                                <div className="sidebar-filter-count">0</div>
                            </Link>
                        </li>
                        <li>
                            <Link to="#">
                                <div className="sidebar-filter-label">Reviews pending on me</div>
                                <div className="sidebar-filter-count">0</div>
                            </Link>
                        </li>
                        <li>
                            <Link to="#">
                                <div className="sidebar-filter-label">Todos pending on me</div>
                                <div className="sidebar-filter-count">0</div>
                            </Link>
                        </li>
                        <li>
                            <Link to="#">
                                <div className="sidebar-filter-label">Notes awaiting my reply</div>
                                <div className="sidebar-filter-count">0</div>
                            </Link>
                        </li>
                        <li>
                            <Link to="#">
                                <div className="sidebar-filter-label">Unread candidates</div>
                                <div className="sidebar-filter-count">0</div>
                            </Link>
                        </li>
                    </ul>
                </aside>
                <aside className="sidebar-item">
                    <h3 className="sidebar-item-header">OTHERS</h3>
                    <ul className="sidebar-list sidebar-nav list-unstyled">
                        <li><Link to="#">Starred</Link></li>
                        <li><Link to="#">Added by me</Link></li>
                        <li>
                            <Dropdown>
                                <Dropdown.Toggle id="dropdown-basic" >
                                    Filter by labels
                                    </Dropdown.Toggle>
                                <Dropdown.Menu className="dropdown-menu" >
                                <Link to="#">Manage labels</Link>
                                </Dropdown.Menu>
                            </Dropdown>
                        </li>
                        <li>
                            <Dropdown>
                                <Dropdown.Toggle variant="success" id="dropdown-basic">
                                    Filtered by stage
                                    </Dropdown.Toggle>
                                <Dropdown.Menu className="dropdown-menu">
                                <Link to="#" style={{position:"relative"}}>
                                        <div className="sidebar-filter-label">Telephone Interview</div>
                                        <div className="sidebar-filter-count">2</div>
                                    </Link>
                                    <Link to="#" style={{position:"relative"}}>
                                        <div className="sidebar-filter-label">Make Offer</div>
                                        <div className="sidebar-filter-count">1</div>
                                    </Link>
                                </Dropdown.Menu>
                            </Dropdown>
                        </li>
                        <li>
                            <Dropdown>
                                <Dropdown.Toggle variant="success" id="dropdown-basic">
                                  Decisioned
                                    </Dropdown.Toggle>
                                <Dropdown.Menu className="dropdown-menu">
                                <Link to="#">Hired</Link>
                                <Link to="#">Rejected</Link>
                                <Link to="#">On Hold</Link>
                                <Link to="#">Withdrawn</Link>
                                <Link to="#">Declined Offer</Link>
                                <hr style={{margin:0}}></hr>
                                <Link to="#">Archived</Link>
                                <hr style={{margin:0}}></hr>
                                <Link to="#" >Spam</Link>
                                </Dropdown.Menu>
                            </Dropdown>
                        </li>
                       
                        <li><Link to="#">All accessible</Link></li>
                    </ul>
                </aside>
            </div>
        )
    }
}

export default CandidateSidebar
