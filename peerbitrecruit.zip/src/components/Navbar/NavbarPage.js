import React, { Component, Fragment } from 'react'
import logo from '../../assets/logo.png'
import { Navbar, Nav } from 'react-bootstrap'
import "./NavbarPage.css";
import { NavLink, Link } from 'react-router-dom';
class NavbarPage extends Component {
  render() {
    return (
      <Fragment>
        <div className="background-navbar" style={{ overflow: "auto" }} >
          <div className="top-nav-bar">
            <div className="pull-left">
              <span style={{marginRight:"10px",display:"inline-block"}}>
                <strong>Nasrullahpatel</strong>
                <span>/</span>
                <span>Nasrullah</span>
              </span>
            </div>
            <div className="pull-right">
              <ul className="sysnav nav nav-pills pull-right navbar-elements">
                <li><Link to="#">Reports</Link></li>
                <li><Link to="#">Settings</Link></li>
                <li><Link to="#">Logout</Link></li>
              </ul>
            </div>
          </div>
        </div>
        <Navbar expand="lg" className="background-navbar" variant="dark">
          <Navbar.Brand className="brand-logo" to="#home">
            <img
              alt="company-logo"
              src={logo}
              className="d-inline-block align-top"
            />
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav" style={{ position: "relative" }}>
            <Nav>
              <Nav.Item className="nav-items">
                <NavLink activeClassName="nav-links-active" exact className="nav-links-style" to="/">Dashboard</NavLink>
              </Nav.Item>
              <Nav.Item className="nav-items">
                <NavLink activeClassName="nav-links-active" className="nav-links-style" to="/openings">Openings</NavLink>
              </Nav.Item>
              <Nav.Item className="nav-items">
                <NavLink activeClassName="nav-links-active" className="nav-links-style" to="/candidates" >
                  Candidates
           </NavLink>
              </Nav.Item>
              <Nav.Item className="nav-items">
                <NavLink activeClassName="nav-links-active" className="nav-links-style" to="/calender" >
                  Calender
           </NavLink>
              </Nav.Item>
            </Nav>

          </Navbar.Collapse>

        </Navbar>

      </Fragment>
    )
  }
}

export default NavbarPage 