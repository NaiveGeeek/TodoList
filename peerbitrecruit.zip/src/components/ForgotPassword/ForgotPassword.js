import React, { Component } from 'react'
import { Image, Container, Form, Button } from 'react-bootstrap'
import logo from '../../assets/logo.png'
import './ForgotPassword.css';
import { Link, Redirect } from 'react-router-dom';
import { isUserAuthorized } from '../../utils/commonFuntions';
 class ForgotPassword extends Component {
    constructor(props){
        super(props);
        this.state={
            email:''
        }
        }
        handleChange =(event)=>{
         const target = event.target;
         this.setState({[target.name] : target.value});
        }
    render() {
        if(isUserAuthorized()){
            return <Redirect to="/"></Redirect>
         }
        return (
            <div className="forgotPasswordContainer">
                <div className="forgotPasswordHeader">
                    <Image src={logo} alt="company logo"></Image>
                    <h1 className="forgotPasswordHeaderText">Having problem with login?</h1>
                </div>
                <Container className="formContainer">
                    <Form>
                        <p className="cannot-login-form-desc">Enter the email address you used to sign up, and we will send you instructions to login into your account.</p>
                        <Form.Group controlId="emailId">
                            <Form.Control name ="email" type="email" placeholder="Email" value={this.state.email} onChange={this.handleChange}/>
                        </Form.Group>
                        <Button variant="primary" type="submit" block>
                            Submit
                        </Button>
                    </Form>
                    <div className="backtoLogin">
                        <Link to ="/login"> Back to login?</Link>
                    </div>
                </Container>
                <p className="content-box-outer">Write to us at  <Link to="mailto:support@peerrecruiter.com">support@peerrecruiter.com</Link> if you have trouble.</p>

                
            </div>
        )
    }
}

export default ForgotPassword