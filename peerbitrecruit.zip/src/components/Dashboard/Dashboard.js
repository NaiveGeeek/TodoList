import React, { Component } from "react";
import { Container, Row, Col } from "react-bootstrap";
import "./Dashboard.css";
// import assignedChart from "../../assets/assigned-chart.jpg"
import ActionIcon from "../../reusableComponent/Action Icons/ActionIcon";
import ActionLink from "../../reusableComponent/ActionLinks/ActionLinks";
import { BarChart, CartesianGrid, XAxis, YAxis, Bar } from "recharts";
import { connect } from "react-redux";
import { getDashboardData } from "../../actions/dashboardAction";
class Dashboard extends Component {
  componentDidMount() {
    this.props.dispatch(getDashboardData());
  }
  render() {
    return (
      <Container className="main-container">
        <Row className="salient-actions">
          <Col xs={12} sm={6} md={3}>
            <ActionIcon
              className="iconlarge-pin"
              label="Create New Opening"
            ></ActionIcon>
          </Col>
          <Col xs={12} sm={6} md={3}>
            <ActionIcon
              className="iconlarge-candidate"
              label="Add Candidates"
            ></ActionIcon>
          </Col>
          <Col xs={12} sm={6} md={3}>
            <ActionIcon
              className="iconlarge-chart"
              label="Analyze Report"
            ></ActionIcon>
          </Col>
          <Col xs={12} sm={6} md={3}>
            <ActionIcon
              className="iconlarge-wrench"
              label="Manage Settings"
            ></ActionIcon>
          </Col>
        </Row>

        <section className="dashboard-section">
          <h3>Things assigned to you</h3>
          <div className="dashboard-list-group dashboard-subsection">
            <Row>
              <Col xs={6} sm={2}>
                <ActionLink className="special-link">
                  <div className="salient-metric-number">
                    {this.props.dashboardData.assignedInterview.length}
                  </div>
                  <div className="salient-metric-label">
                    Candidates in stages <br></br>assigned to you
                  </div>
                </ActionLink>
              </Col>
              <Col xs={6} sm={10}>
                <div className="assigned-chart">
                  <BarChart
                    width={630}
                    height={230}
                    data={[
                      {
                        name: "TelePhone Inteview",
                        interview: this.props.dashboardData.assignedInterview
                          .length
                      }
                    ]}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis domain={[0, 4]} />
                    <Bar dataKey="interview" fill="#8884d8" />
                  </BarChart>
                  {/* <Image src={assignedChart} alt="Assigned Chart"></Image> */}
                </div>
              </Col>
            </Row>
          </div>
          <div className="dashboard-list-group dashboard-subsection">
            <Row>
              <Col xs={6} sm={2}>
                <ActionLink className="special-link">
                  <div className="salient-metric-number">
                    {this.props.dashboardData.todo.length}
                  </div>
                  <div className="salient-metric-label">
                    To-dos <br></br>assigned to you
                  </div>
                </ActionLink>
              </Col>
              <Col xs={6} sm={10}></Col>
            </Row>
          </div>
        </section>
        <section className="dashboard-section">
          <h3>Things to follow up</h3>
          <div className="dashboard-list-group dashboard-subsection">
            <Row>
              <Col xs={6} sm={2}>
                <ActionLink>
                  <div className="salient-metric-number">Yay!</div>
                  <div className="salient-metric-label">
                    No unread <br></br>Candidates<br></br> in your inbox
                  </div>
                </ActionLink>
              </Col>
              <Col xs={6} sm={2}>
                <ActionLink>
                  <div className="salient-metric-number">2</div>
                  <div className="salient-metric-label">
                    Starred <br></br>Candidates
                  </div>
                </ActionLink>
              </Col>
              <Col xs={6} sm={2}>
                <ActionLink>
                  <div className="salient-metric-number">Yay!</div>
                  <div className="salient-metric-label">
                    No pendings To-dos <br></br>to follow up
                  </div>
                </ActionLink>
              </Col>
            </Row>
          </div>
        </section>
      </Container>
    );
  }
}
const mapStoreToProps = state => {
  const { dashboardStore: dashboardData } = state;
  return { dashboardData };
};
export default connect(mapStoreToProps)(Dashboard);
