import React, { Component, Fragment } from 'react'
import { Switch, Route } from 'react-router-dom'
import Openings from '../Openings/Openings'
import Candidates from '../Candidates/Candidates'
import Calender from '../Calender/Calender'
import Dashboard from '../Dashboard/Dashboard'
import AddCandidate from '../AddCandidate/AddCandidate'
import SingleCandidatePage from '../SingleCandidatePage/SingleCandidatePage'
import SingleOpeningPage from '../SingleOpeningPage/SingleOpeningPage'
import EditOpening from '../EditOpening/EditOpening'
// import OpeningFirstStep from '../AddOpening/OpeningFirstStep'
import AddOpening from '../AddOpening/AddOpening'
// import OpeningSecondStep from '../AddOpening/OpeningSecondStep'
// import OpeningThirdStage from '../AddOpening/OpeningThirdStage'
// import OpeningLastStage from '../AddOpening/OpeningLastStage'

class Routing extends Component {
    render() {
        return (
            <Fragment>
                   <Switch>
                    <Route exact path="/" component={Dashboard}></Route>
                    <Route  path="/openings" component = {Openings}></Route>
                    <Route  path="/candidates" component ={Candidates}></Route>
                    <Route  path="/calender" component ={Calender}></Route>
                    <Route  path="/add_candidate" component={AddCandidate}></Route>
                    <Route  path="/single_page_view_candidate" component={SingleCandidatePage}></Route>
                    <Route  path="/single_page_opening_view" component ={SingleOpeningPage}></Route>
                    <Route  path="/edit_opening" component={EditOpening}></Route>
                    <Route  path ="/add_opening" component={AddOpening}></Route>
                    {/* <Route  path ="/openings_details" component={OpeningSecondStep}></Route>
                    <Route  path ="/openings_stages" component={OpeningThirdStage}></Route>
                    <Route  path ="/opening_creation_success" component={OpeningLastStage}></Route> */}
                </Switch>
            </Fragment>
        )
    }
}
export default Routing
