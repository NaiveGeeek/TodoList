import React, { Component } from 'react'
import './AllOpenings.css'
import { Link } from 'react-router-dom';
import { OverlayTrigger, Tooltip } from 'react-bootstrap';
import { IoIosWarning } from 'react-icons/io';
import { connect } from 'react-redux';
import { mapStateToProps, openingStateToProps } from '../../constant/mapStateToProps';
import { mapDispatchToProps, asyncApiCallDispatchToProps } from '../../constant/mapDispatchToProps';
import { HTTP_METHOD } from '../../constant/httpMethods';
import { openingAll } from '../../actions/openingAction';
class AllOpenings extends Component {
   
        
    getDivElements = () => {
        const elements = this.props.openingState.allOpenigs.map((data, index) => {
            return (
                <div key={data.id} className="dashboard-row">
                    <div className="row">
                        <div className="dashboard-col dashboard-title-col col-sm-4">
                            <h2 className="dashboard-row-title">
                                {data.isDataIncomplete ? <span className="incomplete-warnings">
                                    <OverlayTrigger
                                        placement="top"
                                        overlay={
                                            <Tooltip id={`tooltip-${"top"}+${index}`} style={{ fontSize: "10px" }}>
                                                This opening has incomplete details.
                                              </Tooltip>
                                        }
                                    ><IoIosWarning></IoIosWarning></OverlayTrigger></span> : null}
                                <Link to="/single_page_opening_view">{data.title}</Link>
                            </h2>
                            <div className="dashboard-desc opening-desc">
                                <span className="text-mute">Location:</span>{data.location}
                            </div>
                        </div>
                        <div className="dashboard-col dashboard-desc-col col-sm-6">
                            <div className="dashboard-desc opening-assigned-users">
                                <span className="text-mute">Assigned Users:</span><br></br>{data.assignedUser}
                            </div>
                        </div>
                        <div className="dashboard-col dashboard-candidates-col col-sm-2">
                            <Link to="#" className="link-pill">{data.candidates} candidates</Link>
                        </div>
                    </div>
                </div>
            )
        });

        return elements;

    }
    componentDidMount(){
        this.props.apiCall("http://www.mocky.io/v2/5e3d07432d00002800d95a3b",HTTP_METHOD.GET,{},{},openingAll);
    }
    render() {
        return (
            <div className="main-col list-page">
                <div className="list-page-without-actions">
                    <section className="dashboard-section">
                        <div className="clearfix">
                            <h1 className="list-section-heading pull-left">All Accessible Openings</h1>
                            <div className="pagination pagination-simple pull-right js-results-count">15 results</div>
                        </div>
                        <div className="dashboard-list">
                            {this.getDivElements()}
                        </div>
                    </section>
                </div>
            </div>
        )
    }
}

export default connect(mapStateToProps([openingStateToProps]),mapDispatchToProps([asyncApiCallDispatchToProps]))(AllOpenings)