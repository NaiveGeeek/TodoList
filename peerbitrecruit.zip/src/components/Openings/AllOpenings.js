import React, { Component } from 'react'
import './AllOpenings.css'
import { Link } from 'react-router-dom';
import { OverlayTrigger, Tooltip } from 'react-bootstrap';
import { IoIosWarning } from 'react-icons/io';
class AllOpenings extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [{
                id: 1,
                title: "Abdulhanan Shaikh",
                assignedUser: "Nasrullah",
                location: "Ahemdabad, India",
                candidates: 0,
                isDataIncomplete: false,
            }, {
                id: 2,
                title: "Android",
                assignedUser: "Nasrullah",
                location: "Ahemdabad, India",
                candidates: 0,
                isDataIncomplete: false,
            }, {
                id: 3,
                title: "Android",
                assignedUser: "Nasrullah",
                location: "Ahemdabad, India",
                candidates: 0,
                isDataIncomplete: true,
            }, {
                id: 4,
                title: "Android",
                assignedUser: "Nasrullah",
                location: "Ahemdabad, India",
                candidates: 0,
                isDataIncomplete: false,
            }, {
                id: 5,
                title: "Android",
                assignedUser: "Nasrullah",
                location: "Ahemdabad, India",
                candidates: 0,
                isDataIncomplete: false,
            }, {
                id: 6,
                title: "Android",
                assignedUser: "Nasrullah",
                location: "Ahemdabad, India",
                candidates: 0,
                isDataIncomplete: true,
            }]
        }
    }
    getDivElements = () => {
        const elements = this.state.data.map((data, index) => {
            return (
                <div key={data.id} className="dashboard-row">
                    <div className="row">
                        <div className="dashboard-col dashboard-title-col col-sm-4">
                            <h2 className="dashboard-row-title">
                                {data.isDataIncomplete ? <span className="incomplete-warnings">
                                    <OverlayTrigger
                                        placement="top"
                                        overlay={
                                            <Tooltip id={`tooltip-${"top"}+${index}`} style={{ fontSize: "10px" }}>
                                                This opening has incomplete details.
                                              </Tooltip>
                                        }
                                    ><IoIosWarning></IoIosWarning></OverlayTrigger></span> : null}
                                <Link to="/single_page_opening_view">{data.title}</Link>
                            </h2>
                            <div className="dashboard-desc opening-desc">
                                <span className="text-mute">Location:</span>{data.location}
                            </div>
                        </div>
                        <div className="dashboard-col dashboard-desc-col col-sm-6">
                            <div className="dashboard-desc opening-assigned-users">
                                <span className="text-mute">Assigned Users:</span><br></br>{data.assignedUser}
                            </div>
                        </div>
                        <div className="dashboard-col dashboard-candidates-col col-sm-2">
                            <Link to="#" className="link-pill">{data.candidates} candidates</Link>
                        </div>
                    </div>
                </div>
            )
        });

        return elements;

    }
    render() {
        return (
            <div className="main-col list-page">
                <div className="list-page-without-actions">
                    <section className="dashboard-section">
                        <div className="clearfix">
                            <h1 className="list-section-heading pull-left">All Accessible Openings</h1>
                            <div className="pagination pagination-simple pull-right js-results-count">15 results</div>
                        </div>
                        <div className="dashboard-list">
                            {this.getDivElements()}
                        </div>
                    </section>
                </div>
            </div>
        )
    }
}

export default AllOpenings