import React, { Component } from 'react'
import "./Private.css"

class Private extends Component {
    render() {
        return (
            <div className="main-col list-page">
                <div className="list-page-without-actions">
                    <section className="dashboard-section">
                        <div className="clearfix">
                            <h1 className="list-section-heading pull-left">Private</h1>
                        </div>
                        <div className="dashboard-list">
                         <p className="text-mute">There are no private openings.</p>
                        </div>
                    </section>
                </div>
            </div>
        )
    }
}

export default Private;