import React, { Component } from 'react'
import "./Openings.css"
import OpeningsRoute from "./OpeningsRoute";
import OpeningSideBar from './OpeningSideBar';
class Openings extends Component {
    render() {
        return (
            <div className="page">
                <div className="clearfix equal-height-content">
                <OpeningSideBar></OpeningSideBar>
                {/* insert routing here*/}
                <OpeningsRoute></OpeningsRoute>
                </div>
            </div>

        )
    }
}

export default Openings