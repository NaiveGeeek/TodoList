import React, { Component } from 'react'
import { Switch, Route } from 'react-router-dom'
import Overview from './Overview'
import AssignedToMe from './AssignedToMe'
import AllOpenings from './AllOpenings'
import Archived from './Archived'
import Private from './Private'


class OpeningsRoute extends Component {
    render() {
        return (
           <Switch>
               <Route exact path="/openings" component={Overview}></Route>
               <Route path="/openings/assigned_to_me" component={AssignedToMe}></Route>
               <Route path="/openings/all_openings" component={AllOpenings}></Route>
               <Route path="/openings/drafts"></Route>
               <Route path="/openings/published"></Route>
               <Route path="/openings/used_internally"></Route>
               <Route path="/openings/not_accepting_candidates"></Route>
               <Route path="/openings/archived" component={Archived}></Route>
               <Route path="/openings/private" component={Private}></Route> 
           </Switch>
        )
    }
}
export default OpeningsRoute