import React, { Component } from 'react'
import "./login.css";
import { Image, Container, Form, Button } from 'react-bootstrap';
import logo from '../../assets/logo.png';
import { Link } from 'react-router-dom';

class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            email: '',
            password: '',
            keepmeLoggedin: false,
        }
    }
    handleChange = (event) => {
        const target = event.target;
        if (target.type === "checkbox") {
            this.setState({[target.name]: target.checked });
        }
        else {
            this.setState({[target.name]: target.value });
        }

    }

    render() {
        return (
            <div className="loginContainer">
                <div className="loginHeader">
                    <Image src={logo} alt="company logo"></Image>
                    <h1 className="loginHeaderText">Log in to your PeerRecruiter account</h1>
                </div>
                <Container className="formContainer">
                    <Form>
                        <Form.Group controlId="emailId">
                            <Form.Control name="email" type="email" placeholder="Email" value={this.state.email} onChange={this.handleChange} />
                        </Form.Group>
                        <Form.Group controlId="password">
                            <Form.Control type="password" name="password" placeholder="Password" value={this.state.password} onChange={this.handleChange} />
                        </Form.Group>
                        <Form.Group controlId="checkbox">
                            <Form.Check type="checkbox" name="keepmeLoggedin" label="Keep me logged in" checked={this.state.keepmeLoggedin} onChange={this.handleChange} />
                        </Form.Group>
                        <Button  as={Link} to="/" variant="primary" type="submit" block>
                            Log in
                        </Button>
                    </Form>
                    <div className="cannotLogin">
                        <Link to="/forgot_password"> can not login?</Link>
                    </div>
                </Container>
                <Button className="signupBtn">
                    <Link to="/signup" className="signupLink">Don't have an account?  Sign up </Link>

                </Button>
            </div>
        )
    }

}

export default Login