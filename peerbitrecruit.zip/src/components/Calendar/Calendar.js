import React, { Component } from "react";
import { Calendar, momentLocalizer, Views } from "react-big-calendar";
import moment from "moment";
import { connect } from "react-redux";
import { mapStateToProps, calandarStateToProps } from "../../constant/mapStateToProps";
import { mapDispatchToProps, showHideModalDispatchToProps ,calandarDispatchToProps} from "../../constant/mapDispatchToProps";
import { CREATE_EVENT_MODAL } from "../../constant/modaltypes";
import { generateRandomId } from "../../utils/commonFuntions";

class Calender extends Component {
  constructor(props) {
    super(props);
    this.state = {
      calendarEvents: []
    };
  }
  handleSelect = ({ start, end }) => {
    const title = window.prompt('New Event name');
    const id= this.state.calendarEvents.length+1;
    if (title)
      this.setState({
        calendarEvents: [
          ...this.state.calendarEvents,
          {
            start,
            end,
            title,
            id
          },
        ],
      })
  }
  closeModal = () => {
   this.props.nodisplayModal();
  };
  openModal =({ start, end }) => {
    let modalObject = {
      modalType: CREATE_EVENT_MODAL,
      modalProps: {
        open: true,
        closeModal: this.closeModal,
        start,
        end,
        id:generateRandomId(),
        addEvents:this.props.addEvents
      }
    };
    this.props.displayModal(modalObject);
  };
  render() {
    const localizer = momentLocalizer(moment);
    const {calandarState}=this.props;
    return (
      <div className="main-col list-page">
        <Calendar
          localizer={localizer}
          selectable
          events={calandarState.calandarEvents}
          defaultView={Views.WEEK}
          defaultDate={new Date()}
          style={{height:"500px"}}
          onSelectSlot={this.openModal}
        ></Calendar>
      </div>
    );
  }
}

export default connect(mapStateToProps([calandarStateToProps]),mapDispatchToProps([showHideModalDispatchToProps,calandarDispatchToProps])) (Calender);
