import React, { Component } from "react";
import { Modal, Form, Row, Col } from "react-bootstrap";
import { FaRegClock } from "react-icons/fa";
import { formatTimeToAMPM } from "../../utils/commonFuntions";

class CreateEventModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      title: "",
      description:""
    };
  }
  handleChange = event => {
    const target = event.target;
    this.setState({
      [target.name]: target.value
    });
  };
  handleSubmit =(event,{id,start,end,addEvents,closeModal})=>{
  event.preventDefault();
  let newEventObject = {id,start,end,
    title:this.state.title,
    description:this.state.description
  }
  addEvents(newEventObject);
  closeModal();
  }
  render() {
    const { modalProps } = this.props;
    const startDate =
      modalProps.start.toDateString() +
      " " +
      formatTimeToAMPM(modalProps.start);
    const endDate =
      modalProps.end.toDateString() + " " + formatTimeToAMPM(modalProps.end);
    return (
      <Modal show={modalProps.open}  centered onHide={()=>modalProps.closeModal()}>
        <Modal.Body style={{ padding: 0 }}>
          <Form>
            <Form.Group className="padding-1rem" style={{ marginTop: "1rem" }}>
              <Form.Control
                name="title"
                type="text"
                placeholder="Title"
                value={this.state.title}  
                onChange={this.handleChange}
              ></Form.Control>
            </Form.Group>
            <Row className="padding-1rem">
              <Col xs={2}>
                <FaRegClock></FaRegClock>
              </Col>
              <Col xs={10}>{startDate + " - " + endDate}</Col>
            </Row>
            <Form.Group className="padding-1rem"style={{ marginTop: "1rem" }}>
              <Form.Control as={"textarea"} rows={3} name="description" placeholder="Description..."
                value={this.state.description}  
                onChange={this.handleChange}></Form.Control>
            </Form.Group>
            <div className="stage-edit-form-buttons clearfix">
              <button
                type="submit"
                className="btn btn-primary pull-right save-btn"
                onClick ={(event)=>{this.handleSubmit(event,modalProps)}}
              >
                Save
              </button>
              <button
                type="button"
                className="btn btn-default pull-right hide-non-interview-button"
                style={{ marginRight: "10px" }}
                onClick={() => {
                  modalProps.closeModal();
                }}
              >
                Cancel
              </button>
            </div>
          </Form>
        </Modal.Body>
      </Modal>
    );
  }
}

export default (CreateEventModal);
