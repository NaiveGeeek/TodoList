import React, { Component } from 'react'
import { Link } from 'react-router-dom'

class SinglePageCandidateMain extends Component {
    render() {
        return (
            <div className="main-col">
            <div className="page-title-block-bleeding-left clearfix">
                <h1 className="page-title">Second Candidate</h1>
            </div>
            <section className="dashboard-section dashboard-list-group-wrapper">
                <div className="section-heading">
                    <Link to="#" className="pull-right">Edit</Link> 
                    <h2 className="heading">Profile</h2>
                </div>
                <div className="dashboard-list-group">
                    <table className="table">
                        <colgroup>
                            <col width="25%"></col>
                            <col width="75%"/>
                        </colgroup>
                        <tbody>
                            <tr>
                                <td className="text-muted">First Name</td>
                                <td>Abdulhannan</td>
                            </tr>
                            <tr>
                                <td className="text-muted">Last Name</td>
                                <td>Shaikh</td>
                            </tr>
                            <tr>
                                <td className="text-muted">Email</td>
                                <td>second@yahoo.com</td>
                            </tr>
                            <tr>
                                <td className="text-muted">Phone</td>
                                <td>90099898988</td>
                            </tr>
                            <tr>
                                <td className="text-muted">Date of Birth</td>
                                <td>19/11/1992</td>
                            </tr>
                            <tr>
                                <td className="text-muted">Gender</td>
                                <td>Male</td>
                            </tr>
                            <tr>
                                <td className="text-muted">Status</td>
                                <td><i className="glyphicon glyphicon-ok text-success"></i> Active</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>
            <section className="dashboard-section dashboard-list-group-wrapper">
                <div className="section-heading">
                    <Link to="#" className="pull-right">Edit</Link>                                                         
                    <h2 className="heading">Candidate Details</h2>
                </div>
                <div className="dashboard-list-group">
                    <table className="table">
                        <colgroup>
                            <col width="25%"/>
                            <col width="75%"/>
                        </colgroup>
                        <tbody>
                            <tr>
                                <td className="text-muted">Joining Date</td>
                                <td>19/11/1992</td>
                            </tr>
                            <tr>
                                <td className="text-muted">Location</td>
                                <td>Ahmedabad, Gujarat, India</td>
                            </tr>
                            <tr>
                                <td className="text-muted">Total Experience</td>
                                <td>1 Year 4 Months</td>
                            </tr>
                            <tr>
                                <td className="text-muted">Relevant Experience</td>
                                <td>2 Years 1 Month</td>
                            </tr>
                            <tr>
                                <td className="text-muted">Current CTC</td>
                                <td>Rs. 1,40,000</td>
                            </tr>
                            <tr>
                                <td className="text-muted">Job</td>
                                <td>iOS Developer</td>
                            </tr>
                            <tr>
                                <td className="text-muted">Source</td>
                                <td>Indeed</td>
                            </tr>
                            <tr>
                                <td className="text-muted">Description</td>
                                <td>-</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>
            <section className="dashboard-section dashboard-list-group-wrapper">
                <div className="section-heading">
                    <Link to="#" className="pull-right">+ Add Resume</Link>                                                         
                    <h2 className="heading">Resume</h2>
                </div>
                <div className="dashboard-list-group">
                    <div className="dashboard-section-empty text-muted">
                        There is no resume for this candidate.
                    </div>
                </div>
            </section>
            <section className="dashboard-section dashboard-list-group-wrapper">
                <div className="section-heading">
                    <Link to="#" className="pull-right">+ Add Document</Link>                                                         
                    <h2 className="heading">Document</h2>
                </div>
                <div className="dashboard-list-group">
                    <div className="dashboard-section-empty text-muted">
                        There is no document for this candidate.
                    </div>
                </div>
            </section>
        </div>
        )
    }
}
export default SinglePageCandidateMain