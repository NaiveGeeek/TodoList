import React, { Component } from "react";
import "./SingleCandidatePage.css";
import { Link } from "react-router-dom";
import SinglePageCandidateMain from "./SinglePageCandidateMain";
import { Collapse, Dropdown, Button, ButtonGroup } from "react-bootstrap";
import { MdArrowBack, MdArrowForward, MdDateRange } from "react-icons/md";
import { FaListAlt, FaUser, FaMobileAlt } from "react-icons/fa";
import { showModal, hideModal } from "../../actions/modalAction";
import { SINGLE_CANDIDATE_TELEPHONE_MODAL } from "../../constant/modaltypes";
import { connect } from "react-redux";

class SingleCandidatePage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      collapseable: {
        collapseOneOpen: true,
        collapseTwoOpen: false,
        collapseThreeOpen: false,
        collapseFourOpen: false
      }
    };
  }
  handleClick = event => {
    const target = event.target;
    this.setState({ collapseable: this.getNewCollapsableState(target) });
  };
  getNewCollapsableState = target => {
    let newState = {};
    for (let x in this.state.collapseable) {
      if (x === target.name) {
        newState[x] = !this.state.collapseable[x];
      } else {
        newState[x] = false;
      }
    }
    return newState;
  };
  closeModal = () => {
    this.props.nodisplayModal();
  };
  openModal = name => {
    let modalObject = {
      modalType: name,
      modalProps: {
        open: true,
        closeModal: this.closeModal
      }
    };
    this.props.displayModal(modalObject);
  };
  render() {
    return (
      <div
        className="clearfix equal-height-content"
        style={{ minHeight: "532px" }}
      >
        <div className="sidebar sidebar-colored candidate-profile-stages">
          <div className="candidate-profile-stages-header clearfix">
            <h3 className="heading text-uppercase">
              <Link
                to="#"
                className="long-text-ellipsis link-disguise"
                style={{ color: "#333" }}
              >
                <FaMobileAlt className="text-mute"></FaMobileAlt> iOS Developer
              </Link>
            </h3>
            <span className="assigned-user-label">
              <FaUser className="text-mute"></FaUser> Assigned to
            </span>
          </div>
          <div className="candidate-profile-stages-content">
            <div
              className="panel-group"
              id="accordion"
              role="tablist"
              aria-multiselectable="true"
            >
              <div className="panel current">
                <div className="panel-heading" role="tab" id="headingOne">
                  <h4 className="panel-title">
                    <span className="text-muted time">2 hours ago</span>
                    <Link
                      role="button"
                      name="collapseOneOpen"
                      to="#collapseOne"
                      aria-expanded={this.state.collapseable.collapseOneOpen}
                      aria-controls="collapseOne"
                      onClick={this.handleClick}
                    >
                      Screening
                    </Link>
                    <Collapse in={this.state.collapseable.collapseOneOpen}>
                      <div
                        id="collapseOne"
                        className="panel-collapse"
                        role="tabpanel"
                        aria-labelledby="headingOne"
                      >
                        <div className="panel-body">
                          <div className="action-block">
                            <div className="action-block-header">
                              <FaListAlt className="text-mute"></FaListAlt>{" "}
                              Screening
                              <span className="spacer text-muted">—</span>
                              <em className="text-muted">Yet to be sent</em>
                            </div>
                            <button className="btn btn-primary btn-sm">
                              Send profile for Review
                            </button>
                          </div>
                          <button
                            type="button"
                            className="btn btn-outline-secondary btn-sm"
                          >
                            <MdArrowBack></MdArrowBack> Move back to this stage
                          </button>
                        </div>
                      </div>
                    </Collapse>
                  </h4>
                </div>
              </div>
              <div className="panel visited">
                <div className="panel-heading" role="tab" id="headingTwo">
                  <h4 className="panel-title">
                    <span className="text-muted time">a minute ago</span>
                    <Link
                      role="button"
                      name="collapseTwoOpen"
                      to="#collapseTwo"
                      aria-expanded={this.state.collapseable.collapseTwoOpen}
                      aria-controls="collapseTwo"
                      onClick={this.handleClick}
                    >
                      Telephone Interview
                    </Link>
                    <Collapse in={this.state.collapseable.collapseTwoOpen}>
                      <div
                        id="collapseTwo"
                        className="panel-collapse"
                        role="tabpanel"
                        aria-labelledby="headingOne"
                      >
                        <div className="panel-body">
                          <div className="action-block">
                            <div className="action-block-header">
                              <MdDateRange className="text-mute"></MdDateRange>{" "}
                              Telephone Interview
                              <span className="spacer text-muted">—</span>
                              <em className="text-muted">
                                Your Evalution Pending
                              </em>
                            </div>
                            <button
                              className="btn btn-primary btn-sm"
                              onClick={() =>
                                this.openModal(SINGLE_CANDIDATE_TELEPHONE_MODAL)
                              }
                            >
                              Write Evalution
                            </button>
                          </div>
                          <button
                            type="button"
                            className="btn btn-outline-secondary btn-sm"
                          >
                            <MdArrowBack></MdArrowBack> Move back to this stage
                          </button>
                        </div>
                      </div>
                    </Collapse>
                  </h4>
                </div>
              </div>
              <div className="panel visited">
                <div className="panel-heading" role="tab" id="headingThree">
                  <h4 className="panel-title">
                    <span className="text-muted time">1 hour ago</span>
                    <Link
                      role="button"
                      name="collapseThreeOpen"
                      to="#collapseThree"
                      aria-expanded={this.state.collapseable.collapseThreeOpen}
                      aria-controls="collapseThree"
                      onClick={this.handleClick}
                    >
                      Face to face Interview
                    </Link>
                    <Collapse in={this.state.collapseable.collapseThreeOpen}>
                      <div
                        id="collapseThree"
                        className="panel-collapse"
                        role="tabpanel"
                        aria-labelledby="headingOne"
                      >
                        <div className="panel-body">
                          <div className="action-block">
                            <div className="action-block-header">
                              <MdDateRange className="text-mute"></MdDateRange>{" "}
                              Face to face Interview
                              <span className="spacer text-muted">—</span>
                              <em className="text-muted">Yet to Schedule</em>
                            </div>
                            <button className="btn btn-primary btn-sm">
                              Schedule Inteview
                            </button>
                            <br></br>
                            <button
                              type="button"
                              className="btn btn-link"
                              style={{ padding: 0 + "px" }}
                            >
                              <small>Already scheduled?</small>
                            </button>
                          </div>
                          <div style={{ display: "flex" }}>
                            <Dropdown
                              as={ButtonGroup}
                              className="custom-dropdown"
                              style={{ margin: "0px 5px" }}
                            >
                              <Button style={{ width: "300%" }}>
                                <MdArrowForward></MdArrowForward> Make Offer
                              </Button>
                              <Dropdown.Toggle
                                split
                                variant="success"
                                id="dropdown-split-basic-1"
                              />
                              <Dropdown.Menu>
                                <Dropdown.Item as={Link} to="#">
                                  Screening
                                </Dropdown.Item>
                                <Dropdown.Item as={Link} to="#">
                                  Telephone Interview
                                </Dropdown.Item>
                                <Dropdown.Item as={Link} to="#" disabled>
                                  Face to Face Interview
                                </Dropdown.Item>
                                <Dropdown.Item as={Link} to="#">
                                  Make Offer
                                </Dropdown.Item>
                                <hr style={{ margin: 0 }}></hr>
                                <Dropdown.Item as={Link} to="#">
                                  Mark as Hired
                                </Dropdown.Item>
                              </Dropdown.Menu>
                            </Dropdown>
                            <Dropdown
                              as={ButtonGroup}
                              className="custom-dropdown"
                              style={{ margin: "0px 5px" }}
                            >
                              <Button style={{ width: "300%" }}>
                                Select Action
                              </Button>
                              <Dropdown.Toggle
                                split
                                variant="success"
                                id="dropdown-split-basic"
                              />
                              <Dropdown.Menu>
                                <Dropdown.Item as={Link} to="#">
                                  Reject
                                </Dropdown.Item>
                                <Dropdown.Item as={Link} to="#">
                                  Put On Hold
                                </Dropdown.Item>
                                <Dropdown.Item as={Link} to="#">
                                  Candidate Withdrew
                                </Dropdown.Item>
                                <Dropdown.Item as={Link} to="#">
                                  Candidate declined offer
                                </Dropdown.Item>
                                <hr style={{ margin: 0 }}></hr>
                                <Dropdown.Item as={Link} to="#">
                                  Archive
                                </Dropdown.Item>
                                <hr style={{ margin: 0 }}></hr>
                                <Dropdown.Item as={Link} to="#">
                                  Mark as Spam
                                </Dropdown.Item>
                              </Dropdown.Menu>
                            </Dropdown>
                          </div>
                        </div>
                      </div>
                    </Collapse>
                  </h4>
                </div>
              </div>
              <div className="panel visited">
                <div className="panel-heading" role="tab" id="headingFour">
                  <h4 className="panel-title">
                    <span className="text-muted time">30 minutes ago</span>
                    <Link
                      role="button"
                      name="collapseFourOpen"
                      to="#collapseTwo"
                      aria-expanded={this.state.collapseable.collapseFourOpen}
                      aria-controls="collapseFour"
                      onClick={this.handleClick}
                    >
                      Make Offer
                    </Link>
                    <Collapse in={this.state.collapseable.collapseFourOpen}>
                      <div
                        id="collapseFour"
                        className="panel-collapse"
                        role="tabpanel"
                        aria-labelledby="headingOne"
                      >
                        <div className="panel-body">
                          <button
                            type="button"
                            className="btn btn-outline-secondary btn-sm"
                          >
                            <MdArrowBack></MdArrowBack> Move back to this stage
                          </button>
                        </div>
                      </div>
                    </Collapse>
                  </h4>
                </div>
              </div>
            </div>
          </div>
        </div>

        <SinglePageCandidateMain></SinglePageCandidateMain>
      </div>
    );
  }
}
const mapDispatchToProps = dispatch => {
  const displayModal = object => {
    dispatch(showModal(object));
  };
  const nodisplayModal = () => dispatch(hideModal());
  return { displayModal, nodisplayModal };
};
export default connect(null, mapDispatchToProps)(SingleCandidatePage);
