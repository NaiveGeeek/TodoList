import React, { Component } from 'react'
import { Image, Container, Form, Button } from 'react-bootstrap'
import "./Signup.css"
import logo from '../../assets/logo.png'
import { Link } from 'react-router-dom';

class Signup extends Component {
    constructor(props){
        super(props);
        this.state={
            fullName:'',
            email:'',
            password:'',
            phoneNumber:false,
        }
        }
        handleChange =(event)=>{
         const target = event.target;
         this.setState({[target.name] : target.value});
        }
    render() {
        return (
            <div className="signupContainer">
                <div className="signupHeader">
                    <Image src={logo} alt="company logo"></Image>
                    <h1 className="signupHeaderText">Sign up for Free &amp; set up your hiring today</h1>
                </div>
                <Container className="formContainer">
                    <Form>
                        <Form.Group controlId="fullname">
                            <Form.Control name="fullName" type="text" placeholder="Your Full Name" value={this.state.fullName} onChange={this.handleChange} />
                        </Form.Group>

                        <Form.Group controlId="emailId">
                            <Form.Control name="email" type="email" placeholder="Your Work Email" value={this.state.email} onChange={this.handleChange} />
                        </Form.Group>
                        <Form.Group controlId="password">
                            <Form.Control type="password" name="password" placeholder="Choose A Password" value={this.state.password} onChange={this.handleChange} />
                        </Form.Group>
                        <Form.Group controlId="checkbox">
                            <Form.Control type="number" name="phoneNumber" placeholder="Your Phone Number" value={this.state.phoneNumber} onChange={this.handleChange} />
                        </Form.Group>
                        <Button variant="primary" type="submit" block>
                          Create account &amp; Get started
                        </Button>
                    </Form>
                    <div className="cannotsignup">
                       No obligation, cancel anytime
                    </div>
                </Container>
                <p className="content-box-outer">By signing up, you agree to our <Link to="/signup">Terms of Service</Link></p>
                <Button className="loginBtn">
                    <Link to="/login" className="loginLink">Already have an account? Log in </Link>
                </Button>
            </div>
        )
    }
}

export default Signup
