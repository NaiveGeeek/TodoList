import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import {FaFacebookF, FaLinkedinIn, FaTwitter,FaSuitcase} from "react-icons/fa"
class SingleOpeningSidebar extends Component {
    render() {
        return (
            <div className="sidebar sidebar-colored">
                                    <aside className="sidebar-item list-sidebar-create">
                                        <Link to="/edit_opening" className="btn btn-default btn-create btn-with-icon">
                                            <FaSuitcase className="text-mute"></FaSuitcase> Edit Opening Details
                                        </Link>
                                    </aside>                                            
                                    <aside className="sidebar-item">
                                        <h3 className="sidebar-item-header">Important Actions</h3>
                                        <ul className="sidebar-list sidebar-nav list-unstyled">
                                            <li><Link to="#">Add / Remove Users</Link></li>
                                            <li><Link to="#">Manage Hiring Workflow</Link></li>
                                            <li><Link to="#">Customize the Application Form</Link></li>
                                            <li><Link to="#">Add tag to Opening</Link></li>
                                        </ul>
                                    </aside>
                                    <hr></hr>
                                    <aside className="sidebar-item">
                                        <h3 className="sidebar-item-header">More Actions</h3>
                                        <ul className="sidebar-list sidebar-nav list-unstyled">
                                            <li><Link to="#">Generate Report</Link></li>
                                            <li><Link to="#">Make this Opening private</Link></li>
                                            <li><Link to="#">Auto-acknowledgement settings</Link></li>
                                        </ul>
                                    </aside>
                                    <hr></hr>
                                    <aside className="sidebar-item">
                                        <h3 className="sidebar-item-header">Upload Candidates</h3>
                                        <ul className="sidebar-list sidebar-nav list-unstyled">
                                            <li><Link to="#">Add a Candidate</Link></li>
                                        </ul>
                                    </aside>
                                    <hr></hr>
                                    <aside className="sidebar-item">
                                        <h3 className="sidebar-item-header">Share your opening</h3>
                                        <div className="opening-social-buttons sidebar-item-content">
                                            <button type="button" className="btn btn-default btn-sm btn-social-share btn-social-share-facebook">
                                            <FaFacebookF style={{color: "#3b5998",marginRight:"5px"}}></FaFacebookF>
                                            <span>Share</span>
                                            </button>
                                            <button type="button" className="btn btn-default btn-sm btn-social-share btn-social-share-linkedin">
                                            <FaLinkedinIn style={{color: "#007fb1",marginRight:"5px"}}></FaLinkedinIn>
                                            <span>Share</span>
                                            </button>
                                            <button type="button" className="btn btn-default btn-sm btn-social-share btn-social-share-twitter">
                                            <FaTwitter style={{color: "#007fb1",marginRight:"5px"}}></FaTwitter>
                                            <span>Share</span>
                                            </button>                                            
                                        </div>
                                    </aside>
                                    <hr></hr>
                                    <aside className="sidebar-item">
                                        <h3 className="sidebar-item-header">Delete Opening</h3>
                                        <div className="sidebar-item-content">
                                            <p className="text-muted">Deleting an opening will remove all data associated with that opening.
                                                Deleting is permanent and cannot be reversed.<br></br><br></br>Alternately, if you want to stop working on this opening, you can "Archive" it.
                                                Archived openings cannot be modified, but you can un-archive them anytime.
                                                To archive an opening, see the "Summary" section above.
                                            </p>
                                            <button className="btn btn-sm btn-danger space-on-top-10px">
                                                <i className="glyphicon glyphicon-trash"></i> Delete permanently
                                            </button>                                                    
                                        </div>
                                    </aside>
                                </div>
        )
    }
}

export default SingleOpeningSidebar