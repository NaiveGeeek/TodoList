import React, { Component, Fragment } from 'react'
import NavbarPage from '../Navbar/NavbarPage'
import Routing from '../Routing/Routing'
import { withRouter } from 'react-router-dom'

class Home extends Component {
    render() {
        return (
            <Fragment>
                <NavbarPage></NavbarPage>
                <Routing></Routing>
            </Fragment>
        )
    }   
}

export default withRouter(Home)