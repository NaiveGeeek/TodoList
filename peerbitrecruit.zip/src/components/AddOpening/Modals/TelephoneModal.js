import React, { Component } from 'react';
import { Modal, Form, Row, Col } from 'react-bootstrap';
import {Typeahead} from "react-bootstrap-typeahead"
import "./TelephoneModal.css";
import { Link } from 'react-router-dom';
import {FaLock} from 'react-icons/fa'

class TelephoneModal extends Component {
    constructor(props){
        super(props);
        this.state={
            telephoneInterview:'',
            coordinator:" ",
            interviewers:[],
            medium:'1',
            duration:'1',
            additionalInfoVisible:false,

        }
        this.options=["Mohsin","Toufik"];
    }
    handleChange=(event)=>{
        const target = event.target;
        this.setState({
            [target.name]:target.value,
        })
    }
    handleMultipleInputChange =(values)=>{
        this.setState({
            interviewers:values,
        });
    }
    displayAdditionalInfo=()=>{
        this.setState({
           additionalInfoVisible:true,
        });
    }
    render() {
        return (
          <Modal show={this.props.isModalVisible} size="lg" centered backdrop="static">
            <Modal.Body style={{padding:0}}>
               <Form>
                   <Form.Group className="padding-1rem margin-top-1rem">
                       <Form.Control name= "telephoneInterview"type="text" placeholder="Screening" value={this.state.screening} onChange={this.handleChange}></Form.Control>
                   </Form.Group>
                   <Form.Group className="padding-1rem">
                        <Form.Label><strong>Coordinator</strong></Form.Label>
                            <Form.Control as="select" name="coordinator" value={this.state.job} onChange={this.handleChange}>
                                     <option value=" " disabled>Select a Person...</option>
                                     <option value="1">Abdulhannan</option>
                                     <option value="2">Mohsin</option>
                                     <option value="3">Taufiq</option>
                            </Form.Control>
                    </Form.Group>
                    <div className="divider"></div>
                    <div className="heading-telephone-modal">Preset for the interview</div>
                    <div className="subheading-telephone-modal text-mute">These <strong>can be oerridden </strong>while scheduling interview for any candidate</div>
                    <Form.Group className="padding-1rem">
                        <Form.Label><strong>Interviewers</strong></Form.Label>
                        <Typeahead
                            id ="interviewers"
                            labelKey="name"
                            clearButton
                            multiple ={true}
                            options={this.options}
                            placeholder="Choose a Person..." onChange={(values)=>{this.handleMultipleInputChange(values)}}>
                        </Typeahead>
                    </Form.Group>
                    <Row className="padding-1rem">
                        <Col sm={6}>
                            <Form.Label><strong>Type / Medium</strong></Form.Label>   
                            <Form.Control name="medium" as="select" onChange={this.handleChange} value={this.state.medium}>
                                <option value="1">Skype</option>
                                <option value="2">Phone</option>
                                <option value="3">Telephone (Direct call)</option>
                                <option value="4">Face to face</option>
                            </Form.Control>
                        </Col>
                        <Col sm={6}>  
                            <Form.Label><strong>Duration</strong></Form.Label>   
                            <Form.Control as="select" name="duration" onChange={this.handleChange} value={this.state.duration}>
                                <option value="1">15 minutes</option>
                                <option value="2">30 minutes</option>
                                <option value="3">45 minutes</option>
                                <option value="4">1 hour</option>
                            </Form.Control>
                        </Col>
                    </Row>
                    <div className="padding-1rem margin-top-1rem">
                        <Link to="#">Set up Evalution Form</Link>
                        <Link to="#" style={{display:this.state.additionalInfoVisible?"none":"inline-block",marginLeft:"8px"}} onClick={this.displayAdditionalInfo}>+ Additional Info</Link>
                    </div>
                    <Form.Group className="padding-1rem margin-top-1rem" style={{display:this.state.additionalInfoVisible?"block":"none"}}>
                        <Form.Label><strong>Additional Info</strong></Form.Label>
                        <Form.Control as="textarea" rows="4" />
                    </Form.Group>
                    <div className="padding-1rem margin-top-1rem">
                        <input type="checkbox"></input>
                        <span className="lock-icon  "><FaLock></FaLock></span>
                        <span>Keep the interview schedule and comments <strong>private</strong> to: coordinator &amp; interviewers.</span>
                    </div>
                    <div className="stage-edit-form-buttons clearfix">
                        <button type="submit" className="btn btn-primary pull-right save-btn">Save as Interview stage</button>
                        <button type="button" className="btn btn-default pull-right hide-non-interview-button" style={{marginRight:"10px"}} onClick={()=>{this.props.closeModal(this.props.name);}}>Cancel</button>
                    </div>
               </Form>
            </Modal.Body>
          </Modal>
        )
    }
}
 export default TelephoneModal