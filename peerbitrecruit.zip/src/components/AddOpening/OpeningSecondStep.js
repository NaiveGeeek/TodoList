import React, { Component } from "react";
import {
  Row,
  Col,
  Form,
  Button,
  OverlayTrigger,
  Tooltip
} from "react-bootstrap";
import { Link } from "react-router-dom";
import { FaInfoCircle } from "react-icons/fa";
import { Formik } from "formik";
import { openingCreateJobDetailSchema } from "../../constant/formvalidator";
class OpeningSecondStep extends Component {
  render() {
    return (
      <div className="main-col" style={{ paddingBottom: "150px" }}>
        <div className="page-header">
          <div className="page-title-block-bleeding-left clearfix">
            <h1 className="page-title">Almost there! </h1>
            <div className="js-steps-bar">
              <ol className="process-step-bar">
                <li className="process-step-item">1. Create Opening</li>
                <li className="process-step-item process-step-item-current">
                  2. Opening Details
                </li>
                <li className="process-step-item">3. Hiring Workflow</li>
              </ol>
            </div>
          </div>
        </div>
        <Row>
          <Col sm={8}>
            <Formik
              initialValues={{
                openingTitle: "",
                job: "",
                openingType: "",
                totalExpInYears: "",
                totalExpInMonths: "",
                location: "",
                jobDescription: ""
              }}
              validationSchema={openingCreateJobDetailSchema}
              onSubmit={values => {
                this.props.history.push("/add_opening/openings_stages");
              }}
            >
              {({ values, errors, touched, handleChange, handleSubmit }) => {
                return (
                  <Form onSubmit={handleSubmit}>
                    <div style={{ margin: "30px auto 20px" }}>
                      <h2>
                        Just a little more information about the opening and
                        we're ready to go.
                      </h2>
                    </div>
                    <Row>
                      <Col sm={6}>
                        <Form.Group>
                          <Form.Label>Opening Title</Form.Label>
                          <Form.Control
                            type="text"
                            name="openingTitle"
                            value={values.openingTitle}
                            onChange={handleChange}
                            className={
                              touched.openingTitle && errors.openingTitle
                                ? "error-input"
                                : null
                            }
                          ></Form.Control>
                          {touched.openingTitle && errors.openingTitle ? (
                            <div className="error-message">
                              {errors.openingTitle}
                            </div>
                          ) : null}
                        </Form.Group>
                      </Col>
                      <Col sm={6}>
                        <Form.Group>
                          <Form.Label>Job</Form.Label>
                          <Form.Control
                            as="select"
                            value={values.job}
                            onChange={handleChange}
                            name="job"
                            className={
                              touched.job && errors.job ? "error-input" : null
                            }
                          >
                            <option value="" disabled>
                              Select a Job
                            </option>
                            <option value="Business Development Manager">
                              Business Development Manager
                            </option>
                            <option value="iOS Developer">iOS Developer</option>
                            <option value="QA">QA</option>
                            <option value="Android Developer">
                              Android Developer
                            </option>
                          </Form.Control>
                          {touched.job && errors.job ? (
                            <div className="error-message">{errors.job}</div>
                          ) : null}
                        </Form.Group>
                      </Col>
                      <Col sm={6}>
                        <Form.Group>
                          <Form.Label>Opening Type</Form.Label>
                          <Form.Control
                            as="select"
                            value={values.openingType}
                            name="openingType"
                            onChange={handleChange}
                            className={
                              touched.openingType && errors.openingType
                                ? "error-input"
                                : null
                            }
                          >
                            <option value="" disabled>
                              Select a Type
                            </option>
                            <option value="1">Fresher</option>
                            <option value="2">Experience</option>
                          </Form.Control>
                          {touched.openingType && errors.openingType ? (
                            <div className="error-message">
                              {errors.openingType}
                            </div>
                          ) : null}
                        </Form.Group>
                      </Col>
                      <Col sm={6}>
                        <Form.Group>
                          <Form.Label>Total Experience</Form.Label>
                          <Row>
                            <Col sm={6}>
                              <Form.Control
                                as="select"
                                value={values.totalExpInYears}
                                name="totalExpInYears"
                                onChange={handleChange}
                                className={
                                  touched.totalExpInYears &&
                                  errors.totalExpInYears
                                    ? "error-input"
                                    : null
                                }
                              >
                                <option value="" disabled>
                                  Years
                                </option>
                                <option value="1 Year">1 Year</option>
                                <option value="2 Years">2 Years</option>
                              </Form.Control>
                              {touched.totalExpInYears &&
                              errors.totalExpInYears ? (
                                <div className="error-message">
                                  {errors.totalExpInYears}
                                </div>
                              ) : null}
                            </Col>
                            <Col sm={6}>
                              <Form.Control
                                as="select"
                                value={values.totalExpInMonths}
                                name="totalExpInMonths"
                                onChange={handleChange}
                                className={
                                  touched.totalExpInMonths &&
                                  errors.totalExpInMonths
                                    ? "error-input"
                                    : null
                                }
                              >
                                <option value="" disabled>
                                  Months
                                </option>
                                <option value="1 Month">1 Month</option>
                                <option value="2 Months">2 Months</option>
                              </Form.Control>
                              {touched.totalExpInMonths &&
                              errors.totalExpInMonths ? (
                                <div className="error-message">
                                  {errors.totalExpInMonths}
                                </div>
                              ) : null}
                            </Col>
                          </Row>
                        </Form.Group>
                      </Col>
                      <Col sm={6}>
                        <Form.Group>
                          <Form.Label>
                            Location{" "}
                            <OverlayTrigger
                              placement={"top"}
                              overlay={
                                <Tooltip
                                  id={`tooltip-${"top"}+${1}`}
                                  style={{ fontSize: "10px" }}
                                >
                                  For remote positions, please provide your
                                  office location.
                                </Tooltip>
                              }
                            >
                              <FaInfoCircle
                                style={{ marginLeft: "5px" }}
                                className="text-mute"
                              ></FaInfoCircle>
                            </OverlayTrigger>{" "}
                          </Form.Label>
                          <Form.Control
                            type="text"
                            placeholder="Enter a location"
                            value={values.location}
                            name="location"
                            onChange={handleChange}
                            className={
                              touched.location && errors.location
                                ? "error-input"
                                : null
                            }
                          ></Form.Control>
                          {touched.location && errors.location ? (
                            <div className="error-message">
                              {errors.location}
                            </div>
                          ) : null}
                        </Form.Group>
                      </Col>
                      <Col sm={12}>
                        <Form.Group>
                          <Form.Label>Job Description</Form.Label>
                          <Form.Control
                            as="textarea"
                            rows="3"
                            value={values.jobDescription}
                            name="jobDescription"
                            onChange={handleChange}
                            className={
                              touched.jobDescription && errors.jobDescription
                                ? "error-input"
                                : null
                            }
                          />
                          {touched.jobDescription && errors.jobDescription ? (
                            <div className="error-message">
                              {errors.jobDescription}
                            </div>
                          ) : null}
                        </Form.Group>
                      </Col>
                    </Row>
                    <div className="form-action">
                      <Button
                        type="submit"
                        variant="primary"
                        style={{ marginRight: "10px" }}
                        className="pull-right"
                      >
                        Next
                      </Button>
                      <Link
                        to="/add_opening"
                        className="btn btn-default pull-left"
                      >
                        {" "}
                        Back{" "}
                      </Link>
                    </div>
                  </Form>
                );
              }}
            </Formik>
          </Col>
        </Row>
      </div>
    );
  }
}
export default OpeningSecondStep;
