import React, { Component } from 'react'
import { Link } from 'react-router-dom'

export default class OpeningLastStage extends Component {
    render() {
        return (
            <div className="main-col">
                <div className="page-header">
                    <div className="page-title-block-bleeding-left clearfix">
                        <h1 className="page-title">We're done! </h1>
                    </div>
                </div>
                <div className="form-action">
                    <Link to="/add_opening/openings_stages" className="btn btn-default"><span className="big-text">«</span> Back</Link>
                    <Link to="/single_page_opening_view" className="btn btn-primary pull-right">View Opening Details <span className="big-text">»</span></Link>
                </div>
            </div>
        )
    }
}
