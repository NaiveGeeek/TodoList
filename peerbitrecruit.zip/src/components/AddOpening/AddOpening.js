import React, { Component, Fragment } from 'react'
import OpeningFirstStep from './OpeningFirstStep'
import { Switch,Route } from 'react-router-dom'
import OpeningSecondStep from './OpeningSecondStep'
import OpeningThirdStage from './OpeningThirdStage'
import OpeningLastStage from './OpeningLastStage'

export default class AddOpening extends Component {
    render() {
        return (
            <Fragment>
                <SubRoute></SubRoute>          
            </Fragment>
        )
    }
}

const SubRoute =()=>{
    return(
              <Fragment>
                  <Switch>
                    <Route exact path ="/add_opening" component={OpeningFirstStep}></Route>
                    <Route  path ="/add_opening/openings_details" component={OpeningSecondStep}></Route>
                    <Route  path ="/add_opening/openings_stages" component={OpeningThirdStage}></Route>
                    <Route  path ="/add_opening/opening_creation_success" component={OpeningLastStage}></Route>
                </Switch>
             </Fragment>    
    );
}
