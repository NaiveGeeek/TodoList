//Dashboard Action Types
export const GET_TODOS="GET_TODOS";
export const GET_ASSIGNED_INTERVIEWS = "GET_ASSIGNED_INTERVIEW";
export const GET_THINGS_TO_FOLLOW_UP = "GET_THINGS_TO_FOLLOW_UP";

//Modal Action Types
export const SHOW_MODAL ="SHOW_MODAL";
export const HIDE_MODAL ="HIDE_MODAL";
