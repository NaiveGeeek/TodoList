//Dashboard Action Types
export const GET_TODOS="GET_TODOS";
export const GET_ASSIGNED_INTERVIEWS = "GET_ASSIGNED_INTERVIEW";
export const GET_THINGS_TO_FOLLOW_UP = "GET_THINGS_TO_FOLLOW_UP";

//Modal Action Types
export const SHOW_MODAL ="SHOW_MODAL";
export const HIDE_MODAL ="HIDE_MODAL";

//Login action Types
export const SET_USER_LOGIN_DETAILS = "SET_USER_LOGIN_DETAILS";

//Opening Page action Types
export const OPENING_OVERVIEW_LIST = "OPENING_OVERVIEW_LIST";
export const OPENING_ASSIGNED_TO_ME = "OPENING_ASSIGNED_TO_ME";
export const OPENING_ALL = "OPENING_ALL";

//Candidate Page Action Types
export const CANDIADTE_OVERVIEW_LIST = "CANDIADTE_OVERVIEW_LIST"; 
export const ADD_CANDIDATE ="ADD_CANDIDATE";

//Calander Page Action Types
export const ADD_EVENTS_TO_CALANDAR = "ADD_EVENTS_TO_CALANDAR";
export const DELETE_EVENTS_FROM_CALANDAR = "DELETE_EVENTS_FROM_CALANDAR";
