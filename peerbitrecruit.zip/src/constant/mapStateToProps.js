export const navbarStateToPops=(state)=>{
const { loginState: loginData } = state;
return { loginData };
}

export const openingStateToProps =(state)=>{
    return {openingState : state.openingState}
}
export const candidateStateToProps = (state)=>{
    return {candidateState:state.candidateState}
}
export const modalcontainerStateToProps = (state)=>{
    return {modalState:state.modalState}
}
export const calandarStateToProps = (state)=>{
    return {calandarState:state.calandarState}
}
export  const mapStateToProps=(data)=>{
    return (state)=>{
        const newStateToProps = data.reduce((accumulator={},current)=>{
            return {...accumulator,...current(state)}
        });
        return newStateToProps;
    }
}