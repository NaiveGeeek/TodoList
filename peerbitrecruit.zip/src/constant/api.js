import { HTTP_METHOD } from "../constant/httpMethods";
import axios from "axios";
import { toast } from "react-toastify";
export const httpService = (
  url,
  methodType = HTTP_METHOD.GET,
  payload = {},
  config = {},
  success,
  failure,
  callback = null
) => {
  let result = callAppropriateHttpMethod(url, methodType, payload, config);
  result.then(
      response=>{
          if(success){
              success(response.data);
          }
      }
  ).catch(
      error=>{
          if(error.response && (typeof error.response.data === "string")){
              toast.error(error.response.data)
          }else{
              toast.error("something went wrong");
          }
          
      }
  );
};

const callAppropriateHttpMethod = (url, methodType, payload, config) => {
  switch (methodType) {
    case HTTP_METHOD.POST: {
      return axios.post(url, payload, config);
    }
    case HTTP_METHOD.GET: {
      return axios.get(url, config);
    }
    case HTTP_METHOD.PUT: {
      return axios.put(url, payload, config);
    }
    case HTTP_METHOD.DELETE: {
      return axios.delete(url, config);
    }
    case HTTP_METHOD.PATCH: {
      return axios.patch(url, payload, config);
    }
    default: {
      return axios.get(url, config);
    }
  }
};
