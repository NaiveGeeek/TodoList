import React, { Component } from 'react'
import { Link } from 'react-router-dom'

class ActionIcon extends Component {
    render() {
        return (
            <div>
               <Link className="salient-action" to = "/">
               <span className={`icon-large ${this.props.className} salient-action-icon`}></span>
               <div className="salient-action-label">{this.props.label}</div>
               </Link>  
            </div>
        )
    }
}
export default ActionIcon