import {CANDIADTE_OVERVIEW_LIST, ADD_CANDIDATE} from "../constant/actiontypes"
export const candidateOverview=(data)=>{
    return{
    type:CANDIADTE_OVERVIEW_LIST,
    payload:data
}};
export const addCandidate=(data)=>{
    return{
        type:ADD_CANDIDATE,
        payload:data
    }
}