import { ADD_EVENTS_TO_CALANDAR,DELETE_EVENTS_FROM_CALANDAR } from "../constant/actiontypes";

export const addEventsToCalandar=(data)=>{
    return{
        type:ADD_EVENTS_TO_CALANDAR,
        payload:data
    }
}
export const deleteEventsFromCalandar =(id)=>{
    return{
        type:DELETE_EVENTS_FROM_CALANDAR,
        paylaod:id
    }
}