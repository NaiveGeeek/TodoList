import { OPENING_OVERVIEW_LIST, OPENING_ASSIGNED_TO_ME, OPENING_ALL } from "../constant/actiontypes";

export const openingOverview=(data)=>{
    return{
    type:OPENING_OVERVIEW_LIST,
    payload:data
}}

export const openingAssignedToMe= (data)=>({
    type:OPENING_ASSIGNED_TO_ME,
    payload:data
})
export const openingAll = (data)=>({
    type:OPENING_ALL,
    payload:data
})