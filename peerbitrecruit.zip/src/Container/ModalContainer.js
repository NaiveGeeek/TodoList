import React, { Component } from "react";
import { SINGLE_CANDIDATE_TELEPHONE_MODAL } from "../constant/modaltypes";
import TelephoneCandidateModal from "../components/SingleCandidatePage/Modal/TelephoneCandidateModal";
import { connect } from "react-redux";

const MODAL_TYPES = {
  [SINGLE_CANDIDATE_TELEPHONE_MODAL]: TelephoneCandidateModal
};
class ModalContainer extends Component {
  render() {
    const SpecifiedModal = MODAL_TYPES[this.props.modalType];
    return SpecifiedModal ? (
      <SpecifiedModal {...this.props}></SpecifiedModal>
    ) : null;
  }
}
const mapStateToProps = state => {
  return { ...state.modalState };
};
export default connect(mapStateToProps)(ModalContainer);
