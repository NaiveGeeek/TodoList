import React, { Component } from "react";
import { SINGLE_CANDIDATE_TELEPHONE_MODAL, OPENING_STAGE_TELEPHONIC_MODAL, OPENING_STAGE_SCREENING_MODAL, CREATE_EVENT_MODAL } from "../constant/modaltypes";
import TelephoneCandidateModal from "../components/SingleCandidatePage/Modal/TelephoneCandidateModal";
import { connect } from "react-redux";
import TelephoneModal from "../components/AddOpening/Modals/TelephoneModal";
import ScreeningModal from "../components/AddOpening/Modals/ScreeningModal";
import { mapStateToProps, modalcontainerStateToProps } from "../constant/mapStateToProps";
import CreateEventModal from "../components/Calendar/createEventModal";

const MODAL_TYPES = {
  [SINGLE_CANDIDATE_TELEPHONE_MODAL]: TelephoneCandidateModal,
  [OPENING_STAGE_TELEPHONIC_MODAL]:TelephoneModal,
  [OPENING_STAGE_SCREENING_MODAL]:ScreeningModal,
  [CREATE_EVENT_MODAL]:CreateEventModal
};
class ModalContainer extends Component {
  
  render() {
    const SpecifiedModal = MODAL_TYPES[this.props.modalState.modalType];
    return SpecifiedModal ? (
      <SpecifiedModal {...this.props.modalState}></SpecifiedModal>
    ) : null;
  }
}
export default connect(mapStateToProps([modalcontainerStateToProps]))(ModalContainer);
