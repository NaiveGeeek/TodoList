import React from'react'
import { Route, Redirect } from "react-router-dom";
import { isUserAuthorized } from './utils/commonFuntions';


function SecuredRoute({component:Component,...rest}){
  return(
      <Route {...rest} render={(props)=>{
         return isUserAuthorized()?<Component {...props}></Component>:<Redirect to={{pathname:"/login",state:{from:props.location}}}></Redirect>
      }}></Route>
  )
}

export default SecuredRoute;