import { ADD_EVENTS_TO_CALANDAR } from "../../constant/actiontypes";

const initialState ={
    calandarEvents:[]
}

const CalandarReducer =(state = initialState,action)=>{
    switch(action.type){
        case ADD_EVENTS_TO_CALANDAR:{
            return {...state,calandarEvents:[...state.calandarEvents,action.payload]}
        }
        default:
            return {...state}
    }
}

export default CalandarReducer;