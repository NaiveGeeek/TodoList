import { CANDIADTE_OVERVIEW_LIST, ADD_CANDIDATE } from "../../constant/actiontypes"

const initialState={
    candidates:[{
        id:1,
        firstName:"Adil",
        lastName:"Khan",
        email:"adil@gmail.com",
        phone:"9876543210",
        dateOfBirth:"01/01/1993",
        gender:"Male",
        location:"Ahmedabad",
        joiningDate:"01/01/2019",
        totalExperience:"2 year 5 months",
        totalReleventExperience:"2 year 0 months",
        currentCtc:"3 Lakh 40 Thousand",
        expectedCtc:"4 Lakh 80 Thousand",
        job:"IOS Developer",
        opening:1,
        stage:"screening",
        source:"Naukari",
        description:"",
        assignedDate:"01/01/2020",
    },{
        id:2,
        firstName:"Safina",
        lastName:"Khan",
        email:"safina@gmail.com",
        phone:"9876543210",
        dateOfBirth:"01/05/1993",
        gender:"Male",
        location:"Ahmedabad",
        joiningDate:"01/02/2018",
        totalExperience:"2 year 5 months",
        totalReleventExperience:"2 year 0 months",
        currentCtc:"3 Lakh 40 Thousand",
        expectedCtc:"4 Lakh 80 Thousand",
        job:"Android Developer",
        opening:2,
        stage:"screening",
        source:"Naukari",
        description:"",
        assignedDate:"16/01/2020",
    },
]

}
 const CandidateReducer =(state=initialState,action)=>{
    switch(action.type){
     case CANDIADTE_OVERVIEW_LIST:{
         return {...state,candidates:action.payload}
     }
     case ADD_CANDIDATE:{
         return {...state,candidates:[...state.candidates,action.payload]}
     }
     default:{
         return {...state}
     }
    }
}
export default CandidateReducer;