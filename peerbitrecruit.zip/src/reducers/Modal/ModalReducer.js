import {SHOW_MODAL,HIDE_MODAL} from '../../constant/actiontypes';

const initial_state={
    modalType:null,
    modalProps:{
        open:false
    }
}

const ModalReducer =(state =initial_state,action)=>{
    switch(action.type){
        case SHOW_MODAL:
            return{
                modalType:action.modalType,
                modalProps:action.modalProps,
                type:action.type,
            }
        case HIDE_MODAL:
            return initial_state
        default:
            return state
         }
}

export default ModalReducer