import { OPENING_OVERVIEW_LIST, OPENING_ASSIGNED_TO_ME, OPENING_ALL } from "../../constant/actiontypes"

const initialState={
    overview:[],
    allOpenigs:[],
    assignedToMe:[]
}
 const OpeningReducer =(state=initialState,action)=>{
    switch(action.type){
     case OPENING_OVERVIEW_LIST:{
         return {...state,overview:action.payload}
     }
     case OPENING_ASSIGNED_TO_ME:{
         return {...state,assignedToMe:action.payload}
     }
     case OPENING_ALL:{
         return {...state,allOpenigs:action.payload}
     }
     default:{
         return {...state}
     }
    }
}
export default OpeningReducer;