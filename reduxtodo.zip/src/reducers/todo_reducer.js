import {
  ADD_TODO,
  DELETE_TODO,
  UPDATE_TODO,
  SETALL_TODO
} from "../constants/action_types";
const initialState = {
  todos: []
};
const todoReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_TODO: {
      return {
        ...state,
        todos: [...state.todos, action.payload]
      };
    }
    case DELETE_TODO: {
      const newTodos = state.todos.filter(data => {
        return data.id !== action.id;
      });
      return { ...state, todos: newTodos };
    }
    case UPDATE_TODO: {
      const updateTodos = state.todos.map(data => {
        if (data.id === action.payload.id) {
          data = action.payload;
        }

        return data;
      });
      return { ...state, todos: updateTodos };
    }
    case SETALL_TODO: {
      return { ...state, todos: action.payload };
    }
    default:
      return { ...state };
  }
};
export default todoReducer;
