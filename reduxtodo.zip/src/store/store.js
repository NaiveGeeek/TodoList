import { createStore, applyMiddleware } from "redux";
import thunk from "redux-thunk";
import todo_reducer from "../reducers/todo_reducer";
const store = createStore(todo_reducer, applyMiddleware(thunk));

export default store;
