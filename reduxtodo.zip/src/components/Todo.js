import React, { Component, Fragment } from "react";
import { connect } from "react-redux";
import {
  addTodo,
  deleteTododata,
  fetchTododata
} from "../constants/Actions/todo_actions";
import { Button, Row, Col, Container } from "react-bootstrap";

class Todo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      value: "",
      elementId: ""
    };
  }
  handleInputChange = event => {
    this.setState({
      value: event.target.value
    });
  };
  componentDidMount() {
    this.props.getTodoData();
  }
  displayTodoList = () => {
    const { todos: todoList } = this.props;
    const elements = todoList.map(data => {
      return (
        <Row key={data.id}>
          <Col xs={10} className="mb-2">
            <span>{data.title}</span>
          </Col>
          <Col xs={2} className="mb-2">
            <Button
              variant="danger"
              onClick={() => {
                this.props.deleteItem(data.id);
              }}
            >
              delete
            </Button>
          </Col>
        </Row>
      );
    });
    return elements;
  };
  render() {
    return (
      <Fragment>
        <Container className="todo-input-container"> 
          <input
            type="text"
            value={this.state.value}
            onChange={event => {
              this.handleInputChange(event);
            }}
          />  
          <Button
            variant="primary"
            onClick={() => {
              this.props.addItem(this.state.value);
            }}
          >
            Add Todo
          </Button>
        </Container>
        <Container className="todo-list-container">
          <div>
            <h6 className="todo-list-heading"> List of Todos</h6>
          </div>
          {this.displayTodoList()}
        </Container>
      </Fragment>
    );
  }
}
const mapStateToProps = state => {
  const { todos } = state;
  return { todos };
};
const mapDispatchToProps = dispatch => {
  const getTodoData = () => dispatch(fetchTododata());
  const deleteItem = id => dispatch(deleteTododata(id));
  const addItem = value => dispatch(addTodo(value));

  return { getTodoData, deleteItem, addItem };
};
export default connect(mapStateToProps, mapDispatchToProps)(Todo);
