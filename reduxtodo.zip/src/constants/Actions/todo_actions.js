import {
  ADD_TODO,
  DELETE_TODO,
  UPDATE_TODO,
  SETALL_TODO
} from "../action_types";
import axios from "axios";
let indexValue = 0;
export const addTodo = value => ({
  type: ADD_TODO,
  payload: {
    id: ++indexValue,
    title: value,
    completed: false
  }
});

export const updateTodo = (id, value) => ({
  type: UPDATE_TODO,
  payload: {
    id: id,
    title: value,
    completed: false
  }
});

export const deleteTodo = id => ({
  type: DELETE_TODO,
  id: id
});
export const setAllTodo = data => ({
  type: SETALL_TODO,
  payload: data
});

export const fetchTododata = () => {
  return dispatch => {
    axios
      .get(
        "https://cors-anywhere.herokuapp.com/https://jsonplaceholder.typicode.com/todos"
      )
      .then(response => {
        indexValue=response.data.length;
        dispatch(setAllTodo(response.data));
      });
  };
};
export const deleteTododata = id => {
  return dispatch => {
    axios
      .delete(
        `https://cors-anywhere.herokuapp.com/https://jsonplaceholder.typicode.com/todos/${id}`
      )
      .then(response => {
        dispatch(deleteTodo(id));
      })
      .catch(error => {
        console.log("something went wrong");
      });
  };
};
