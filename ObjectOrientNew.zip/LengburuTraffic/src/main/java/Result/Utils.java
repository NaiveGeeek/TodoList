package Result;

import Orbit.OrbitTypes;
import Vehicle.Vehicle;
import Weather.Weather;

import java.util.ArrayList;

public class Utils {
    private static final int NUMBER_OF_MINUTES_IN_HOUR = 60;
    public static Result calculateMinTimeTakenToTravel(OrbitTypes[] orbit, int[] trafficSpeed, Weather weather, Vehicle vehicle) {
        Result result = new Result(orbit[0].name(),vehicle.getName(),Float.MAX_VALUE);
        for(int i = 0;i<orbit.length;i++){
            float time = calculateTimeToTravelOnIndividualOrbit(orbit[i],trafficSpeed[i],weather,vehicle);
            if(time<result.getTime()){
                result.setOrbitName(orbit[i].name());
                result.setTime(time);
            }
        }
        return result;
    }


    private static float calculateTimeToTravelOnIndividualOrbit(OrbitTypes orbit, int trafficSpeed, Weather weather,Vehicle vehicle) {
        int craters = orbit.getCraters();
        craters = weather.getCratersValue(craters);
        int vehicleSpeed = Math.min(vehicle.getMaxSpeed(), trafficSpeed);
        float time = craters*vehicle.getTimeToCrossSingleCrater() + ((orbit.getOrbitLength()*NUMBER_OF_MINUTES_IN_HOUR)/vehicleSpeed);
        return time;
    }

    public static Result getCalculatedResult(ArrayList<Result> results){
        Result resultData = results.get(0);
        for(Result el:results){
            if(resultData.getTime()>el.getTime()){
                resultData =el;
            }
        }
        return resultData;
    }
}
