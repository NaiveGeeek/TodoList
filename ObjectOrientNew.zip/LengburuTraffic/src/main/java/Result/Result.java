package Result;

import java.util.ArrayList;

public class Result {

    private String orbitName;

    private String vehicleName;

    private float  time;

    public  Result(String orbitName , String vehicleName , float time){
        this.orbitName = orbitName;
        this.vehicleName = vehicleName;
        this.time = time;
    }

    public String getOrbitName() {
        return orbitName;
    }

    public String getVehicleName() {
        return vehicleName;
    }

    public float getTime() {
        return time;
    }

    public void setOrbitName(String orbitName) {
        this.orbitName = orbitName;
    }

    public void setVehicleName(String vehicleName) {
        this.vehicleName = vehicleName;
    }

    public void setTime(float time) {
        this.time = time;
    }


}
