package Weather;

import Vehicle.Vehicle;
import Vehicle.VehicleFactory;

import java.util.ArrayList;

public class Sunny implements Weather{
   private WeatherTypes weather = WeatherTypes.SUNNY;


   @Override
   public ArrayList<Vehicle> getUsableVehicleList() {
      return VehicleFactory.getVehicleObject(weather.name());
   }

   @Override
   public int getCratersValue(int existingCraters) {
      return (int) (existingCraters-existingCraters*0.1);
   }
}
