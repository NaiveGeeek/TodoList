package Weather;

import Vehicle.Vehicle;

import java.util.ArrayList;

public interface Weather {
    ArrayList<Vehicle> getUsableVehicleList();
    int getCratersValue(int existingCraters);
}
