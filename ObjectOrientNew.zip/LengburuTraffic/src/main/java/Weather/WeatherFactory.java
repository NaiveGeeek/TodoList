package Weather;

public class WeatherFactory {
    public static Weather getWeather (String name){
        if(name.equals(WeatherTypes.SUNNY.name())){
         return new Sunny();
        }else if(name.equals(WeatherTypes.RAINY.name())){
            return new Rainy();
        }else
            return new Windy();
    }
}
