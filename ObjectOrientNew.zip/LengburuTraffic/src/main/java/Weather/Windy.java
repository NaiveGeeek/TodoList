package Weather;

import Vehicle.Vehicle;
import Vehicle.VehicleFactory;
import java.util.ArrayList;

public class Windy implements Weather {
    private WeatherTypes weather = WeatherTypes.WINDY;


    @Override
    public ArrayList<Vehicle> getUsableVehicleList() {
        return VehicleFactory.getVehicleObject(weather.name());
    }

    @Override
    public int getCratersValue(int existingCraters) {
        return (existingCraters);
    }
}
