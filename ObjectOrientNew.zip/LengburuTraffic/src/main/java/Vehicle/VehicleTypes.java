package Vehicle;

public enum VehicleTypes {
    BIKE,
    TUKTUK,
    CAR;
}
