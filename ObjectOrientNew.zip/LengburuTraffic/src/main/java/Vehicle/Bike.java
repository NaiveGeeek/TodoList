package Vehicle;

import Orbit.OrbitTypes;
import Result.Result;
import Weather.Weather;

public class Bike implements Vehicle {

    private final String name = VehicleTypes.BIKE.name();

    private final int maxSpeed = 10;

    private final int timeToCrossSingleCrater = 2;

   public Bike(){

    }

    @Override
    public int getMaxSpeed() {
        return maxSpeed;
    }

    @Override
    public int getTimeToCrossSingleCrater() {
        return timeToCrossSingleCrater;
    }

    @Override
    public String getName(){
        return this.name;
    }

}
