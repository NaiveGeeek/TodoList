package Vehicle;
import Orbit.OrbitTypes;
import Result.Result;
import Weather.Weather;

public interface Vehicle {
 String getName();
 int getTimeToCrossSingleCrater();
 int getMaxSpeed();
}
