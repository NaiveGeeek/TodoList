package Vehicle;

import Orbit.OrbitTypes;
import Result.Result;
import Weather.Weather;

public class Car implements Vehicle {
    private final String name = VehicleTypes.CAR.name();

    private final int maxSpeed = 20;

    private final int timeToCrossSingleCrater = 3;

    public  Car(){

    }

    @Override
    public int getMaxSpeed() {
        return maxSpeed;
    }

    @Override
    public int getTimeToCrossSingleCrater() {
        return timeToCrossSingleCrater;
    }

    @Override
    public String getName(){
        return this.name;
    }
}
