package Vehicle;

import Orbit.OrbitTypes;
import Result.Result;
import Weather.Weather;

public class Tuktuk implements Vehicle {
    private final String name = VehicleTypes.TUKTUK.name();

    private final int maxSpeed = 12;

    private final int timeToCrossSingleCrater = 1;

    public Tuktuk(){

    }

    @Override
    public int getMaxSpeed() {
        return maxSpeed;
    }

    @Override
    public int getTimeToCrossSingleCrater() {
        return timeToCrossSingleCrater;
    }

    @Override
    public String getName(){
        return this.name;
    }
}
