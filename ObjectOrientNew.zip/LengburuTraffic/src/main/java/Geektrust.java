import Orbit.OrbitFactory;
import Orbit.OrbitTypes;
import Orbit.OrbitFactory;
import Result.Result;
import Result.Utils;
import Vehicle.Vehicle;
import Weather.Weather;
import Weather.WeatherFactory;

import java.util.ArrayList;

public class Geektrust {
    public static void main(String [] args){
        OrbitTypes[] orbit = OrbitFactory.getOrbits();
        int []trafficSpeed = {12,10};
        Weather weather = WeatherFactory.getWeather("SUNNY");
        ArrayList<Result> results = new ArrayList<>();
        ArrayList<Vehicle> vehicles = weather.getUsableVehicleList();
        for(Vehicle vl :vehicles){
            results.add(Utils.calculateMinTimeTakenToTravel(orbit,trafficSpeed,weather,vl));
        }
        Result rl = Utils.getCalculatedResult(results);
        System.out.println( rl.getVehicleName()+ " " + rl.getOrbitName());
    }
}
