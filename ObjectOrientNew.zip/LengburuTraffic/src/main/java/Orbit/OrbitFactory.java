package Orbit;

public class OrbitFactory {
    public  static  OrbitTypes[] getOrbits(){
        OrbitTypes[] orbit ={OrbitTypes.ORBIT1,OrbitTypes.ORBIT2};
        return orbit;
    }
}
