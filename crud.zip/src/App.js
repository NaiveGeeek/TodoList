import React from 'react';
import './App.css';
import Home from './component/home';
import { Provider } from "react-redux";
import store from "../src/store/store"
function App() {
  return (
    <Provider store={store}>
    <Home></Home>
    </Provider>
  );
}

export default App;
