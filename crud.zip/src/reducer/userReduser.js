import {
  ADD_USER,
  DELETE_USER,
  UPDATE_USER,
  GET_ALL_USER,
} from "../action/actiontypes";

const initialState = {
  users: [],
};
const userReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_USER: {
      return {
        ...state,
        todos: [...state.users, action.payload],
      };
    }
    case DELETE_USER: {
      const newUsers = state.users.filter((data) => {
        return data.id !== action.payload.id;
      });
      return { ...state, users: newUsers };
    }
    case UPDATE_USER: {
      const updateUser = state.users.map((data) => {
        if (data.id === action.payload.id) {
          data = action.payload.data;
        }

        return data;
      });
      return { ...state, users: updateUser };
    }
    case GET_ALL_USER: {
      return { ...state, users: action.payload.data };
    }
    default:
      return { ...state };
  }
};
export default userReducer;
