import {
  ADD_USER,
  UPDATE_USER,
  DELETE_USER,
  GET_ALL_USER,
} from "./actiontypes";
import Axios from "axios";
const corsUrl = "https://cors-anywhere.herokuapp.com/";
const httpUrl = "https://jsonplaceholder.typicode.com/users";

export const addUser = (data) => ({
  type: ADD_USER,
  payload: {
    data: data,
  },
});

export const updateUser = (id, data) => ({
  type: UPDATE_USER,
  payload: {
    id: id,
    data: data,
  },
});

export const deleteUser = (id) => ({
  type: DELETE_USER,
  payload: { id: id },
});

export const getAllUSer = (data) => ({
  type: GET_ALL_USER,
  payload: {
    data: data,
  },
});

export const fetchAllUser = () => {
  return (dispatch) => {
    Axios.get(corsUrl + httpUrl)
      .then((response) => {
        dispatch(getAllUSer(response.data));
      })
      .catch(() => {
        console.log("something went wrong !!!");
      });
  };
};

export const deletUserRequest = (id) => {
  return (dispatch) => {
    Axios.delete(corsUrl + httpUrl + `/:${id}`)
      .then((response) => {
        dispatch(deleteUser(id));
      })
      .catch(() => {
        console.log("something went wrong !!!");
      });
  };
};

export const updateUserRequest = (id, data) => {
  return (dispatch) => {
    Axios.put(corsUrl + httpUrl + `/:${id}`, data)
      .then((response) => {
        dispatch(updateUser(id, data));
      })
      .catch(() => {
        console.log("something went wrong !!!");
      });
  };
};

export const addUserRequest = (data)=>{
 const newData = {id:Date.now(),...data};
 return (dispatch) => {
    Axios.post(corsUrl + httpUrl, newData)
      .then((response) => {
        dispatch(addUser(newData));
      })
      .catch(() => {
        console.log("something went wrong !!!");
      });
  };
};
