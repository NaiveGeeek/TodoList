import React, { Component } from "react";
import { Button, Container } from "react-bootstrap";
import FormModal from "./formModal";
import { deletUserRequest, fetchAllUser, addUserRequest, updateUserRequest } from "../action/action";
import { connect } from "react-redux";

class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {
      adduser: false,
      edituser: false,
    };
  }
  openadduserModal = () => {
    this.setState({
      adduser: true,
    });
  };
  closeadduserModal = () => {
    this.setState({
      adduser: false,
    });
  };
  componentDidMount() {
    this.props.getUserData();
  }
  render() {
     console.log(this.props.users);
    return (
      <Container>
        <Button onClick={this.openadduserModal}> + Add User</Button>
        {this.state.adduser ? (
          <FormModal
            open={this.state.adduser}
            handleClose={this.closeadduserModal}
          ></FormModal>
        ) : null}
      </Container>
    );
  }
}
const mapStateToProps = state => {
    const { users } = state;
    return { users };
  };
  const mapDispatchToProps = dispatch => {
    const getUserData = () => dispatch(fetchAllUser());
    const deleteUser = id => dispatch(deletUserRequest(id));
    const addUser = data => dispatch(addUserRequest(data));
    const updateUser = (id,data) => dispatch(updateUserRequest(id,data));
    return { getUserData,deleteUser,addUser,updateUser};
  };

export default connect(mapStateToProps, mapDispatchToProps)(Home);
