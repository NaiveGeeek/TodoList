import java.util.Set;

public class PersonalDetail {

    private String fatherName;
    private String motherName;
    private Set<String> childrenName;
    private String spouseName;

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public String getMotherName() {
        return motherName;
    }

    public void setMotherName(String motherName) {
        this.motherName = motherName;
    }

    public Set<String> getChildrenName() {
        return childrenName;
    }

    public void setChildrenName(Set<String> childrenName) {
        this.childrenName = childrenName;
    }

    public String getSpouseName() {
        return spouseName;
    }

    public void setSpouseName(String spouseName) {
        this.spouseName = spouseName;
    }


}
