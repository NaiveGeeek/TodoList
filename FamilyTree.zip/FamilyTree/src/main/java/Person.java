public class Person {

    private String name;

    private GenderType genderType;

    private PersonalDetail personalDetail;

    public Person(){

    }

    public Person(String name,GenderType genderType){
         this.name = name;
         this.genderType = genderType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public GenderType getGenderType() {
        return genderType;
    }

    public void setGenderType(GenderType genderType) {
        this.genderType = genderType;
    }

    public PersonalDetail getPersonalDetail(){
        return this.personalDetail;
    }

    public void setPersonalDetail(PersonalDetail personalDetail){
        this.personalDetail = personalDetail;
    }

}
