import React, { Component } from "react";
import { Row, Col, Dropdown } from "react-bootstrap";
import { IoMdMore, IoMdCreate } from "react-icons/io";
import { FaUser, FaLock, FaRegClock, FaRegCalendarAlt } from "react-icons/fa";
import { Link } from "react-router-dom";
import { DragSource, DropTarget } from "react-dnd";
import { findDOMNode } from "react-dom";
import { flow } from "lodash";
class InterviewStage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      expanded: false
    };
  }

  handleExpansion = () => {
    this.setState({ expanded: !this.state.expanded });
  };

  render() {
    const subdetails = this.props.subdetails;
    const {
      connectDragSource,
      connectDropTarget,
      isDragging,
      canDrop,
      isOver
    } = this.props;
    const opacity = isDragging ? 0.5 : 1;
    // console.log(this.props);
    const backgroundColor =
      isOver && canDrop ? "white" : !isOver && canDrop ? "#f3f0e8" : "white";
    return connectDropTarget(
      connectDragSource(
        <div>
          <Row className="stage-row" style={{ opacity, backgroundColor }}>
            <Col xs={1}>
              <IoMdMore></IoMdMore>
              <IoMdMore></IoMdMore>
            </Col>
            <Col xs={10}>
              <div>
                <span className="title-opening">{this.props.title}</span>
                <span className="text-mute">·</span>
                <span className="text-mute">
                  <FaUser style={{ fontSize: "12px" }}></FaUser>
                </span>
                <span style={{ marginRight: "10px" }} className="text-mute">
                  <strong>Cordinator:</strong>
                </span>
                <span className="text-mute">{this.props.coordinator}</span>
              </div>
              <div
                className="sub-content-opening"
                style={{
                  display: subdetails ? "block" : "none"
                }}
              >
                <span className="text-mute">
                  <FaUser></FaUser>
                </span>
                <span>
                  <span>Interviewers: </span>
                  <span>
                    {subdetails ? subdetails.interviewers.join(", ") : ""}
                  </span>
                </span>
                <span className="text-mute">·</span>
                <span className="text-mute">
                  {subdetails ? subdetails.type : ""}
                </span>
                <span className="text-mute">·</span>
                <span className="text-mute">
                  <FaLock></FaLock>
                </span>
                <span className="text-mute">Private</span>
                <span>
                  <Link to="#" onClick={this.handleExpansion}>
                    ... show more
                  </Link>
                </span>
              </div>
              <div
                style={{
                  display: this.state.expanded ? "block" : "none"
                }}
              >
                <div className="sub-content-opening">
                  <span className="text-mute">
                    <FaRegClock></FaRegClock>
                  </span>
                  <span>Duration: </span>
                  <span>{subdetails ? subdetails.duration : "Not Set"} </span>
                </div>
                <div className="sub-content-opening">
                  <span className="text-mute">
                    <FaRegCalendarAlt></FaRegCalendarAlt>
                  </span>
                  <span className="text-mute">
                    {subdetails ? subdetails.date : "Not Set"}
                  </span>
                </div>
              </div>
            </Col>
            <Col xs={1} className="edit-flow text-mute">
              <Dropdown className="icon-dropdown">
                <Dropdown.Toggle
                  style={{ background: "transparent" }}
                  id="dropdown-basic"
                >
                  <IoMdCreate className="edit-icon text-mute"></IoMdCreate>
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  <Dropdown.Item as={Link} to="#">
                    Edit
                  </Dropdown.Item>
                  <Dropdown.Item
                    as={Link}
                    to="#"
                    style={{
                      display: this.props.stage === "Plain" ? "block" : "none"
                    }}
                  >
                    Convert to <em>Interview Stage</em>
                  </Dropdown.Item>
                  <Dropdown.Item
                    as={Link}
                    to="#"
                    style={{
                      display: this.props.stage === "Plain" ? "block" : "none"
                    }}
                  >
                    Convert to <em>Review Stage</em>
                  </Dropdown.Item>
                  <Dropdown.Item
                    as={Link}
                    to="#"
                    style={{
                      display:
                        this.props.stage === "Interview" ? "block" : "none"
                    }}
                  >
                    Convert to <em>Plain Stage</em>
                  </Dropdown.Item>
                  <Dropdown.Item
                    as={Link}
                    to="#"
                    onClick={() => this.props.deleteStage(this.props.id)}
                  >
                    Delete
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </Col>
          </Row>
        </div>
      )
    );
  }
}

const cardSource = {
  beginDrag(props) {
    return {
      index: props.index,
      listId: props.listId
    };
  },
};

const cardTarget = {
  hover(props, monitor, component) {
    const dragIndex = monitor.getItem().index;
    const hoverIndex = props.index;
    const sourceListId = monitor.getItem().listId;
    if (dragIndex === hoverIndex) {
      return;
    }
    const hoverBoundingRect = findDOMNode(component).getBoundingClientRect();
    const hoverMiddleY = (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2;
    const clientOffset = monitor.getClientOffset();
    const hoverClientY = clientOffset.y - hoverBoundingRect.top;
    if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
      return;
    }
    if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
      return;
    }
    if (props.listId === sourceListId) {
      props.moveCard(dragIndex, hoverIndex);
      monitor.getItem().index = hoverIndex;
    }
  }
};

export default flow(
  DropTarget("CARD", cardTarget, (connect, monitor) => ({
    connectDropTarget: connect.dropTarget(),
    hovered: monitor.isOver(),
    isOver: monitor.isOver(),
    canDrop: monitor.canDrop()
  })),
  DragSource("CARD", cardSource, (connect, monitor) => ({
    connectDragSource: connect.dragSource(),
    isDragging: monitor.isDragging()
  }))
)(InterviewStage);
