import React, { Component, Fragment } from "react";
import "./AddCandidate.css";
import {
  Form,
  Row,
  Col,
  Button,
  Tooltip,
  OverlayTrigger
} from "react-bootstrap";
import { Link } from "react-router-dom";
import { FaInfoCircle } from "react-icons/fa";
import { Formik } from "formik";
import { addCandidateValidationSchema } from "../../constant/formvalidator";
import { connect } from "react-redux";
import {
  mapDispatchToProps,
  candidateDispatchToProp
} from "../../constant/mapDispatchToProps";
import DatePicker from "react-datepicker";
import { generateRandomId } from "../../utils/commonFuntions";
class AddCandidate extends Component {
  render() {
    return (
      <Fragment>
        <div className="main-col" style={{ paddingBottom: "150px" }}>
          <div className="page-header">
            <div className="page-title-block-bleeding-left clearfix">
              <h1 className="page-title js-page-title">Add Candidate</h1>
            </div>
          </div>
          <Row>
            <Col sm={8}>
              <Formik
                initialValues={{
                  firstName: "",
                  lastName: "",
                  email: "",
                  phone: "",
                  dateOfBirth: "",
                  gender: "",
                  location: "",
                  joiningDate: "",
                  totalExpInYears: "",
                  totalExpInMonths: "",
                  releventExpInYears: "",
                  releventExpInMonths: "",
                  currentCTCInLakhs: "",
                  currentCTCInThousands: "",
                  expectedCTCInLakhs: "",
                  expectedCTCInThousands: "",
                  job:"",
                  opening:"",
                  stage:"screening",
                  source:"",
                  shortDescription:"",
                  file:null,
                  fileName:"",
                }}
                validationSchema={addCandidateValidationSchema}
                onSubmit={values => {
                  const id = generateRandomId();
                  const newValues = {
                    ...values,
                    ...{ assignedDate: new Date().toLocaleDateString(), id: id }
                  };
                  this.props.addCandidates(newValues);
                  this.props.history.push("/candidates");
                }}
              >
                {({
                  values,
                  errors,
                  touched,
                  handleChange,
                  handleSubmit,
                  setFieldValue,
                  isSubmitting
                }) => {
                  console.log(values);
                  return (
                    <Form onSubmit={handleSubmit}>
                      <Form.Group>
                        <h2>Upload a Resume</h2>
                        <div style={{ marginBottom: "10px" }}>
                          {" "}
                          Select a file to upload
                        </div>
                          <Form.Control
                            type="file"
                            placeholder="No File Choosen"
                            className="upload-file"
                            accept="application/pdf"
                            onChange={event => {
                              setFieldValue("file", event.currentTarget.files[0]);
                              setFieldValue("fileName",event.currentTarget.files[0].name);
                            }}
                          ></Form.Control>
                      </Form.Group>
                      <div style={{ marginTop: "50px" }}>
                        <h2>Candidate Details</h2>
                        <div style={{ marginBottom: "10px" }}>
                          {" "}
                          Upload a resume above to{" "}
                          <strong>auto-fill these details</strong>
                        </div>
                      </div>
                      <Row>
                        <Col sm={6}>
                          <Form.Group>
                            <Form.Label>First Name</Form.Label>
                            <Form.Control
                              name="firstName"
                              value={values.firstName}
                              onChange={handleChange}
                              type="text"
                              className={
                                touched.firstName && errors.firstName
                                  ? "error-input"
                                  : null
                              }
                            ></Form.Control>
                            {touched.firstName && errors.firstName ? (
                              <div className="error-message">
                                {errors.firstName}
                              </div>
                            ) : null}
                          </Form.Group>
                        </Col>
                        <Col sm={6}>
                          <Form.Group>
                            <Form.Label>Last Name</Form.Label>
                            <Form.Control
                              name="lastName"
                              value={values.lastName}
                              onChange={handleChange}
                              type="text"
                              className={
                                touched.lastName && errors.lastName
                                  ? "error-input"
                                  : null
                              }
                            ></Form.Control>
                            {touched.lastName && errors.lastName ? (
                              <div className="error-message">
                                {errors.lastName}
                              </div>
                            ) : null}
                          </Form.Group>
                        </Col>
                        <Col sm={6}>
                          <Form.Group>
                            <Form.Label>Email</Form.Label>
                            <Form.Control
                              name="email"
                              value={values.email}
                              onChange={handleChange}
                              type="email"
                              className={
                                touched.email && errors.email
                                  ? "error-input"
                                  : null
                              }
                            ></Form.Control>
                            {touched.email && errors.email ? (
                              <div className="error-message">
                                {errors.email}
                              </div>
                            ) : null}
                          </Form.Group>
                        </Col>
                        <Col sm={6}>
                          <Form.Group>
                            <Form.Label>Phone</Form.Label>
                            <Form.Control
                              name="phone"
                              value={values.phone}
                              type="number"
                              onChange={handleChange}
                              className={
                                touched.phone && errors.phone
                                  ? "error-input"
                                  : null
                              }
                            ></Form.Control>
                            {touched.phone && errors.phone ? (
                              <div className="error-message">
                                {errors.phone}
                              </div>
                            ) : null}
                          </Form.Group>
                        </Col>
                        <Col sm={6}>
                          <Form.Group>
                            <Form.Label>Date of Birth</Form.Label>
                            <DatePicker
                              name="dateOfBirth"
                              selected={values.dateOfBirth}
                              onChange={date =>
                                setFieldValue("dateOfBirth", date)
                              }
                              className={` ${
                                touched.dateOfBirth && errors.dateOfBirth
                                  ? "error-input"
                                  : null
                              } form-control`}
                            />
                            {touched.dateOfBirth && errors.dateOfBirth ? (
                              <div className="error-message">
                                {errors.dateOfBirth}
                              </div>
                            ) : null}
                          </Form.Group>
                        </Col>
                        <Col sm={6}>
                          <Form.Group>
                            <Form.Label>Gender</Form.Label>
                            <Form.Control
                              as="select"
                              value={values.gender}
                              name="gender"
                              onChange={handleChange}
                              className={
                                touched.gender && errors.gender
                                  ? "error-input"
                                  : null
                              }
                            >
                              <option value="" disabled>
                                Select an Gender
                              </option>
                              <option value="Male">Male</option>
                              <option value="Female">Female</option>
                            </Form.Control>
                            {touched.gender && errors.gender ? (
                              <div className="error-message">
                                {errors.gender}
                              </div>
                            ) : null}
                          </Form.Group>
                        </Col>
                        <Col sm={6}>
                          <Form.Group>
                            <Form.Label>
                              Location{" "}
                              <OverlayTrigger
                                placement={"top"}
                                overlay={
                                  <Tooltip
                                    id={`tooltip-${"top"}+${1}`}
                                    style={{ fontSize: "10px" }}
                                  >
                                    For remote positions, please provide your
                                    office location.
                                  </Tooltip>
                                }
                              >
                                <FaInfoCircle
                                  style={{ marginLeft: "5px" }}
                                  className="text-mute"
                                ></FaInfoCircle>
                              </OverlayTrigger>{" "}
                            </Form.Label>
                            <Form.Control
                              type="text"
                              placeholder="Enter a location"
                              name="location"
                              value={values.location}
                              onChange={handleChange}
                              className={
                                touched.location && errors.location
                                  ? "error-input"
                                  : null
                              }
                            ></Form.Control>
                            {touched.location && errors.location ? (
                              <div className="error-message">
                                {errors.location}
                              </div>
                            ) : null}
                          </Form.Group>
                        </Col>
                        <Col sm={6}>
                          <Form.Group>
                            <Form.Label>Joining Date</Form.Label>
                            <DatePicker
                              name="joiningDate"
                              selected={values.joiningDate}
                              onChange={date =>
                                setFieldValue("joiningDate", date)
                              }
                              className={` ${
                                touched.joiningDate && errors.joiningDate
                                  ? "error-input"
                                  : null
                              } form-control`}
                            />
                            {touched.joiningDate && errors.joiningDate ? (
                              <div className="error-message">
                                {errors.joiningDate}
                              </div>
                            ) : null}
                          </Form.Group>
                        </Col>
                        <Col sm={6}>
                          <Form.Group>
                            <Form.Label>Total Experience</Form.Label>
                            <Row>
                              <Col sm={6}>
                                <Form.Control
                                  as="select"
                                  value={values.totalExpInYears}
                                  name="totalExpInYears"
                                  onChange={handleChange}
                                  className={
                                    touched.totalExpInYears &&
                                    errors.totalExpInYears
                                      ? "error-input"
                                      : null
                                  }
                                >
                                  <option value="" disabled>
                                    Years
                                  </option>
                                  <option value="1 Year">1 Year</option>
                                  <option value="2 Years">2 Years</option>
                                </Form.Control>
                                {touched.totalExpInYears &&
                                errors.totalExpInYears ? (
                                  <div className="error-message">
                                    {errors.totalExpInYears}
                                  </div>
                                ) : null}
                              </Col>
                              <Col sm={6}>
                                <Form.Control
                                  as="select"
                                  value={values.totalExpInMonths}
                                  name="totalExpInMonths"
                                  onChange={handleChange}
                                  className={
                                    touched.totalExpInMonths &&
                                    errors.totalExpInMonths
                                      ? "error-input"
                                      : null
                                  }
                                >
                                  <option value="" disabled>
                                    Months
                                  </option>
                                  <option value="1 Month">1 Month</option>
                                  <option value="2 Months">2 Months</option>
                                </Form.Control>
                                {touched.totalExpInMonths &&
                                errors.totalExpInMonths ? (
                                  <div className="error-message">
                                    {errors.totalExpInMonths}
                                  </div>
                                ) : null}
                              </Col>
                            </Row>
                          </Form.Group>
                        </Col>
                        <Col sm={6}>
                          <Form.Group>
                            <Form.Label>Relevent Experience</Form.Label>
                            <Row>
                              <Col sm={6}>
                                <Form.Control
                                  as="select"
                                  value={values.releventExpInYears}
                                  name="releventExpInYears"
                                  onChange={handleChange}
                                  className={
                                    touched.releventExpInYears &&
                                    errors.releventExpInYears
                                      ? "error-input"
                                      : null
                                  }
                                >
                                  <option value="" disabled>
                                    Years
                                  </option>
                                  <option value="1 Year">1 Year</option>
                                  <option value="2 Years">2 Years</option>
                                </Form.Control>
                                {touched.releventExpInYears &&
                                errors.releventExpInYears ? (
                                  <div className="error-message">
                                    {errors.releventExpInYears}
                                  </div>
                                ) : null}
                              </Col>
                              <Col sm={6}>
                                <Form.Control
                                  as="select"
                                  value={values.releventExpInMonths}
                                  name="releventExpInMonths"
                                  onChange={handleChange}
                                  className={
                                    touched.releventExpInMonths &&
                                    errors.releventExpInMonths
                                      ? "error-input"
                                      : null
                                  }
                                >
                                  <option value="" disabled>
                                    Months
                                  </option>
                                  <option value="1 Month">1 Month</option>
                                  <option value="2 Months">2 Months</option>
                                </Form.Control>
                                {touched.releventExpInMonths &&
                                errors.releventExpInMonths ? (
                                  <div className="error-message">
                                    {errors.releventExpInMonths}
                                  </div>
                                ) : null}
                              </Col>
                            </Row>
                          </Form.Group>
                        </Col>
                        <Col sm={6}>
                          <Form.Group>
                            <Form.Label>Current CTC</Form.Label>
                            <Row>
                              <Col sm={6}>
                                <Form.Control
                                  as="select"
                                  value={values.currentCTCInLakhs}
                                  name="currentCTCInLakhs"
                                  onChange={handleChange}
                                  className={
                                    touched.currentCTCInLakhs &&
                                    errors.currentCTCInLakhs
                                      ? "error-input"
                                      : null
                                  }
                                >
                                  <option value="" disabled>
                                    Lakhs
                                  </option>
                                  <option value="0 Lakhs">0 Lakhs</option>
                                  <option value="1 Lakhs">1 Lakhs</option>
                                  <option value="2 Lakhs">2 Lakhs</option>
                                </Form.Control>
                                {touched.currentCTCInLakhs &&
                                errors.currentCTCInLakhs ? (
                                  <div className="error-message">
                                    {errors.currentCTCInLakhs}
                                  </div>
                                ) : null}
                              </Col>
                              <Col sm={6}>
                                <Form.Control
                                  as="select"
                                  value={values.currentCTCInThousands}
                                  name="currentCTCInThousands"
                                  onChange={handleChange}
                                  className={
                                    touched.currentCTCInThousands &&
                                    errors.currentCTCInThousands
                                      ? "error-input"
                                      : null
                                  }
                                >
                                  <option value="" disabled>
                                    Thousand
                                  </option>
                                  <option value="0 Thousand">0 Thousand</option>
                                  <option value="5 Thousand">5 Thousand</option>
                                  <option value="10 Thousand">
                                    10 Thousand
                                  </option>
                                </Form.Control>
                                {touched.currentCTCInThousands &&
                                errors.currentCTCInThousands ? (
                                  <div className="error-message">
                                    {errors.currentCTCInThousands}
                                  </div>
                                ) : null}
                              </Col>
                            </Row>
                          </Form.Group>
                        </Col>
                        <Col sm={6}>
                          <Form.Group>
                            <Form.Label>Expected CTC</Form.Label>
                            <Row>
                              <Col sm={6}>
                                <Form.Control
                                  as="select"
                                  value={values.expectedCTCInLakhs}
                                  name="expectedCTCInLakhs"
                                  onChange={handleChange}
                                  className={
                                    touched.expectedCTCInLakhs &&
                                    errors.expectedCTCInLakhs
                                      ? "error-input"
                                      : null
                                  }
                                >
                                  <option value="" disabled>
                                    Lakhs
                                  </option>
                                  <option value="0 Lakhs">0 Lakhs</option>
                                  <option value="1 Lakhs">1 Lakhs</option>
                                  <option value="2 Lakhs">2 Lakhs</option>
                                </Form.Control>
                                {touched.expectedCTCInLakhs &&
                                errors.expectedCTCInLakhs ? (
                                  <div className="error-message">
                                    {errors.expectedCTCInLakhs}
                                  </div>
                                ) : null}
                              </Col>
                              <Col sm={6}>
                                <Form.Control
                                  as="select"
                                  value={values.expectedCTCInThousands}
                                  name="expectedCTCInThousands"
                                  onChange={handleChange}
                                  className={
                                    touched.expectedCTCInThousands &&
                                    errors.expectedCTCInThousands
                                      ? "error-input"
                                      : null
                                  }
                                >
                                  <option value="" disabled>
                                    Thousand
                                  </option>
                                  <option value="0 Thousand">0 Thousand</option>
                                  <option value="5 Thousand">5 Thousand</option>
                                  <option value="10 Thousand">
                                    10 Thousand
                                  </option>
                                </Form.Control>
                                {touched.expectedCTCInThousands &&
                                errors.expectedCTCInThousands ? (
                                  <div className="error-message">
                                    {errors.expectedCTCInThousands}
                                  </div>
                                ) : null}
                              </Col>
                            </Row>
                          </Form.Group>
                        </Col>
                      </Row>
                      <div style={{ marginTop: "50px" }}>
                        <h2>Assign to</h2>
                      </div>
                      <Row>
                        <Col sm={6}>
                          <Form.Group>
                            <Form.Label>Job</Form.Label>
                            <Form.Control
                              as="select"
                              value={values.job}
                              name="job"
                              onChange={handleChange}
                              className={
                                touched.job && errors.job ? "error-input" : null
                              }
                            >
                              <option value="" disabled>
                                Select a Job
                              </option>
                              <option value="Business Development Manager">
                                Business Development Manager
                              </option>
                              <option value="iOS Developer">
                                iOS Developer
                              </option>
                              <option value="QA">QA</option>
                              <option value="Android Developer">
                                Android Developer
                              </option>
                            </Form.Control>
                            {touched.job && errors.job ? (
                              <div className="error-message">{errors.job}</div>
                            ) : null}
                          </Form.Group>
                        </Col>
                        <Col sm={6}>
                          <Form.Group>
                            <Form.Label>Opening</Form.Label>
                            <Form.Control
                              as="select"
                              disabled
                              value={values.opening}
                              name="opening"
                              onChange={handleChange}
                            >
                              <option value="" disabled>
                                Select a Opening
                              </option>
                              <option value="1">1</option>
                              <option value="2">2</option>
                              <option value="3">3</option>
                              <option value="4">4</option>
                            </Form.Control>
                            {touched.opening && errors.opening ? (
                              <div className="error-message">
                                {errors.opening}
                              </div>
                            ) : null}
                          </Form.Group>
                        </Col>
                        <Col sm={6}>
                          <Form.Group>
                            <Form.Label>Stage</Form.Label>
                            <Form.Control
                              as="select"
                              disabled
                              value={values.stage}
                              name="stage"
                              onChange={handleChange}
                            >
                              <option value="" disabled>
                                Select a Stage
                              </option>
                              <option value="screening">Screening</option>
                              <option value="telephonic interview">
                                Telephonic Interview
                              </option>
                              <option value="face to face interview">
                                Face to Face interview
                              </option>
                              <option value="selected">Selected</option>
                            </Form.Control>
                          </Form.Group>
                        </Col>
                        <Col sm={6}>
                          <Form.Group>
                            <Form.Label>Source of the candidate</Form.Label>
                            <Form.Control
                              as="select"
                              value={values.source}
                              name="source"
                              onChange={handleChange}
                              className={
                                touched.source && errors.source
                                  ? "error-input"
                                  : null
                              }
                            >
                              <option value="" disabled>
                                Select a Source
                              </option>
                              <option value="Indeed">Indeed</option>
                              <option value="Linkedin">Linkedin</option>
                              <option value="Naukari">Naukari</option>
                            </Form.Control>
                            {touched.source && errors.source ? (
                              <div className="error-message">
                                {errors.source}
                              </div>
                            ) : null}
                          </Form.Group>
                        </Col>
                        <Col sm={12}>
                          <Form.Group>
                            <Form.Label>Short Description</Form.Label>
                            <p className="text-mute">
                              Write a short note describing the candidate,
                              especially if you are not uploading a resume.
                            </p>
                            <Form.Control
                              as="textarea"
                              rows="3"
                              value={values.shortDescription}
                              name="shortDescription"
                              onChange={handleChange}
                            />
                          </Form.Group>
                        </Col>
                      </Row>
                      <div className="form-action">
                        <Button
                          type="submit"
                          variant="primary"
                          style={{ marginRight: "10px" }}
                        >
                          Create candidate
                        </Button>
                        <Link to="#" className="btn btn-default">
                          {" "}
                          Cancel{" "}
                        </Link>
                      </div>
                    </Form>
                  );
                }}
              </Formik>
            </Col>
          </Row>
        </div>
      </Fragment>
    );
  }
}
export default connect(
  null,
  mapDispatchToProps([candidateDispatchToProp])
)(AddCandidate);
