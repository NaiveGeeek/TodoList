import React, { Component } from "react";
import { Calendar, momentLocalizer, Views } from "react-big-calendar";
import moment from "moment";
import { connect } from "react-redux";
import { mapStateToProps, calandarStateToProps } from "../../constant/mapStateToProps";
import { mapDispatchToProps, showHideModalDispatchToProps ,calandarDispatchToProps, asyncApiCallDispatchToProps} from "../../constant/mapDispatchToProps";
import { CREATE_EVENT_MODAL, DELETE_EVENT_MODAL } from "../../constant/modaltypes";
import { generateRandomId } from "../../utils/commonFuntions";
import { HTTP_METHOD } from "../../constant/httpMethods";
import { calendarEventsList } from "../../actions/calandarAction";

class Calender extends Component {
  closeModal = () => {
   this.props.nodisplayModal();
  };
  openModal =({ start, end }) => {
    let modalObject = {
      modalType: CREATE_EVENT_MODAL,
      modalProps: {
        open: true,
        closeModal: this.closeModal,
        start,
        end,
        id:generateRandomId(),
        addEvents:this.props.addEvents
      }
    };
    this.props.displayModal(modalObject);
  };
  openDeleteModal =(event)=>{
    let modalObject = {
      modalType: DELETE_EVENT_MODAL,
      modalProps: {...event,
        deleteEvents:this.props.deleteEvents,
        editEvents:this.props.editEvents,
        closeModal: this.closeModal,
        open:true
      }
    };
    this.props.displayModal(modalObject);
  }
  componentDidMount(){
    this.props.apiCall("http://www.mocky.io/v2/5e4279ed2f00004c0087f5e7",HTTP_METHOD.GET,{},{},calendarEventsList);
}

  render() {
    const localizer = momentLocalizer(moment);
    const {calandarState}=this.props; 
    return (
      <div className="main-col list-page">
        <Calendar
          localizer={localizer}
          selectable
          events={calandarState.calandarEvents}
          defaultView={Views.WEEK}
          defaultDate={new Date()}
          style={{height:"500px"}}
          onSelectSlot={this.openModal}
          views={{ month: true, week: true,day:true }}
          onSelectEvent={(event)=>{this.openDeleteModal(event)}}
        ></Calendar>
      </div>
    );
  }
}

export default connect(mapStateToProps([calandarStateToProps]),mapDispatchToProps([showHideModalDispatchToProps,calandarDispatchToProps,asyncApiCallDispatchToProps])) (Calender);
