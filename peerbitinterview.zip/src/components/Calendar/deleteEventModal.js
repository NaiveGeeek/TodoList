import React, { Component } from "react";
import { formatTimeToAMPM } from "../../utils/commonFuntions";
import { Modal, Form, Row, Col } from "react-bootstrap";
import { FaRegClock } from "react-icons/fa";
import DatePicker from "react-datepicker";

class DeleteEventModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isEditingEvent: false,
      title: this.props.modalProps.title,
      description: this.props.modalProps.description,
      startDate: this.props.modalProps.start,
      endDate: this.props.modalProps.end
    };
  }
  handleChange = event => {
    const name = event.target.name;
    this.setState({
      [name]: event.target.value
    });
  };
  handelEditClose = () => {
    this.setState({
      isEditingEvent: false
    });
  };
  handelEditClick = () => {
    this.setState({
      isEditingEvent: true
    });
  };
  handleEditSave = ({ id, editEvents, closeModal }) => {
    const newObject = {
      id,
      start: this.state.startDate,
      end: this.state.endDate,
      title: this.state.title,
      description: this.state.description
    };
    editEvents(newObject);
    closeModal();
  };
  deleteEvent = ({ id, deleteEvents, closeModal }) => {
    deleteEvents(id);
    closeModal();
  };
  render() {
    const { modalProps } = this.props;
    const startDate =
      modalProps.start.toDateString() +
      " " +
      formatTimeToAMPM(modalProps.start);
    const endDate =
      modalProps.end.toDateString() + " " + formatTimeToAMPM(modalProps.end);
    return (
      <Modal
        show={modalProps.open}
        centered
        onHide={() => modalProps.closeModal()}
      >
        <Modal.Body style={{ padding: 0 }}>
          <Form>
            <div
              style={{
                display: this.state.isEditingEvent ? "none" : "block"
              }}
            >
              <Row className="padding-1rem " style={{ margin: "10px 0px" }}>
                <Col xs={3}>
                  <span>
                    <strong>Title : </strong>
                  </span>
                </Col>
                <Col xs={9}>{modalProps.title}</Col>
              </Row>
              <Row className="padding-1rem" style={{ margin: "5px 0px" }}>
                <Col xs={3}>
                  <FaRegClock></FaRegClock>
                </Col>
                <Col xs={9}>{startDate + " - " + endDate}</Col>
              </Row>
              <Row className="padding-1rem" style={{ margin: "10px 0px" }}>
                <Col xs={3}>
                  <span>
                    <strong>Description : </strong>
                  </span>
                </Col>
                <Col xs={9}>{modalProps.description}</Col>
              </Row>
            </div>
            <div
              style={{
                display: this.state.isEditingEvent ? "block" : "none"
              }}
            >
              <Row className="padding-1rem " style={{ margin: "10px 0px" }}>
                <Col xs={3} className="edit-calander-event-modal">
                  <span>
                    <strong>Title : </strong>
                  </span>
                </Col>
                <Col xs={9}>
                  <Form.Control
                    type="text"
                    name="title"
                    value={this.state.title}
                    onChange={this.handleChange}
                  ></Form.Control>
                </Col>
              </Row>
              <Row className="padding-1rem " style={{ margin: "10px 0px" }}>
                <Col xs={3} className="edit-calander-event-modal">
                  <span>
                    <strong> Start Date : </strong>
                  </span>
                </Col>
                <Col xs={9}>
                  <DatePicker
                    selected={this.state.startDate}
                    onChange={date =>
                      this.setState({
                        startDate: date
                      })
                    }
                    className="form-control"
                    showTimeSelect
                    timeFormat="HH:mm"
                    timeIntervals={30}
                    timeCaption="time"
                    dateFormat="MMMM d, yyyy h:mm aa"
                    maxDate={this.state.endDate}
                  ></DatePicker>
                </Col>
              </Row>
              <Row className="padding-1rem " style={{ margin: "10px 0px" }}>
                <Col xs={3} className="edit-calander-event-modal">
                  <span>
                    <strong> End Date : </strong>
                  </span>
                </Col>
                <Col xs={9}>
                  <DatePicker
                    selected={this.state.endDate}
                    onChange={date =>
                      this.setState({
                        endDate: date
                      })
                    }
                    className="form-control"
                    showTimeSelect
                    timeFormat="HH:mm"
                    timeIntervals={30}
                    timeCaption="time"
                    dateFormat="MMMM d, yyyy h:mm aa"
                    minDate={this.state.startDate}
                  ></DatePicker>
                </Col>
              </Row>
              <Row className="padding-1rem " style={{ margin: "10px 0px" }}>
                <Col xs={3} className="edit-calander-event-modal">
                  <span>
                    <strong>Description : </strong>
                  </span>
                </Col>
                <Col xs={9}>
                  <Form.Control
                    name="description"
                    as="textarea"
                    rows={3}
                    onChange={this.handleChange}
                    value={this.state.description}
                  ></Form.Control>
                </Col>
              </Row>
            </div>
            <div className="stage-edit-form-buttons clearfix">
              <div
                style={{
                  display: this.state.isEditingEvent ? "none" : "block"
                }}
              >
                <button
                  type="button"
                  className="btn btn-danger pull-right save-btn"
                  onClick={() => {
                    this.deleteEvent(modalProps);
                  }}
                >
                  Delete
                </button>
                <button
                  type="button"
                  className="btn btn-info pull-right hide-non-interview-button"
                  style={{ marginRight: "10px" }}
                  onClick={this.handelEditClick}
                >
                  Edit
                </button>
                <button
                  type="button"
                  className="btn btn-default pull-right hide-non-interview-button"
                  style={{ marginRight: "10px" }}
                  onClick={() => {
                    modalProps.closeModal();
                  }}
                >
                  Cancel
                </button>
              </div>
              <div
                style={{
                  display: this.state.isEditingEvent ? "block" : "none"
                }}
              >
                <button
                  type="button"
                  className="btn btn-primary pull-right save-btn"
                  onClick={() => {
                    this.handleEditSave(modalProps);
                  }}
                >
                  Save
                </button>
                <button
                  type="button"
                  className="btn btn-default pull-right hide-non-interview-button"
                  style={{ marginRight: "10px" }}
                  onClick={this.handelEditClose}
                >
                 Go Back
                </button>
              </div>
            </div>
          </Form>
        </Modal.Body>
      </Modal>
    );
  }
}

export default DeleteEventModal;
