import React, { Component } from "react";
import "./login.css";
import { Image, Container, Form, Button } from "react-bootstrap";
import logo from "../../assets/logo.png";
import { Link, Redirect } from "react-router-dom";
import { isUserAuthorized } from "../../utils/commonFuntions";
import { toast } from "react-toastify";
import { connect } from "react-redux";
import { Formik } from "formik";
import { loginSchema } from "../../constant/formvalidator";
import { mapDispatchToProps, loginDispatchToProps } from "../../constant/mapDispatchToProps";

class Login extends Component {
  render() {
    if (isUserAuthorized()) {
      return <Redirect to="/"></Redirect>;
    }
    return (
      <div className="loginContainer">
        <div className="loginHeader">
          <Image src={logo} alt="company logo"></Image>
          <h1 className="loginHeaderText">
            Log in to your PeerRecruiter account
          </h1>
        </div>
        <Container className="formContainer">
          <Formik
            initialValues={{
              email: "",
              password: "",
              keepmeLoggedin: false
            }}
            validationSchema={loginSchema}
            onSubmit={values => {
              const isEmailValid = values.email === "abc@gmail.com";
              const isPasswordValid = values.password === "123456";
              if (isEmailValid && isPasswordValid) {
                const user = {
                  id: 1,
                  name: "Nasrullah patel",
                  userType: "admin"
                };
                localStorage.setItem("token", "peerbits");
                this.props.userDetails(user);
                this.props.history.push("/");
              } else {
                toast.error("Invalid username Password");
              }
            }}
          >
            {({
              values,
              errors,
              touched,
              handleChange,
              handleSubmit,
              isSubmitting
            }) => {
              return (
                <Form onSubmit={handleSubmit}>
                  <Form.Group controlId="emailId">
                    <Form.Control
                      name="email"
                      type="email"
                      placeholder="Email"
                      value={values.email}
                      onChange={handleChange}
                      className={
                        touched.email && errors.email ? "error-input" : null
                      }
                    />
                    {touched.email && errors.email ? (
                      <div className="error-message">{errors.email}</div>
                    ) : null}
                  </Form.Group>
                  <Form.Group controlId="password">
                    <Form.Control
                      type="password"
                      name="password"
                      placeholder="Password"
                      value={values.password}
                      onChange={handleChange}
                      className={
                        touched.password && errors.password
                          ? "error-input"
                          : null
                      }
                    />
                    {touched.password && errors.password ? (
                      <div className="error-message">{errors.password}</div>
                    ) : null}
                  </Form.Group>
                  <Form.Group controlId="checkbox">
                    <Form.Check
                      type="checkbox"
                      name="keepmeLoggedin"
                      label="Keep me logged in"
                      checked={values.keepmeLoggedin}
                      onChange={handleChange}
                    />
                  </Form.Group>
                  <Button
                    variant="primary"
                    type="submit"
                    block
                  >
                    Log in
                  </Button>
                </Form>
              );
            }}
          </Formik>
          <div className="cannotLogin">
            <Link to="/forgot_password"> can not login?</Link>
          </div>
        </Container>
        <Button className="signupBtn">
          <Link to="/signup" className="signupLink">
            Don't have an account? Sign up{" "}
          </Link>
        </Button>
      </div>
    );
  }
}

export default connect(null, mapDispatchToProps([loginDispatchToProps]))(Login);
