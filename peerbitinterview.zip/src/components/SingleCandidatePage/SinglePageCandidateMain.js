import React, { Component } from "react";
import { Link, withRouter } from "react-router-dom";
import { mapStateToProps,candidateStateToProps } from "../../constant/mapStateToProps";
import { connect } from "react-redux";
import {  mapDispatchToProps, candidateDispatchToProp} from "../../constant/mapDispatchToProps";

class SinglePageCandidateMain extends Component {
  constructor(props){
    super(props);
    this.state={}
    this.id=null;
  }
  componentDidMount(){
    const { match: { params } } = this.props;
    this.id = params.id;
    const candidateObject = this.props.candidateState.candidates.filter((element)=>
      (element.id+"") === params.id);
    if(candidateObject.length!==0){
      this.setState({
        ...candidateObject[0]
      });
    }  
  }
  handleUploadResume=(event)=>{
    const file = event.target.files[0];
    const fileData = {file:file,
     fileName:file.name  
    }
    this.setState(
      {...this.state,...fileData},()=>{
        this.props.editCandidates(this.state)}
    )
    
      
  }
  handleUploadDocument=(event)=>{
    const file = event.target.files[0];
    const fileData = {document:file,
     documentName:file.name  
    }
    this.setState(
      {...this.state,...fileData},()=>{this.props.editCandidates(this.state)}
    )
  }
  render() {
    return (
      <div className="main-col">
        <div className="page-title-block-bleeding-left clearfix">
          <h1 className="page-title">
            {this.state.firstName} {this.state.lastName}{" "}
          </h1>
        </div>
        <section className="dashboard-section dashboard-list-group-wrapper">
          <div className="section-heading">
            <Link to={`/edit_candidate/candidates/${this.id}`} className="pull-right">
              Edit
            </Link>
            <h2 className="heading">Profile</h2>
          </div>
          <div className="dashboard-list-group">
            <table className="table">
              <colgroup>
                <col width="25%"></col>
                <col width="75%" />
              </colgroup>
              <tbody>
                <tr>
                  <td className="text-muted">First Name</td>
                  <td>{this.state.firstName}</td>
                </tr>
                <tr>
                  <td className="text-muted">Last Name</td>
                  <td>{this.state.lastName}</td>
                </tr>
                <tr>
                  <td className="text-muted">Email</td>
                  <td>{this.state.email}</td>
                </tr>
                <tr>
                  <td className="text-muted">Phone</td>
                  <td>{this.state.phone}</td>
                </tr>
                <tr>
                  <td className="text-muted">Date of Birth</td>
                  <td>{this.state.dateOfBirth && (typeof this.state.dateOfBirth) !=="string"?this.state.dateOfBirth.toDateString():this.state.dateOfBirth}</td>
                </tr>
                <tr>
                  <td className="text-muted">Gender</td>
                  <td>{this.state.gender}</td>
                </tr>
                <tr>
                  <td className="text-muted">Status</td>
                  <td>
                    <i className="glyphicon glyphicon-ok text-success"></i>{" "}
                    Active
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>
        <section className="dashboard-section dashboard-list-group-wrapper">
          <div className="section-heading">
            <Link to={`/edit_candidate/candidates/${this.id}`}className="pull-right">
              Edit
            </Link>
            <h2 className="heading">Candidate Details</h2>
          </div>
          <div className="dashboard-list-group">
            <table className="table">
              <colgroup>
                <col width="25%" />
                <col width="75%" />
              </colgroup>
              <tbody>
                <tr>
                  <td className="text-muted">Joining Date</td>
                  <td>{ this.state.joiningDate && (typeof this.state.joiningDate) !=="string"?this.state.joiningDate.toDateString():this.state.joiningDate}</td>
                </tr>
                <tr>
                  <td className="text-muted">Location</td>
                  <td>{this.state.location}</td>
                </tr>
                <tr>
                  <td className="text-muted">Total Experience</td>
                  <td>
                    {this.state.totalExpInYears} {this.state.totalExpInMonths}
                  </td>
                </tr>
                <tr>
                  <td className="text-muted">Relevant Experience</td>
                  <td>
                    {this.state.releventExpInYears} {this.state.releventExpInMonths}
                  </td>
                </tr>
                <tr>
                  <td className="text-muted">Current CTC</td>
                  <td>
                    Rs.{this.state.currentCTCInLakhs} {this.state.currentCTCInThousands}
                  </td>
                </tr>
                <tr>
                  <td className="text-muted">Job</td>
                  <td>{this.state.job}</td>
                </tr>
                <tr>
                  <td className="text-muted">Source</td>
                  <td>{this.state.source}</td>
                </tr>
                <tr>
                  <td className="text-muted">Description</td>
                  <td>{this.state.shortDescription}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>
        <section className="dashboard-section dashboard-list-group-wrapper">
          <div className="section-heading">
            <input type="file" accept="application/pdf" className="unique-file-upload" id="fileupload" onChange={this.handleUploadResume}></input>
            <label htmlFor="fileupload" className="btn btn-primary pull-right upload-document"> +Add Resume</label>
            <h2 className="heading">Resume</h2>
          </div>
          <div className="dashboard-list-group">
            <div className="dashboard-section-empty text-muted">
            {this.state.fileName?this.state.fileName:"There is no resume for this candidate."} 
            </div>
          </div>
        </section>
        <section className="dashboard-section dashboard-list-group-wrapper">
          <div className="section-heading">
          <input type="file" accept="application/pdf" className="unique-file-upload" id="documentupload" onChange={this.handleUploadDocument}></input>
            <label htmlFor="documentupload" className="btn btn-primary pull-right upload-document"> +Add Document</label>
            <h2 className="heading">Document</h2>
          </div>
          <div className="dashboard-list-group">
            <div className="dashboard-section-empty text-muted">
              {this.state.documentName?this.state.documentName:"There is no document for this candidate."} 
            </div>
          </div>
        </section>
      </div>
    );
  }
}
export default connect(mapStateToProps([candidateStateToProps]), mapDispatchToProps([candidateDispatchToProp]))(withRouter(SinglePageCandidateMain));
