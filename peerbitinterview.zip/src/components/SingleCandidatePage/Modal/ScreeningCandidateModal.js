import React, { Component } from 'react'
import { Modal, Form } from 'react-bootstrap';

class ScreeningCandidateModal extends Component {
    constructor(props){
        super(props);
        this.state={
            review:""
        }
    }
    handleChange =(event)=>{
        const name =event.target.name;
        this.setState({
            [name]:event.target.value
        })
    }
    render() {
        return (
            <Modal show={this.props.modalProps.open} size="lg" backdrop="static">
                <Modal.Body style={{ padding: 0 }}>
                    <Form>
                        <div className="modal-form-container">
                        <Form.Group>
                            <Form.Label>Review</Form.Label>
                            <Form.Control type="text" name="review" value={this.state.value} onChange={this.handleChange} ></Form.Control>
                        </Form.Group>
                        </div>
                        <div className="stage-edit-form-buttons clearfix">
                            <button type="submit" className="btn btn-primary pull-right save-btn">Save</button>
                            <button type="button" className="btn btn-default pull-right hide-non-interview-button" style={{marginRight:"10px"}} onClick={()=>{this.props.modalProps.closeModal();}}>Cancel</button>
                        </div>
                    </Form>
                </Modal.Body>

            </Modal>
        )
    }
}
export default ScreeningCandidateModal