import React, { Component } from "react";
import "./SingleCandidatePage.css";
import SinglePageCandidateMain from "./SinglePageCandidateMain";
import SingleCandidatePageSidebar from "./SingleCandidatePageSidebar";



class SingleCandidatePage extends Component {
  render(){
    return(
      <div
      className="clearfix equal-height-content"
      style={{ minHeight: "532px" }}
    >
      <SingleCandidatePageSidebar></SingleCandidatePageSidebar>
      <SinglePageCandidateMain></SinglePageCandidateMain>
      </div>
    )
  }
}

export default  (SingleCandidatePage)