import React, { Component, Fragment } from 'react';
import { Route} from 'react-router-dom';
import { privateEditOpeningRoute } from '../../constant/Routing/Routing';
import { connect } from 'react-redux';
import { mapStateToProps, openingStateToProps } from '../../constant/mapStateToProps';
import { mapDispatchToProps, openingsStagesDispatchToProps } from '../../constant/mapDispatchToProps';


class EditOpening extends Component {
    constructor(props){
        super(props);
        this.id = null;
        this.state={}
    }
     componentDidMount(){
        const {match:{params}}=this.props;
        this.id=params.id;
        const openingObject = this.props.openingState.overview.filter((element)=>
         (element.id+"") === this.id);
         if(openingObject.length!==0){
             this.setState({
                 ...openingObject[0]
             })
         }else{
             this.props.history.push("/openings");
         }
        }
    saveEditOpening = () => {
        this.props.editOpeningSecondSteps(this.state);
      };
      updateState = data => {
        this.setState({
          ...this.state, 
          ...data
        });
      };
      render() {
        return (
          <Fragment>
            {privateEditOpeningRoute.map((routeProps, index) => {
              const { path, component: Component, exact } = routeProps;
              return (
                <Route
                  key={index}
                  path={path}
                  exact={exact ? true : false}
                  render={props => (
                    <Component
                      {...props}
                      opening= {this.state}
                      updateParentState={this.updateState}
                      saveEditOpening={this.saveEditOpening}
                    ></Component>
                  )}
                />
              );
            })}
          </Fragment>
        );
      }
}

export default connect(mapStateToProps([openingStateToProps]),mapDispatchToProps([openingsStagesDispatchToProps]))(EditOpening);