import React, { Component } from 'react'
import { Modal, Form } from 'react-bootstrap';
import "./ScreeningModal.css";
class ScreeningModal extends Component {
    constructor(props){
        super(props);
        this.state={
            screening:'',
            coordinator:' ',
        }
    }
    handleChange=(event)=>{
        const target = event.target;
        this.setState({
            [target.name]:target.value,
        })
    }
    render() {
        return (
          <Modal show={this.props.modalProps.open} size="lg" centered backdrop="static">
            <Modal.Body style={{padding:0}}>
               <Form>
                   <Form.Group className="padding-1rem" style={{marginTop:"1rem"}}>
                       <Form.Control name= "screening"type="text" placeholder="Screening" value={this.state.screening} onChange={this.handleChange}></Form.Control>
                   </Form.Group>
                   <Form.Group className="padding-1rem">
                        <Form.Label><strong>Coordinator</strong></Form.Label>
                            <Form.Control as="select" name="coordinator" value={this.state.job} onChange={this.handleChange}>
                                     <option value=" " disabled>Select a Person...</option>
                                     <option value="1">Abdulhannan</option>
                                     <option value="2">Mohsin</option>
                                     <option value="3">Taufiq</option>
                            </Form.Control>
                    </Form.Group>
                    <div className="stage-edit-form-buttons clearfix">
                        <button type="submit" className="btn btn-primary pull-right save-btn">Save</button>
                        <button type="button" className="btn btn-default pull-right hide-non-interview-button" style={{marginRight:"10px"}} onClick={()=>{this.props.modalProps.closeModal();}}>Cancel</button>
                    </div>
               </Form>
            </Modal.Body>
          </Modal>
        )
    }
}

export default ScreeningModal