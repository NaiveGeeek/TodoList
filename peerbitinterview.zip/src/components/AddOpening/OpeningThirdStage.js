import React, { Component } from "react";
import { Link } from "react-router-dom";
import { Row, Col, Dropdown, Button } from "react-bootstrap";
import arrow from "../../assets/arrow.svg";
import { DndProvider } from "react-dnd";
import HTML5Backend from "react-dnd-html5-backend";
import MultiBackend, { TouchTransition } from "react-dnd-multi-backend";
import update from "immutability-helper";
import TouchBackend from "react-dnd-touch-backend";

import { FaRegCalendarAlt, FaListAlt } from "react-icons/fa";
// import {
//   OPENING_STAGE_SCREENING_MODAL,
//   OPENING_STAGE_TELEPHONIC_MODAL
// } from "../../constant/modaltypes";

import { generateRandomId } from "../../utils/commonFuntions";
import InterviewStage from "../../reusableComponent/interviewStage/interviewStage";

const HTML5toTouch = {
  backends: [
    {
      backend: HTML5Backend
    },
    {
      backend: TouchBackend,
      options: { enableMouseEvents: true }, // Note that you can call your backends with options
      preview: false,
      transition: TouchTransition
    }
  ]
};

class OpeningThirdStage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      interviewStages:this.props.interviewStages, 
  }
}
  deleteStage = id => {
    const updatedList = this.state.interviewStages.filter(element => {
      return element.id !== id;
    });
    this.setState({
      interviewStages: updatedList
    });
  };
  addPlainStage = () => {
    const plainstage = {
      id: generateRandomId(),
      title: "Plain Stage",
      coordinator: "Nasrullah",
      stage: "Plain",
      candidates: 0
    };
    this.setState({
      interviewStages: [...this.state.interviewStages, plainstage]
    });
  };
  addInterviewStage = () => {
    const interviewStage = {
      id: generateRandomId(),
      title: "Interview Stage",
      coordinator: "Nasrullah",
      stage: "Interview",
      candidates: 0,
      subdetails: {
        interviewers: ["You"],
        type: "Telephone (Direct Call)",
        duration: "45 minutes",
        date: "12/02/2020 13:45:00"
      }
    };
    this.setState({
      interviewStages: [...this.state.interviewStages, interviewStage]
    });
  };
  //on move div update the state accordingly
  moveCard = (dragIndex, hoverIndex) => {
    const list = this.state.interviewStages;
    const dragCard = list[dragIndex];
    this.setState(
      update(this.state, {
        interviewStages: {
          $splice: [
            [dragIndex, 1],
            [hoverIndex, 0, dragCard]
          ]
        }
      })
    );
  };

  getInterviewStageElements = () => {
    const elements = this.state.interviewStages.map((element,index) => {
      return (
        <InterviewStage
          key={element.id}
          {...element}
          deleteStage={this.deleteStage}
          moveCard={this.moveCard}
          index= {index}
        ></InterviewStage>
      );
    });
    return elements;
  };
  // handleExpansion = event => {
  //   const target = event.target;
  //   this.setState({
  //     [target.name]: !this.state[target.name]
  //   });
  // };
  closeModal = () => {
    this.props.nodisplayModal();
  };
  openModal = name => {
    let payload = {
      modalType: name,
      modalProps: {
        open: true,
        closeModal: this.closeModal
      }
    };
    this.props.displayModal(payload);
  };
  handleSubmit = () => {
    this.props.updateParentState(this.state);
    this.props.history.push({
      pathname: "/add_opening/opening_creation_success",
    });
  };
  render() {
    return (
      <div className="main-col">
        <div className="page-header">
          <div className="page-title-block-bleeding-left clearfix">
            <h1 className="page-title">
              Set up your hiring workflow for the opening{" "}
            </h1>
            <div className="js-steps-bar">
              <ol className="process-step-bar">
                <li className="process-step-item">1. Create Opening</li>
                <li className="process-step-item">2. Opening Details</li>
                <li className="process-step-item process-step-item-current">
                  3. Hiring Workflow
                </li>
              </ol>
            </div>
          </div>
        </div>
        <div className="main-col-inner opening-stages-edit">
          <Row>
            <Col sm={7} className="stages-col">
              <div className="new-candidate  space-on-top-20px">
                <i className="icon icon-candidate-gray"></i>
                <span>New Candidate</span>
                <div className="horizontal"></div>
                <div className="vertical"></div>
              </div>
              <div className="first-stage-row">
                <DndProvider backend={MultiBackend} options={HTML5toTouch}>
                {this.getInterviewStageElements()}
                </DndProvider>
              </div>
              <Dropdown className="add-a-stage">
                <Dropdown.Toggle id="dropdown-basic">
                  + Add a Stage
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  <Dropdown.Item
                    as={Link}
                    to="#"
                    onClick={this.addInterviewStage}
                  >
                    <FaRegCalendarAlt></FaRegCalendarAlt> Interview Stage
                  </Dropdown.Item>
                  <Dropdown.Item as={Link} to="#" onClick={this.addPlainStage}>
                    <FaListAlt></FaListAlt> Review Stage
                  </Dropdown.Item>
                  <hr style={{ margin: 0 }}></hr>
                  <Dropdown.Item as={Link} to="#" onClick={this.addPlainStage}>
                    Plain Stage
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
              {/* hired container  */}
              <div className="hired-container">
                <div className="vertical-bottom"></div>
                <div className="state-circle state-circle-success text-center">
                  <div className="state-name">
                    <span>&nbsp;Hired</span>
                  </div>
                </div>
              </div>
            </Col>
            <Col sm={2} className="text-center">
              <img
                className="hiring-setup-arrow"
                src={arrow}
                alt="arrow sign"
              ></img>
            </Col>
            <Col sm={3}>
              <div className="reject-state-container">
                <div className="states-wrapper">
                  <div className="state-wrapper state-rejected">
                    <div className="state-name">Rejected</div>
                  </div>
                  <div className="state-wrapper state-onhold">
                    <div className="state-name">On Hold</div>
                  </div>
                  <div className="state-wrapper state-archived">
                    <div className="state-name">Archived</div>
                  </div>
                  <div className="state-wrapper state-withdrew">
                    <div className="state-name">Candidate Withdrew</div>
                  </div>
                  <div className="state-wrapper state-declinedoffer">
                    <div className="state-name">Declined Offer</div>
                  </div>
                </div>
              </div>
            </Col>
          </Row>
        </div>
        <div className="form-action">
          <Link to="/add_opening/openings_details" className="btn btn-default">
            <span className="big-text">«</span> Back
          </Link>
          <Button
            onClick={this.handleSubmit}
            className="btn btn-primary pull-right"
          >
            Next <span className="big-text">»</span>
          </Button>
        </div>
      </div>
    );
  }
}
export default (OpeningThirdStage);
