import React, { Component } from "react";
import { Link } from "react-router-dom";
import { Button } from "react-bootstrap";

 class OpeningLastStage extends Component {
   onSubmit=()=>{
     this.props.createOpening();
     this.props.history.push("/openings");
   }
  render() {
    console.log(this.props);
    return (
      <div className="main-col">
        <div className="page-header">
          <div className="page-title-block-bleeding-left clearfix">
            <h1 className="page-title">We're done! </h1>
          </div>
        </div>
        <div className="form-action">
          <Link to="/add_opening/openings_stages" className="btn btn-default">
            <span className="big-text">«</span> Back
          </Link>
          <Button
            type="button"
            className="btn btn-primary pull-right"
            onClick ={this.onSubmit}
          >
            View Opening Details <span className="big-text">»</span>
          </Button>
        </div>
      </div>
    );
  }
}
export default OpeningLastStage;