import React, { Component, Fragment } from "react";
import { generateRandomId } from "../../utils/commonFuntions";
import { privateAddOpeningRoute } from "../../constant/Routing/Routing";
import { Route } from "react-router-dom";
import { connect } from "react-redux";
import {
  mapDispatchToProps,
  openingsStagesDispatchToProps
} from "../../constant/mapDispatchToProps";

class AddOpening extends Component {
  constructor(props) {
    super(props);
    this.state = {
      id: generateRandomId(),
      openingTitle: "",
      job: "",
      openingType: "",
      totalExpInYears: "",
      totalExpInMonths: "",
      location: "",
      jobDescription: "",
      interviewStages: [
        {
          id: generateRandomId(),
          title: "Screening",
          coordinator: "Nasrullah",
          stage: "Plain",
          candidates: 0
        },
        {
          id: generateRandomId(),
          title: "Telephone Interview",
          coordinator: "Nasrullah",
          stage: "Interview",
          candidates: 0,
          subdetails: {
            interviewers: ["You"],
            type: "Telephone (Direct Call)",
            duration: "45 minutes",
            date: "12/02/2020 13:45:00"
          } 
        },
        {
          id: generateRandomId(),
          title: "Face to face Interview",
          coordinator: "Nasrullah",
          stage: "Interview",
          candidates: 0,
          subdetails: {
            interviewers: ["You"],
            type: "Face to Face",
            duration: "45 minutes",
            date: "12/02/2020 15:45:00"
          }
        },
        {
          id: generateRandomId(),
          title: "Make Offer",
          coordinator: "Nasrullah",
          stage: "Plain",
          candidates: 0
        }
      ]
    };
  }
  createOpening = () => {
    this.props.createOpenings(this.state);
  };
  updateState = data => {
    this.setState({
      ...this.state,
      ...data
    });
  };
  render() {
    return (
      <Fragment>
        {privateAddOpeningRoute.map((routeProps, index) => {
          const { path, component: Component, exact } = routeProps;
          return (
            <Route
              key={index}
              path={path}
              exact={exact ? true : false}
              render={props => (
                <Component
                  {...props}
                  {...this.state}
                  updateParentState={this.updateState}
                  createOpening={this.createOpening}
                ></Component>
              )}
            />
          );
        })}
      </Fragment>
    );
  }
}

export default connect(
  null,
  mapDispatchToProps([openingsStagesDispatchToProps])
)(AddOpening);
