import React, { Component } from "react";
import { Row, Col, Form, Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import "./AddOpening.css";

class OpeningFirstStep extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openingTitle: "",
      job: ""
    };
  }
  handleChane = event => {
    const name = event.target.name;
    this.setState({
      [name]: event.target.value
    });
  };
  handleSubmit = () => {
    const updatedOpening = {
      ...this.state,
      coordinator: "Nasrullah",
      candidates: 0,
      isDataIncomplete: true
    };
    this.props.updateParentState(updatedOpening);
    this.props.history.push({
      pathname: "/add_opening/openings_details",
    });
  };
  render() {
    return (
      <div className="main-col">
        <div className="page-header">
          <div className="page-title-block-bleeding-left clearfix">
            <h1 className="page-title">
              Set up your hiring workflow for the opening{" "}
            </h1>
            <div className="js-steps-bar">
              <ol className="process-step-bar">
                <li className="process-step-item process-step-item-current">
                  1. Create Opening
                </li>
                <li className="process-step-item ">2. Opening Details</li>
                <li className="process-step-item">3. Hiring Workflow</li>
              </ol>
            </div>
          </div>
        </div>
        <Row>
          <Col xs={8}>
            <Form>
              <Row>
                <Col xs={6}>
                  <Form.Group>
                    <Form.Label>Opening Title</Form.Label>
                    <Form.Control
                      name="openingTitle"
                      value={this.state.openingTitle}
                      onChange={this.handleChane}
                      type="text"
                    ></Form.Control>
                  </Form.Group>
                </Col>
              </Row>

              <Row>
                <Col xs={6}>
                  <Form.Group>
                    <Form.Label>Job</Form.Label>
                    <Form.Control
                      name="job"
                      value={this.state.job}
                      onChange={this.handleChane}
                      as="select"
                    >
                      <option value="" disabled>
                        Select a Job
                      </option>
                      <option value="Business Development Manager">
                        Business Development Manager
                      </option>
                      <option value="iOS Developer">iOS Developer</option>
                      <option value="QA">QA</option>
                      <option value="Android Developer">
                        Android Developer
                      </option>
                    </Form.Control>
                  </Form.Group>
                </Col>
              </Row>
              <div className="form-action">
                <Button
                  type="buttton"
                  onClick={this.handleSubmit}
                  variant="primary"
                  style={{ marginRight: "10px" }}
                >
                  Create Opening
                </Button>
                <Link to="/openings" className="btn btn-default">
                  {" "}
                  Cancel{" "}
                </Link>
              </div>
            </Form>
          </Col>
        </Row>
      </div>
    );
  }
}

export default (OpeningFirstStep);
