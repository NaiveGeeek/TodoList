import React, { Component, Fragment } from "react";
import NavbarPage from "../Navbar/NavbarPage";
import { privateAppRoute } from "../../constant/Routing/Routing";
import { Route } from "react-router-dom";

class Home extends Component {
  render() {
    return (
      <Fragment>
        <NavbarPage {...this.props}></NavbarPage>
        {privateAppRoute.map((routeProps, index) => (
          <Route key={index} {...routeProps} />
        ))}
      </Fragment>
    );
  }
}

export default Home;
