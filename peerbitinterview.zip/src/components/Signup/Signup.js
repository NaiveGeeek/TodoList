import React, { Component } from "react";
import { Image, Container, Form, Button } from "react-bootstrap";
import "./Signup.css";
import logo from "../../assets/logo.png";
import { Link, Redirect } from "react-router-dom";
import { isUserAuthorized } from "../../utils/commonFuntions";
import { Formik } from "formik";
import { signupSchema } from "../../constant/formvalidator";

class Signup extends Component {
  render() {
    if (isUserAuthorized()) {
      return <Redirect to="/"></Redirect>;
    }
    return (
      <div className="signupContainer">
        <div className="signupHeader">
          <Image src={logo} alt="company logo"></Image>
          <h1 className="signupHeaderText">
            Sign up for Free &amp; set up your hiring today
          </h1>
        </div>
        <Container className="formContainer">
          <Formik
            initialValues={{
              name: "",
              email: "",
              password: "",
              phoneNumber: ""
            }}
            validationSchema={signupSchema}
            onSubmit={values => {
              console.log(values);
            }}
          >
            {({
              values,
              errors,
              touched,
              handleChange,
              handleSubmit,
            }) => {
                console.log(values);
                console.log(errors);
              return (
                <Form onSubmit={handleSubmit}>
                  <Form.Group controlId="fullname">
                    <Form.Control
                      name="name"
                      type="text"
                      placeholder="Your Full Name"
                      value={values.name}
                      onChange={handleChange}
                      className={
                        touched.name && errors.name ? "error-input" : null
                      }
                    />
                    {touched.name && errors.name ? (
                      <div className="error-message">{errors.name}</div>
                    ) : null}
                  </Form.Group>

                  <Form.Group controlId="emailId">
                    <Form.Control
                      name="email"
                      type="email"
                      placeholder="Your Work Email"
                      value={values.email}
                      onChange={handleChange}
                      className={
                        touched.email && errors.email ? "error-input" : null
                      }
                    />
                    {touched.email && errors.email ? (
                      <div className="error-message">{errors.email}</div>
                    ) : null}
                  </Form.Group>
                  <Form.Group controlId="password">
                    <Form.Control
                      type="password"
                      name="password"
                      placeholder="Choose A Password"
                      value={values.password}
                      onChange={handleChange}
                      className={
                        touched.password && errors.password
                          ? "error-input"
                          : null
                      }
                    />
                    {touched.password && errors.password ? (
                      <div className="error-message">{errors.password}</div>
                    ) : null}
                  </Form.Group>
                  <Form.Group controlId="phoneNumber">
                    <Form.Control
                      type="number"
                      name="phoneNumber"
                      placeholder="Your Phone Number"
                      value={values.phoneNumber}
                      onChange={handleChange}
                      className={
                        touched.phoneNumber && errors.phoneNumber
                          ? "error-input"
                          : null
                      }
                    />
                    {touched.phoneNumber && errors.phoneNumber ? (
                      <div className="error-message">{errors.phoneNumber}</div>
                    ) : null}
                  </Form.Group>
                  <Button variant="primary" type="submit" block>
                    Create account &amp; Get started
                  </Button>
                </Form>
              );
            }}
          </Formik>
          <div className="cannotsignup">No obligation, cancel anytime</div>
        </Container>
        <p className="content-box-outer">
          By signing up, you agree to our{" "}
          <Link to="/signup">Terms of Service</Link>
        </p>
        <Button className="loginBtn">
          <Link to="/login" className="loginLink">
            Already have an account? Log in{" "}
          </Link>
        </Button>
      </div>
    );
  }
}

export default Signup;
