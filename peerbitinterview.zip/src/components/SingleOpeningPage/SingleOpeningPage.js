import React, { Component } from 'react';
import SingleOpeningSidebar from './SingleOpeningSidebar';
import SingleOpeningMain from './SingleOpeningMain';
import { mapStateToProps, openingStateToProps } from '../../constant/mapStateToProps';
import { connect } from 'react-redux';

class SingleOpeningPage extends Component {
    constructor(props){
        super(props);
        this.state={};
        this.id=null;
    }
    componentDidMount(){
        const {match:{params}}=this.props;
        this.id=params.id;
        const openingObject = this.props.openingState.overview.filter((element)=>
         (element.id+"") === this.id);
         if(openingObject.length!==0){
             this.setState({
                 ...openingObject[0]
             })
         }else{
             this.props.history.push("/openings");
         }
    }
    render() {
        return (
            <div className="equal-height-content">
                <SingleOpeningSidebar id={this.id}></SingleOpeningSidebar>
                <SingleOpeningMain {...this.state} ></SingleOpeningMain>
            </div>
        )
    }
}
export default connect(mapStateToProps([openingStateToProps]))(SingleOpeningPage)