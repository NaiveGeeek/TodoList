import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { FaSuitcase } from 'react-icons/fa';
import { Dropdown } from 'react-bootstrap';
class OpeningSideBar extends Component {
    render() {
        return (
            <div className="sidebar sidebar-colored">
                        <aside className="sidebar-item list-sidebar-create">
                            <Link to="/add_opening" className="btn btn-default btn-create btn-with-icon">
                                <FaSuitcase className="text-mute"></FaSuitcase>  <span className="button-span-text"> Create Opening</span>
                            </Link>
                        </aside>
                        <aside className="sidebar-item">
                            <ul className="sidebar-list sidebar-nav list-unstyled">
                                <li><Link to="/openings" >Overview</Link></li>
                                <li><Link to="/openings/assigned_to_me" >Assigned to me</Link></li>
                                <li><Link to="/openings/all_openings">All Accessible Openings</Link></li>
                                <hr></hr>
                                <li><Link to="/openings" >Drafts</Link></li>
                                <li><Link to="/openings" >Published</Link></li>
                                <li><Link to="/openings" >Used Internally</Link></li>
                                <li><Link to="/openings" >Not Acceptting Candidates</Link></li>
                                <li><Link to="/openings/archived" >Archived</Link></li>
                                <li><Link to="/openings/private" >Private</Link></li>
                                <hr></hr>
                                <li>
                                    <Dropdown>
                                        <Dropdown.Toggle id="dropdown-basic" >
                                            Filtered By Users
                                    </Dropdown.Toggle>
                                        <Dropdown.Menu className="dropdown-menu" >
                                            <Link to="/openings" >IT Support<span className="text-mute"> (2)</span></Link>
                                            <Link to="/openings" >mohsin<span className="text-mute"> (2)</span></Link>
                                            <Link to="/openings" >You<span className="text-mute"> (6)</span></Link>
                                        </Dropdown.Menu>
                                    </Dropdown>
                                </li>
                                <li>
                                    <Dropdown>
                                        <Dropdown.Toggle variant="success" id="dropdown-basic">
                                            Filtered By Tags
                                    </Dropdown.Toggle>
                                        <Dropdown.Menu className="dropdown-menu">
                                        </Dropdown.Menu>
                                    </Dropdown>
                                </li>
                            </ul>
                        </aside>

                    </div>
        )
    }
}
export default OpeningSideBar