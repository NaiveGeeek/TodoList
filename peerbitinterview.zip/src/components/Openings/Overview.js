import React, { Component } from 'react'
import { Row, Col, OverlayTrigger, Tooltip } from 'react-bootstrap';
import "./Overview.css"
import { Link } from 'react-router-dom';
import { IoIosWarning } from "react-icons/io"
import { connect } from 'react-redux';
import { mapStateToProps, openingStateToProps } from '../../constant/mapStateToProps';
import { mapDispatchToProps, asyncApiCallDispatchToProps } from '../../constant/mapDispatchToProps';
import { HTTP_METHOD } from '../../constant/httpMethods';
import { openingOverview } from '../../actions/openingAction';

class Overview extends Component {
    getCardElements = () => {
        const elements = this.props.openingState.overview.map((data, index) => {
            return (
                <Col key={index} xs={12} sm={4}>
                    <div className="dashboard-tile">
                        <h3>
                            <Link to={`/single_page_opening_view/openings/${data.id}`} className="dashboard-tile-header">
                                {data.isDataIncomplete ? <span className="incomplete-details-warning">
                                    <OverlayTrigger
                                        placement={"top"}
                                        overlay={
                                            <Tooltip id={`tooltip-${"top"}+${index}`} style={{fontSize:"10px"}}>
                                               This opening has incomplete details.
                                              </Tooltip>
                                        }
                                    ><IoIosWarning></IoIosWarning></OverlayTrigger>
                                    </span> : null}
                                <div className="dashboard-tile-title long-text-ellipsis">{data.openingTitle} </div>

                            </Link>
                        </h3>
                        <div className="dashboard-tile-info">
                            <div className="dashboard-tile-info-row">
                                <span className="text-mute">Assigned Users:</span>{data.coordinator}
                            </div>
                            <div className="dashboard-tile-info-row">
                                <span className="text-mute">Location:</span>{data.location}
                            </div>
                            <div className="dashboard-tile-candidates">
                                <Link to="#" className="link-pill">{data.candidates} candidates</Link>
                            </div>
                        </div>
                    </div>
                </Col>
            )
        });
        return elements;
    }
    componentDidMount(){
        this.props.apiCall("http://www.mocky.io/v2/5e44df353000007426614679",HTTP_METHOD.GET,{},{},openingOverview);
    }
    render() {
        return (
            <div className="main-col">
                <div className="list-page-without-actions">
                    <section className="dashboard-section">
                        <h1 className="list-section-heading">Overview</h1>
                        <Row style={{ display: "flex" }}>
                            {this.getCardElements()}
                        </Row>
                    </section>
                </div>
            </div>

        )
    }
}
export default connect(mapStateToProps([openingStateToProps]),mapDispatchToProps([asyncApiCallDispatchToProps]))(Overview)
