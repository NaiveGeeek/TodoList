import React, { Component } from 'react'
import RingLoader from 'react-spinners/RingLoader'

class Loading extends Component {
    render() {
        return (
           <RingLoader></RingLoader>
        )
    }
}

export default Loading;