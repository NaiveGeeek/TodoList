import React, { Component, Fragment } from "react";
import "./CandidateOverview.css";
import {
  Row,
  Col,
  Table,
  Dropdown,
  ButtonGroup,
  Button
} from "react-bootstrap";
import { Link } from "react-router-dom";
import { IoIosRefresh } from "react-icons/io";
import { connect } from "react-redux";
import {
  mapStateToProps,
  candidateStateToProps
} from "../../constant/mapStateToProps";

class CandidateOverview extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showDropDown: true
    };
  }
  getRowElements = () => {
    const elements = this.props.candidateState.candidates.map((data, index) => {
      return (
        <Fragment key={data.id}>
          <tr className="custom-table-row">
            <td>
              <label className="checkbox-label">
                <input type="checkbox"></input>
                <span className="checkbox-custom"></span>
              </label>
            </td>
            <td>
              <Link to={{pathname:`/single_page_view_candidate/candidates/${data.id}`}}>{data.firstName+" "+data.lastName}</Link>
            </td>
            <td>
              <Link to={{pathname:`/single_page_view_candidate/candidates/${data.id}`}}>{data.job}</Link>
            </td>
            <td>
              <span className="text-mute">{data.stage}</span>
            </td>
            <td>
              <span className="text-mute">{data.assignedDate}</span>
            </td>
          </tr>
        </Fragment>
      );
    });
    return elements;
  };
  render() {
    return (
      <div>
        <Row className="action-elements">
          <Col className="sub-action-elements" xs={6} sm={3} md={1}>
            <label className="checkbox-label">
              <input type="checkbox"></input>
              <span className="checkbox-custom"></span>
            </label>
            <span>All </span>
          </Col>
          <Col xs={6} sm={3} md={3} className="sub-action-elements">
            <button className="custom-button-style">Add Label</button>
            <button className="custom-button-style">Send Message</button>
          </Col>
          <Col xs={6} sm={3} md={2} className="sub-action-elements">
            <Dropdown className="custom-dropdown">
              <Dropdown.Toggle id="dropdown-basic-1">
                Move to Stage
              </Dropdown.Toggle>
              <Dropdown.Menu>
                <Dropdown.Item as={Link} to="#">
                  Screening
                </Dropdown.Item>
                <Dropdown.Item as={Link} to="#">
                  Telephone Interview
                </Dropdown.Item>
                <Dropdown.Item as={Link} to="#">
                  Face to Face Interview
                </Dropdown.Item>
                <Dropdown.Item as={Link} to="#">
                  Make Offer
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </Col>
          <Col xs={6} sm={3} md={2} className="sub-action-elements">
            <Dropdown as={ButtonGroup} className="custom-dropdown">
              <Button style={{ width: "300%" }}>Select Action</Button>
              <Dropdown.Toggle
                split
                variant="success"
                id="dropdown-split-basic"
              />
              <Dropdown.Menu>
                <Dropdown.Item as={Link} to="#">
                  Reject
                </Dropdown.Item>
                <Dropdown.Item as={Link} to="#">
                  Put On Hold
                </Dropdown.Item>
                <Dropdown.Item as={Link} to="#">
                  Candidate Withdrew
                </Dropdown.Item>
                <Dropdown.Item as={Link} to="#">
                  Candidate declined offer
                </Dropdown.Item>
                <hr style={{ margin: 0 }}></hr>
                <Dropdown.Item as={Link} to="#">
                  Archive
                </Dropdown.Item>
                <hr style={{ margin: 0 }}></hr>
                <Dropdown.Item as={Link} to="#">
                  Mark as Spam
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </Col>
          <Col xs={6} sm={3} md={1} className="sub-action-elements">
            <Dropdown className="custom-dropdown">
              <Dropdown.Toggle id="dropdown-basic-2">More</Dropdown.Toggle>
              <Dropdown.Menu>
                <Dropdown.Item as={Link} to="#">
                  Move to different opening
                </Dropdown.Item>
                <Dropdown.Item as={Link} to="#">
                  Delete
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </Col>
          <Col xs={6} sm={3} md={1} className="sub-action-elements pull-right">
            <button
              className="custom-button-style"
              style={{ width: "35px", padding: 0 }}
            >
              <IoIosRefresh style={{ fontSize: "18px" }}></IoIosRefresh>
            </button>
          </Col>
        </Row>
        <div className="action-table">
          <div className="action-table-heading">
            <h1>Overview</h1>
          </div>
          <Table responsive borderless>
            <tbody>{this.getRowElements()}</tbody>
          </Table>
        </div>
      </div>
    );
  }
}

export default connect(mapStateToProps([candidateStateToProps]))(
  CandidateOverview
);
