import dashboardStore from "../reducers/Dashboard/dashboardReducer";
import { combineReducers,applyMiddleware,createStore,compose } from "redux";
import thunk from "redux-thunk";
import modalState from "../reducers/Modal/ModalReducer";
import loginState from "../reducers/Login/loginreducer";
import openingState from "../reducers/Openings/openingReducer";
import candidateState from "../reducers/Candidate/candidateReducer";
import calandarState from "../reducers/Calandar/calandarReducer"
const reducers = combineReducers({dashboardStore,modalState,loginState,openingState,candidateState,calandarState});
const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
const store = createStore(reducers,composeEnhancers(applyMiddleware(thunk)));
export default store;