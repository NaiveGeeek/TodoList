import { ADD_EVENTS_TO_CALENDAR,DELETE_EVENTS_FROM_CALENDAR, CALENDAR_EVENTS_LIST, EDIT_EVENTS_TO_CALENDAR } from "../constant/actiontypes";

export const addEventsToCalandar=(data)=>{
    return{
        type:ADD_EVENTS_TO_CALENDAR,
        payload:data
    }
}
export const deleteEventsFromCalandar =(id)=>{
    return{
        type:DELETE_EVENTS_FROM_CALENDAR,
        id:id
    }
}
export const calendarEventsList =(data)=>{
    return {
        type:CALENDAR_EVENTS_LIST,
        payload:data
    }
}
export const editEventToCalendar =(data)=>{
    return {
        type:EDIT_EVENTS_TO_CALENDAR,
        payload:data
    }
}