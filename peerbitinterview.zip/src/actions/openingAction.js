import { OPENING_OVERVIEW_LIST, OPENING_ASSIGNED_TO_ME, OPENING_ALL, CREATE_OPENING, EDIT_OPENING_SECOND_STEP, EDIT_OPENING_THIRD_STEP } from "../constant/actiontypes";

export const openingOverview=(data)=>{
    return{
    type:OPENING_OVERVIEW_LIST,
    payload:data
}}

export const openingAssignedToMe= (data)=>({
    type:OPENING_ASSIGNED_TO_ME,
    payload:data
})
export const openingAll = (data)=>({
    type:OPENING_ALL,
    payload:data
})

export const createOpening =(data)=>({
    type:CREATE_OPENING,
    payload:data
})
export const editOpeningSecondStep = (data)=>({
    type:EDIT_OPENING_SECOND_STEP,
    payload:data
})

export const editOpeningThirdStep = (data)=>({
    type:EDIT_OPENING_THIRD_STEP,
    payload:data
})
