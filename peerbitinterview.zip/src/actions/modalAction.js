import {SHOW_MODAL,HIDE_MODAL} from "../constant/actiontypes"

export const showModal = (data) =>({
      type: SHOW_MODAL,
      modalProps:data.modalProps,
      modalType:data.modalType
    }
)
  
  export const hideModal = () => dispatch => {
    dispatch({
      type: HIDE_MODAL
    })
  }