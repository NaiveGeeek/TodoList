import {SET_USER_LOGIN_DETAILS} from "../constant/actiontypes";

export const setUserDetails = (user)=>({
    type:SET_USER_LOGIN_DETAILS,
    payload:user
})