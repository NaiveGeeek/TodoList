import {SET_USER_LOGIN_DETAILS} from '../../constant/actiontypes'
const initialState={
    user:{
        id:1,
        name:"Nasrullah patel",
        userType:"admin"
    }
}
const LoginReducer= (state = initialState, action)=>{
 switch(action.type){
     case SET_USER_LOGIN_DETAILS:
         return {...state,user:action.payload}
     default:
         return {...state}
 }
}
export default LoginReducer