import {
  OPENING_OVERVIEW_LIST,
  OPENING_ASSIGNED_TO_ME,
  OPENING_ALL,
  CREATE_OPENING,
  EDIT_OPENING_THIRD_STEP,
  EDIT_OPENING_SECOND_STEP
} from "../../constant/actiontypes";
import { removeDuplicateFromArray } from "../../utils/commonFuntions";

const initialState = {
  overview: [],
  allOpenings: [],
  assignedToMe: [],
};
const OpeningReducer = (state = initialState, action) => {
  switch (action.type) {
    case OPENING_OVERVIEW_LIST: {
      //these two line can be removed once the apis will be ready
      let updatedState = [...state.overview,...action.payload];
      updatedState = removeDuplicateFromArray(updatedState);
      return { ...state, overview:updatedState };
    }
    case OPENING_ASSIGNED_TO_ME: {
      //these two line can be removed once the apis will be ready
      let updatedState = [...state.assignedToMe,...action.payload];
      updatedState = removeDuplicateFromArray(updatedState);
      return { ...state, assignedToMe: updatedState };
    }
    case OPENING_ALL: {
      //these two line can be removed once the apis will be ready
      let updatedState = [...state.allOpenings,...action.payload];
      updatedState = removeDuplicateFromArray(updatedState);
      return { ...state, allOpenings:updatedState };
    }
    case CREATE_OPENING: {
      return {
        ...state,
        overview: [...state.overview, action.payload],
        allOpenings: [...state.allOpenings, action.payload],
        assignedToMe: [...state.assignedToMe, action.payload]
      };
    }
    case EDIT_OPENING_SECOND_STEP: {
      /*as of now all(overview allOpenings, assignedTome) have same data so*/
      const updatedValue = state.overview.map(element => {
        if (element.id === action.payload.id) {
          element = { ...element, ...action.payload };
        }
        return element;
      });
      return {
        ...state,
        overview: updatedValue,
        allOpenings: updatedValue,
        assignedToMe: updatedValue
      };
    }
    case EDIT_OPENING_THIRD_STEP: {
      const updatedValue = state.overview.map(element => {
        if (element.id === action.payload.id) {
          element.interviewStages = action.payload.interviewStages;
        }
        return element;
      });
      return {
        ...state,
        overview: updatedValue,
        allOpenings: updatedValue,
        assignedToMe: updatedValue
      };
    }
    default: {
      return { ...state };
    }
  }
};
export default OpeningReducer;
