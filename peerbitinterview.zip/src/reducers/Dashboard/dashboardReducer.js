import { GET_ASSIGNED_INTERVIEWS, GET_THINGS_TO_FOLLOW_UP, GET_TODOS } from "../../constant/actiontypes";
const initialState = {
  assignedInterview: [],
  thingsToFollowUp:[],
  todo:[]
};

const dashboardStore = (state = initialState, action) => {
  switch (action.type) {
    case GET_ASSIGNED_INTERVIEWS:
      return { ...state, assignedInterview: [action.payload] };
    case GET_THINGS_TO_FOLLOW_UP:
          return {...state,thingsToFollowUp:[action.payload]};
    case GET_TODOS:
        return { ...state, todo: [action.payload]};
    default:
      return { ...state };
  }
};

export default dashboardStore;