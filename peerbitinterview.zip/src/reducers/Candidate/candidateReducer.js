import { CANDIADTE_OVERVIEW_LIST, ADD_CANDIDATE, EDIT_CANDIDATE } from "../../constant/actiontypes"
import { filterItemBasedOnIdFromArray } from "../../utils/commonFuntions";

const initialState={
    candidates:[{
        id:1,
        firstName:"Adil",
        lastName:"Khan",
        email:"adil@gmail.com",
        phone:"9876543210",
        dateOfBirth:"01/01/1993",
        gender:"Male",
        location:"Ahmedabad",
        joiningDate:"01/01/2019",
        totalExpInYears:"2 years",
        totalExpInMonths:"2 months",
        releventExpInYears:"2 years",
        releventExpInMonths:"2 months",
        currentCTCInLakhs:"1 Lakhs",
        currentCTCInThousands:"5 Thousand",
        expectedCTCInLakhs: "2 Lakhs",
        expectedCTCInThousands: "10 Thousand",
        job:"IOS Developer",
        opening:1,
        stage:"screening",
        source:"Naukari",
        description:"",
        assignedDate:"01/01/2020",
        file:null,
        fileName:'',
        document:null,
        documentName:'',
    },{
        id:2,
        firstName:"Safina",
        lastName:"Khan",
        email:"safina@gmail.com",
        phone:"9876543210",
        dateOfBirth:"01/05/1993",
        gender:"Female",
        location:"Ahmedabad",
        joiningDate:"01/02/2018",
        totalExpInYears:"2 years",
        totalExpInMonths:"2 months",
        releventExpInYears:"2 years",
        releventExpInMonths:"2 months",
        currentCTCInLakhs:"1 Lakhs",
        currentCTCInThousands:"5 Thousand",
        expectedCTCInLakhs: "2 Lakhs",
        expectedCTCInThousands: "10 Thousand",
        job:"Android Developer",
        opening:2,
        stage:"screening",
        source:"Naukari",
        description:"",
        assignedDate:"16/01/2020",
        file:null,
        fileName:'',
        document:null,
        documentName:'',
    },
]

}
 const CandidateReducer =(state=initialState,action)=>{
    switch(action.type){
     case CANDIADTE_OVERVIEW_LIST:{
         return {...state,candidates:action.payload}
     }
     case ADD_CANDIDATE:{
         return {...state,candidates:[...state.candidates,action.payload]}
     }
     case EDIT_CANDIDATE:{
        const updatedCandidates = filterItemBasedOnIdFromArray(action.payload.id,state.candidates);
        return {...state,candidates:[...updatedCandidates,action.payload]}
     }
     default:{
         return {...state}
     }
    }
}
export default CandidateReducer;