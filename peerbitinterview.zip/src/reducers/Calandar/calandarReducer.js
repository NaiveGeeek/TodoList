import { ADD_EVENTS_TO_CALENDAR, DELETE_EVENTS_FROM_CALENDAR, CALENDAR_EVENTS_LIST, EDIT_EVENTS_TO_CALENDAR } from "../../constant/actiontypes";
import { filterItemBasedOnIdFromArray, generateDateObjectFromString } from "../../utils/commonFuntions";

const initialState ={
    calandarEvents:[]
}

const CalandarReducer =(state = initialState,action)=>{
    switch(action.type){
        case ADD_EVENTS_TO_CALENDAR:{
            return {...state,calandarEvents:[...state.calandarEvents,action.payload]}
        }
        case DELETE_EVENTS_FROM_CALENDAR:{
            const updatedEvents = filterItemBasedOnIdFromArray(action.id,state.calandarEvents);
            return {...state,calandarEvents:updatedEvents}
        }
        case CALENDAR_EVENTS_LIST:{
            const updatedEvents = generateDateObjectFromString(action.payload);
            return {...state,calandarEvents:updatedEvents}
        }
        case EDIT_EVENTS_TO_CALENDAR :{
            const updatedEvents = filterItemBasedOnIdFromArray(action.payload.id,state.calandarEvents);
            return {...state,calandarEvents:[...updatedEvents,action.payload]}
        }
        default:
            return {...state}
    }
}

export default CalandarReducer;