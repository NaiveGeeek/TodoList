import React from "react";
import "./App.css";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import { Provider } from "react-redux";
import store from "./Store/index";
import ModalContainer from "./Container/ModalContainer";
import SecuredRoute from "./securedRoutes";
import { ToastContainer } from "react-toastify";
import Home from "./components/Home/Home";
import { appRoute } from "./constant/Routing/Routing";

function App() {
  return (
    <Provider store={store}>
      <ToastContainer
        position="top-right"
        autoClose={2000}
        hideProgressBar={true}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnVisibilityChange
        draggable
        pauseOnHover
      ></ToastContainer>
      <Router>
         <Switch>
         {appRoute.map((routeProps, index) => (
            <Route key={index} {...routeProps} />
          ))}
          <SecuredRoute  path="/" component={Home}></SecuredRoute>
          </Switch>
        <ModalContainer></ModalContainer>
      </Router>
    </Provider>
  );
}

export default App;
