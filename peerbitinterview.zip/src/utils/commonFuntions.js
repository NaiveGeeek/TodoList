export const isUserAuthorized = () => {
  const token = localStorage.getItem("token");
  return token === "peerbits" ? true : false;
};

export const generateRandomId = () => {
  return (
    "_" +
    Math.random()
      .toString(36)
      .substr(2, 9)
  );
};

export const formatTimeToAMPM = date => {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? "PM" : "AM";
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? "0" + minutes : minutes;
  var strTime = hours + ":" + minutes + " " + ampm;
  return strTime;
};

export const filterItemBasedOnIdFromArray = (id, array) => {
  if (Array.isArray(array)) {
    const updatedArray = array.filter(element => {
      return element.id !== id;
    });
    return updatedArray;
  }
};
export const getMatchedObject = (id, array) => {
  if (Array.isArray(array)) {
    const updatedArray = array.filter(element => {
      return element.id === id;
    });
    return updatedArray;
  }
};
export const generateDateObjectFromString = array => {
  if (Array.isArray(array)) {
    const updatedArray = array.map(element => {
      element.start = new Date(element.start);
      element.end = new Date(element.end);
      return element;
    });
    return updatedArray;
  }
};

export const removeDuplicateFromArray = array => {
  if (Array.isArray(array)) {
    let updatedArray = [];
    for (let x of array) {
      if (updatedArray.length === 0) {
        updatedArray.push(x);
      } else {
        let duplicateFound = false;
        for (let y of updatedArray) {
          if (y.id === x.id) {
            duplicateFound = true;
            break;
          }
          
        }
        if (!duplicateFound) {
          updatedArray.push(x);
        }
      }
    }
    return updatedArray;
  }
};
