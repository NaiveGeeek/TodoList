import { showModal, hideModal } from "../actions/modalAction";
import { setUserDetails } from "../actions/loginAction";
import {addCandidate, editCandidate} from "../actions/candidateAction"
import { apicall } from "../actions/apiAction";
import { addEventsToCalandar, deleteEventsFromCalandar,editEventToCalendar} from "../actions/calandarAction";
import {createOpening,editOpeningSecondStep,editOpeningThirdStep} from "../actions/openingAction"
export const singleCandidateDispatchToProps =(dispatch)=>{
    const displayModal = data => dispatch(showModal(data));
    const nodisplayModal = () => dispatch(hideModal());
    return { displayModal, nodisplayModal };
}

export const loginDispatchToProps = (dispatch)=>{
    const userDetails = data => dispatch(setUserDetails(data));
  return { userDetails };
}
export const openingsThirdStageDispatchToProps = (dispatch)=>{
    const displayModal = data => dispatch(showModal(data));
    const nodisplayModal = () => dispatch(hideModal());
    return { displayModal, nodisplayModal };
}
export const openingsStagesDispatchToProps = (dispatch)=>{
    const createOpenings = data=>dispatch(createOpening(data));
    const editOpeningSecondSteps = data=>dispatch(editOpeningSecondStep(data));
    const editOpeningThirdSteps = data=>dispatch(editOpeningThirdStep(data));
    return {createOpenings,editOpeningSecondSteps,editOpeningThirdSteps}

}
export const candidateDispatchToProp= (dispatch)=>{
    const addCandidates = (data)=>dispatch(addCandidate(data));
    const editCandidates = (data)=>dispatch(editCandidate(data));
    return {addCandidates,editCandidates}
}
export const showHideModalDispatchToProps = (dispatch)=>{
    const displayModal = data => dispatch(showModal(data));
    const nodisplayModal = () => dispatch(hideModal());
    return { displayModal, nodisplayModal };
}
export const calandarDispatchToProps = (dispatch)=>{
    const addEvents = data=>dispatch(addEventsToCalandar(data));
    const deleteEvents =(id)=>dispatch(deleteEventsFromCalandar(id));
    const editEvents =(data)=>dispatch(editEventToCalendar(data));
    return {addEvents,deleteEvents,editEvents};
}
export const asyncApiCallDispatchToProps = (dispatch)=>{
    const apiCall = (url,methodType,payload,config,success)=>dispatch(apicall(url,methodType,payload,config,success));
    return {apiCall}
}
export const mapDispatchToProps = (data)=>{
return (dispatch)=>{
    let newDispatchToProps={}
    data.forEach(element => {
       newDispatchToProps={...newDispatchToProps,...element(dispatch)}
    });
    return newDispatchToProps;
}
}