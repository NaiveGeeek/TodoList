import { showModal, hideModal } from "../actions/modalAction";
import { setUserDetails } from "../actions/loginAction";
import { apicall } from "../actions/apiAction";

export const singleCandidateDispatchToProps =(dispatch)=>{
    const displayModal = data => dispatch(showModal(data));
    const nodisplayModal = () => dispatch(hideModal());
    return { displayModal, nodisplayModal };
}

export const loginDispatchToProps = (dispatch)=>{
    const userDetails = data => dispatch(setUserDetails(data));
  return { userDetails };
}
export const openingsThirdStageDispatchToProps = (dispatch)=>{
    const displayModal = data => dispatch(showModal(data));
    const nodisplayModal = () => dispatch(hideModal());
    return { displayModal, nodisplayModal };
}
export const asyncApiCallDispatchToProps = (dispatch)=>{
    const apiCall = (url,methodType,payload,config,success)=>dispatch(apicall(url,methodType,payload,config,success));
    return {apiCall}
}
export const mapDispatchToProps = (data)=>{
return (dispatch)=>{
    let newDispatchToProps={}
    data.forEach(element => {
       newDispatchToProps={...newDispatchToProps,...element(dispatch)}
    });
    return newDispatchToProps;
}
}