import * as Yup from "yup";

export const addCandidateValidationSchema = Yup.object().shape({
  firstName: Yup.string()
    .min(2, "first name must have 2 characters")
    .max(50, "first name can not be longer than 50 characteres")
    .required("first name is required"),
  lastName: Yup.string()
    .min(2, "last name must have 2 characters")
    .max(50, "last name can not be longer than 50 characteres")
    .required("last name is required"),
  email: Yup.string()
    .email()
    .required("email is required"),
  phone: Yup.string()
    .length(10, "invalid mobile number")
    .required("phone number is required"),
  dateOfBirth: Yup.date()
    .nullable()
    .required("Date of birth is required"),
  gender: Yup.string().required("gender is required"),
  location: Yup.string().required("location is required"),
  joiningDate: Yup.date()
    .nullable()
    .required("Joining date is required"),
  totalExpInYears: Yup.string().required("experience is required"),
  totalExpInMonths: Yup.string().required("experience is required"),
  releventExpInYears: Yup.string().required("relevent experience is required"),
  releventExpInMonths: Yup.string().required("relevent experience is required"),
  currentCTCInLakhs: Yup.string().required("current ctc is required"),
  currentCTCInThousands: Yup.string().required("current ctc is required"),
  expectedCTCInLakhs: Yup.string().required("expected ctc is required"),
  expectedCTCInThousands: Yup.string().required("expected ctc is required"),
  job: Yup.string().required("job is required"),
  source: Yup.string().required("source is required")
});

export const openingCreateJobDetailSchema = Yup.object().shape({
  openingTitle: Yup.string().required("opening title is required"),
  job: Yup.string().required("job is required"),
  openingType: Yup.string().required("opening type is required"),
  totalExpInYears: Yup.string().required("experience is required"),
  totalExpInMonths: Yup.string().required("experience is required"),
  location: Yup.string().required("location is required"),
  jobDescription: Yup.string()
    .min(25, "job description of minimum 25 character is required")
    .required("job description is required")
});

export const loginSchema = Yup.object().shape({
  email: Yup.string()
    .email()
    .required("enter valid email id"),
  password: Yup.string().required("password is required")
});

export const signupSchema = Yup.object().shape({
  name: Yup.string().required("name is required"),
  email: Yup.string()
    .email()
    .required("enter valid email id"),
  password: Yup.string().required("password is required"),
  phoneNumber: Yup.string()
    .length(10, "invalid mobile number")
    .required("phone number is required")
});
