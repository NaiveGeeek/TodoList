export const navbarStateToPops=(state)=>{
const { loginState: loginData } = state;
return { loginData };
}


export const modalcontainerStateToProps = (state)=>{
    return {modalState:state.modalState}
}
export  const mapStateToProps=(data)=>{
    return (state)=>{
        const newStateToProps = data.reduce((accumulator={},current)=>{
            return {...accumulator,...current(state)}
        });
        return newStateToProps;
    }
}