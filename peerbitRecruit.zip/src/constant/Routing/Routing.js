import Openings from "../../components/Openings/Openings";
import Candidates from "../../components/Candidates/Candidates";
import Calender from "../../components/Calender/Calender";
import Dashboard from "../../components/Dashboard/Dashboard";
import AddCandidate from "../../components/AddCandidate/AddCandidate";
import SingleCandidatePage from "../../components/SingleCandidatePage/SingleCandidatePage";
import SingleOpeningPage from "../../components/SingleOpeningPage/SingleOpeningPage";
import EditOpening from "../../components/EditOpening/EditOpening";
import Login from "../../components/Login/Login";
import Signup from "../../components/Signup/Signup";
import ForgotPassword from "../../components/ForgotPassword/ForgotPassword"
import OpeningFirstStep from "../../components/AddOpening/OpeningFirstStep"
import OpeningSecondStep from "../../components/AddOpening/OpeningSecondStep"
import OpeningThirdStage from "../../components/AddOpening/OpeningThirdStage"
import OpeningLastStage from "../../components/AddOpening/OpeningLastStage"
import Overview from "../../components/Openings/Overview"
import Private from "../../components/Openings/Private"
import Archived from "../../components/Openings/Archived"
import AssignedToMe from "../../components/Openings/AssignedToMe"
import AllOpenings from "../../components/Openings/AllOpenings"

export const appRoute=[
  {
    exact: true,
    path: "/login",
    component: Login
  },
  {
    exact: true,
    path: "/signup",
    component: Signup
  },{
    exact: true,
    path: "/forgot_password",
    component: ForgotPassword
  },
]
export const  privateAppRoute = [
  {
    exact: true,
    path: "/",
    component: Dashboard
  },
  {
    path: "/openings",
    component: Openings
  },
  {
    path: "/candidates",
    component: Candidates
  },
  {
    path: "/calender",
    component: Calender
  },
  {
    path: "/add_candidate",
    component: AddCandidate
  },
  {
    path: "/single_page_view_candidate",
    component: SingleCandidatePage
  },
  {
    path: "/single_page_opening_view",
    component: SingleOpeningPage
  },
  {
    path: "/edit_opening",
    component: EditOpening
  },
  {
    exact: true,
    path: "/add_opening",
    component: OpeningFirstStep
  },
  {
    path: "/add_opening/openings_details",
    component: OpeningSecondStep
  },
  {
    path: "/add_opening/openings_stages",
    component: OpeningThirdStage
  },
  {
    path: "/add_opening/opening_creation_success",
    component: OpeningLastStage
  },
];
 export const privateAppOpeningRoute=[
    {
        exact: true,
        path: "/openings",
        component: Overview
      },
      {
        path: "/openings/assigned_to_me",
        component: AssignedToMe
      },
      {
        path: "/openings/all_openings",
        component: AllOpenings
      },
      {
        path: "/openings/drafts",
        component: Overview
      },
      {
        path: "/openings/published",
        component: Overview
      },
      {
        path: "/openings/used_internally",
        component: Overview
      },
      {
        path: "/openings/not_accepting_candidates",
        component: Overview
      },
      {
        path: "/openings/archived",
        component: Archived
      },
      { path: "/openings/private", component: Private }
 ]

 