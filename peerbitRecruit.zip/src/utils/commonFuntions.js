export const isUserAuthorized=()=>{
    const token = localStorage.getItem("token");
    return token==="peerbits"?true:false;
}