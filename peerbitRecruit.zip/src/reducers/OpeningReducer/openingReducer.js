const initialState={
    openings:[],
    allOpenigs:[],
    assignedToMe:[]
}
export const OpeningReducer =(state=initialState,action)=>{
    switch(action.type){
  
    }
}