import {
  GET_TODOS,
  GET_THINGS_TO_FOLLOW_UP,
  GET_ASSIGNED_INTERVIEWS
} from "../constant/actiontypes";
export const getDashboardData = () => {
  return dispatch => {
    setTimeout(() => {
      dispatch(
        setAssignedInterview({
          id: 1,
          name: "John",
          time: new Date(),
          type: "",
          phone: 8825689528
        })
      );
      dispatch(
        setThingsToFollowUp({
          id: 1,
          title: "get call from manager"
        })
      );
      dispatch(
        setTodo({
          id: 1,
          title: "Arrange Meeting with Developers",
          completed: false
        })
      );
    }, 2000);
  };
};

export const setTodo = data => ({
  type: GET_TODOS,
  payload: data
});
export const setThingsToFollowUp = data => ({
  type: GET_THINGS_TO_FOLLOW_UP,
  payload: data
});

export const setAssignedInterview = data => ({
  type: GET_ASSIGNED_INTERVIEWS,
  payload: data
});
