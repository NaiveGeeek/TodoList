import { httpService } from "../constant/api"

export const apicall=(url,methodType,payload,config,success)=>{
    return dispatch=>{
        httpService(url,methodType,payload,config,success);
    }
}   