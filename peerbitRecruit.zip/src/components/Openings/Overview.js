import React, { Component } from 'react'
import { Row, Col, OverlayTrigger, Tooltip } from 'react-bootstrap';
import "./Overview.css"
import { Link } from 'react-router-dom';
import { IoIosWarning } from "react-icons/io"

class Overview extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [{
                id: 1,
                title: "Abdulhanan Shaikh",
                assignedUser: "Nasrullah",
                location: "Ahemdabad, India",
                candidates: 0,
                isDataIncomplete: false,
            }, {
                id: 2,
                title: "Android",
                assignedUser: "Nasrullah",
                location: "Ahemdabad, India",
                candidates: 0,
                isDataIncomplete: false,
            }, {
                id: 3,
                title: "Android",
                assignedUser: "Nasrullah",
                location: "Ahemdabad, India",
                candidates: 0,
                isDataIncomplete: true,
            }, {
                id: 4,
                title: "Android",
                assignedUser: "Nasrullah",
                location: "Ahemdabad, India",
                candidates: 0,
                isDataIncomplete: false,
            }, {
                id: 5,
                title: "Android",
                assignedUser: "Nasrullah",
                location: "Ahemdabad, India",
                candidates: 0,
                isDataIncomplete: false,
            }, {
                id: 6,
                title: "Android",
                assignedUser: "Nasrullah",
                location: "Ahemdabad, India",
                candidates: 0,
                isDataIncomplete: true,
            }]
        }
    }
    getCardElements = () => {
        const elements = this.state.data.map((data, index) => {
            return (
                <Col key={index} xs={12} sm={4}>
                    <div className="dashboard-tile">
                        <h3>
                            <Link to="/single_page_opening_view" className="dashboard-tile-header">
                                {data.isDataIncomplete ? <span className="incomplete-details-warning">
                                    <OverlayTrigger
                                        placement={"top"}
                                        overlay={
                                            <Tooltip id={`tooltip-${"top"}+${index}`} style={{fontSize:"10px"}}>
                                               This opening has incomplete details.
                                              </Tooltip>
                                        }
                                    ><IoIosWarning></IoIosWarning></OverlayTrigger>
                                    </span> : null}
                                <div className="dashboard-tile-title long-text-ellipsis">{data.title} </div>

                            </Link>
                        </h3>
                        <div className="dashboard-tile-info">
                            <div className="dashboard-tile-info-row">
                                <span className="text-mute">Assigned Users:</span>{data.assignedUser}
                            </div>
                            <div className="dashboard-tile-info-row">
                                <span className="text-mute">Location:</span>{data.location}
                            </div>
                            <div className="dashboard-tile-candidates">
                                <Link to="#" className="link-pill">{data.candidates} candidates</Link>
                            </div>
                        </div>
                    </div>
                </Col>
            )
        });
        return elements;
    }
    render() {
        return (
            <div className="main-col">
                <div className="list-page-without-actions">
                    <section className="dashboard-section">
                        <h1 className="list-section-heading">Overview</h1>
                        <Row style={{ display: "flex" }}>
                            {this.getCardElements()}
                        </Row>
                    </section>
                </div>
            </div>

        )
    }
}
export default Overview
