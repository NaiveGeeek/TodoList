import React, { Component } from "react";
import "./Openings.css";

import OpeningSideBar from "./OpeningSideBar";
import { privateAppOpeningRoute } from "../../constant/Routing/Routing";
import { Route } from "react-router-dom";
class Openings extends Component {
  render() {
    return (
      <div className="page">
        <div className="clearfix equal-height-content">
          <OpeningSideBar></OpeningSideBar>
          {privateAppOpeningRoute.map((routeProps, index) => (
            <Route key={index} {...routeProps} />
          ))}
        </div>
      </div>
    );
  }
}

export default Openings;
