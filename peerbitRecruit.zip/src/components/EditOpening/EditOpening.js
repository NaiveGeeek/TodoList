import React, { Component } from 'react'
import { Form, Row, Col, Button, Tooltip, OverlayTrigger } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import {FaInfoCircle} from "react-icons/fa"

class EditOpening extends Component {
    render() {
        return (
            <div className="main-col" style={{ paddingBottom: "150px" }}>
                <div className="page-header">
                    <div className="page-title-block-bleeding-left clearfix">
                        <h1 className="page-title js-page-title">Edit opening: Abdulhannan Shaikh</h1>
                    </div>
                </div>
                <Row>
                    <Col sm={8}>
                        <Form>
                            <div style={{margin:'30px auto 20px'}}>
                                <h2>Just a little more information about the opening and we're ready to go.</h2>
                            </div>
                            <Row>
                                <Col sm={6}>
                                    <Form.Group>
                                        <Form.Label>Opening Title</Form.Label>
                                        <Form.Control type="text"></Form.Control>
                                    </Form.Group>
                                </Col>
                                <Col sm={6}>
                                    <Form.Group>
                                        <Form.Label>Job</Form.Label>
                                        <Form.Control as="select" defaultValue=" ">
                                            <option value=" " disabled>Select a Job</option>
                                            <option value="Business Development Manager">Business Development Manager</option>
                                            <option value="iOS Developer">iOS Developer</option>
                                            <option value="QA">QA</option>
                                            <option value="Android Developer">Android Developer</option>
                                        </Form.Control>
                                    </Form.Group>
                                </Col>
                                <Col sm={6}>
                                    <Form.Group>
                                        <Form.Label>Opening Type</Form.Label>
                                        <Form.Control as="select" defaultValue=" ">
                                            <option value=" " disabled>Select a Type</option>
                                            <option value="1">Fresher</option>
                                            <option value="2">Experience</option>
                                        </Form.Control>
                                    </Form.Group>
                                </Col>
                                <Col sm={6}>
                                    <Form.Group>
                                        <Form.Label>Total Experience</Form.Label>
                                        <Row>
                                            <Col sm={6}>
                                                <Form.Control as="select" defaultValue=" ">
                                                    <option value=" " disabled>Years</option>
                                                    <option value="1 Year">1 Year</option>
                                                    <option value="2 Years">2 Years</option>
                                                </Form.Control>
                                            </Col>
                                            <Col sm={6}>
                                                <Form.Control as="select" defaultValue=" ">
                                                    <option value=" " disabled>Months</option>
                                                    <option value="1 Month">1 Month</option>
                                                    <option value="2 Months">2 Months</option>
                                                </Form.Control>
                                            </Col>
                                        </Row>
                                    </Form.Group>
                                </Col>
                                <Col sm={6}>
                                    <Form.Group>
                                        <Form.Label>Location <OverlayTrigger
                                            placement="top"
                                            overlay={
                                                <Tooltip id={`tooltip-${"top"}+${1}`} style={{ fontSize: "10px" }}>
                                                    For remote positions, please provide your office location.
                                              </Tooltip>
                                            }
                                        ><FaInfoCircle style={{ marginLeft: "5px" }} className="text-mute"></FaInfoCircle></OverlayTrigger> </Form.Label>
                                        <Form.Control type="text" placeholder="Enter a location"></Form.Control>
                                    </Form.Group>
                                </Col>
                                <Col sm={12}>
                                    <Form.Group>
                                        <Form.Label>Job Description</Form.Label>
                                        <Form.Control as="textarea" rows="3" />
                                    </Form.Group>
                                </Col>
                            </Row>
                            <div className="form-action">
                                <Button type="submit" variant="primary" style={{ marginRight: "10px" }} className="pull-right">Save</Button>
                                <Link to="#" className="btn btn-default pull-left"> Cancel </Link>
                            </div>
                        </Form>
                    </Col>
                </Row>
            </div>
        )
    }
}

export default EditOpening;