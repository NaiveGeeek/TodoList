import React, { Component } from 'react'
import { Modal, Row, Col, Form } from 'react-bootstrap'
import { Typeahead } from 'react-bootstrap-typeahead'
import { FaThumbsUp, FaRegThumbsUp, FaThumbsDown, FaRegThumbsDown } from 'react-icons/fa';
import {IoIosRemove} from "react-icons/io"
import "./TelephoneCandidateModal.css"
class TelephoneCandidateModal extends Component {
    constructor(props) {
        super(props);
        this.options = ["Mohsin", "Toufik"];
        this.state = {
            interviewers: [],
        }
    }
    handleMultipleInputChange = (values) => {
        this.setState({
            interviewers: values,
        })
    }
    render() {
        return (
            <Modal show={this.props.modalProps.open} size="lg" backdrop="static">
                <Modal.Header>
                    <Modal.Title><strong>Set up Evaluation Form for Screening</strong></Modal.Title>
                </Modal.Header>
                <Modal.Body style={{ padding: 0 }}>
                    <div className="form-alert-heading"> This is a preview of how the evaluation form will look to <strong>interviewers</strong> .</div>
                    <Form >
                        <div className="modal-form-container">
                        <Row >
                            <Col xs={12}>
                                <Form.Group>
                                    <Form.Label>Schedule Date</Form.Label>
                                    <Form.Control type="text"></Form.Control>
                                </Form.Group>
                            </Col>
                            <Col xs={12}>
                                <Form.Group>
                                    <Form.Label><strong>Interviewers</strong></Form.Label>
                                    <Typeahead
                                        id="interviewers"
                                        labelKey="name"
                                        clearButton
                                        multiple={true}
                                        options={this.options}
                                        placeholder="Choose a Person..." onChange={(values) => { this.handleMultipleInputChange(values) }}>
                                    </Typeahead>
                                </Form.Group>
                            </Col>
                            <Col xs={6}>
                                <Form.Group>
                                    <Form.Label><strong>Type / Medium</strong></Form.Label>
                                    <Form.Control name="medium" as="select" onChange={this.handleChange} value={this.state.medium}>
                                        <option value="1">Skype</option>
                                        <option value="2">Phone</option>
                                        <option value="3">Telephone (Direct call)</option>
                                        <option value="4">Face to face</option>
                                    </Form.Control>
                                </Form.Group>
                            </Col>
                            <Col xs={6}>
                                <Form.Group>
                                    <Form.Label><strong>Duration</strong></Form.Label>
                                    <Form.Control as="select" name="duration" onChange={this.handleChange} value={this.state.duration}>
                                        <option value="1">15 minutes</option>
                                        <option value="2">30 minutes</option>
                                        <option value="3">45 minutes</option>
                                        <option value="4">1 hour</option>
                                    </Form.Control>
                                </Form.Group>
                            </Col>
                            <Col xs={12}>
                                <Form.Group>
                                    <Form.Label>Remarks</Form.Label>
                                    <Form.Control as="textarea" rows="4" />
                                </Form.Group>
                            </Col>
                        </Row>
                        <Row>
                            <Col xs={6}>
                                <div><span><strong>Basic</strong></span></div>
                            </Col>
                            <Col xs={6} className="align-items-end">
                                <div className="radio-button-group">
                                    <label className="radio-label">
                                        <input type="radio" value={5} name="basic"></input>
                                        <span className="custom-radio worst">
                                            <FaThumbsDown></FaThumbsDown>
                                        </span>
                                    </label>
                                    <label className="radio-label">
                                        <input type="radio" value={5} name="basic"></input>
                                        <span className="custom-radio bad">
                                            <FaRegThumbsDown></FaRegThumbsDown>
                                        </span>
                                    </label>
                                    <label className="radio-label">
                                        <input type="radio" value={5} name="basic"></input>
                                        <span className="custom-radio neutral">
                                            <IoIosRemove></IoIosRemove>
                                        </span>
                                    </label>
                                    <label className="radio-label">
                                        <input type="radio" value={4} name="basic"></input>
                                        <span className="custom-radio good">
                                            <FaRegThumbsUp></FaRegThumbsUp>
                                        </span>
                                    </label>
                                    <label className="radio-label">
                                        <input type="radio" value={5} name="basic"></input>
                                        <span className="custom-radio excellent">
                                            <FaThumbsUp></FaThumbsUp>
                                        </span>
                                    </label>
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col xs={6}>
                                <div><span><strong>Technical</strong></span></div>
                            </Col>
                            <Col xs={6} className="align-items-end">
                                <div className="radio-button-group">
                                    <label className="radio-label">
                                        <input type="radio" value={5} name="technical"></input>
                                        <span className="custom-radio worst">
                                            <FaThumbsDown></FaThumbsDown>
                                        </span>
                                    </label>
                                    <label className="radio-label">
                                        <input type="radio" value={5} name="technical"></input>
                                        <span className="custom-radio bad">
                                            <FaRegThumbsDown></FaRegThumbsDown>
                                        </span>
                                    </label>
                                    <label className="radio-label">
                                        <input type="radio" value={5} name="technical"></input>
                                        <span className="custom-radio neutral">
                                            <IoIosRemove></IoIosRemove>
                                        </span>
                                    </label>
                                    <label className="radio-label">
                                        <input type="radio" value={4} name="technical"></input>
                                        <span className="custom-radio good">
                                            <FaRegThumbsUp></FaRegThumbsUp>
                                        </span>
                                    </label>
                                    <label className="radio-label">
                                        <input type="radio" value={5} name="technical"></input>
                                        <span className="custom-radio excellent">
                                            <FaThumbsUp></FaThumbsUp>
                                        </span>
                                    </label>
                                </div>
                            </Col>
                        </Row>
                        </div>
                        <div className="stage-edit-form-buttons clearfix">
                            <button type="submit" className="btn btn-primary pull-right save-btn">Save as Interview stage</button>
                            <button type="button" className="btn btn-default pull-right hide-non-interview-button" style={{marginRight:"10px"}} onClick={()=>{this.props.modalProps.closeModal();}}>Cancel</button>
                        </div>
                    </Form>
                </Modal.Body>

            </Modal>
        )
    }
}
export default TelephoneCandidateModal