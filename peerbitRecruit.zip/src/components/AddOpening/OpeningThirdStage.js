import React, { Component } from "react";
import { Link } from "react-router-dom";
import { Row, Col, Dropdown } from "react-bootstrap";
import arrow from "../../assets/arrow.svg";
import { IoMdMore, IoMdCreate } from "react-icons/io";
import {
  FaUser,
  FaLock,
  FaRegClock,
  FaRegCalendarAlt,
  FaListAlt
} from "react-icons/fa";
import { connect } from "react-redux";
import {
  OPENING_STAGE_SCREENING_MODAL,
  OPENING_STAGE_TELEPHONIC_MODAL
} from "../../constant/modaltypes";
import { mapDispatchToProps, openingsThirdStageDispatchToProps } from "../../constant/mapDispatchToProps";
class OpeningThirdStage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      telephoneExapndable: false,
      faceInterviewExpandable: false
    };
  }

  handleExpansion = event => {
    const target = event.target;
    this.setState({
      [target.name]: !this.state[target.name]
    });
  };
  closeModal = () => {
    this.props.nodisplayModal();
  };
  openModal = name => {
    let payload = {
      modalType: name,
      modalProps: {
        open: true,
        closeModal: this.closeModal
      }
    };
    this.props.displayModal(payload);
  };
  render() {
    return (
      <div className="main-col">
        <div className="page-header">
          <div className="page-title-block-bleeding-left clearfix">
            <h1 className="page-title">
              Set up your hiring workflow for the opening{" "}
            </h1>
            <div className="js-steps-bar">
              <ol className="process-step-bar">
                <li className="process-step-item">1. Create Opening</li>
                <li className="process-step-item">2. Opening Details</li>
                <li className="process-step-item process-step-item-current">
                  3. Hiring Workflow
                </li>
              </ol>
            </div>
          </div>
        </div>
        <div className="main-col-inner opening-stages-edit">
          <Row>
            <Col sm={7} className="stages-col">
              <div className="new-candidate  space-on-top-20px">
                <i className="icon icon-candidate-gray"></i>
                <span>New Candidate</span>
                <div className="horizontal"></div>
                <div className="vertical"></div>
              </div>
              <Row className="stage-row first-stage-row">
                <Col xs={1}>
                  <IoMdMore></IoMdMore>
                  <IoMdMore></IoMdMore>
                </Col>
                <Col xs={10}>
                  <span className="title-opening">Screening</span>
                  <span className="text-mute">·</span>
                  <span className="text-mute">
                    <FaUser style={{ fontSize: "12px" }}></FaUser>
                  </span>
                  <span style={{ marginRight: "10px" }} className="text-mute">
                    <strong>Cordinator:</strong>
                  </span>
                  <span className="text-mute">Nasrullah</span>
                </Col>
                <Col xs={1} className="edit-flow text-mute">
                  <Dropdown className="icon-dropdown">
                    <Dropdown.Toggle
                      style={{ background: "transparent" }}
                      id="dropdown-basic"
                    >
                      <IoMdCreate className="edit-icon text-mute"></IoMdCreate>
                    </Dropdown.Toggle>
                    <Dropdown.Menu>
                      <Dropdown.Item
                        as={Link}
                        to="#"
                        onClick={() => {
                          this.openModal(OPENING_STAGE_SCREENING_MODAL);
                        }}
                      >
                        Edit
                      </Dropdown.Item>
                      <Dropdown.Item as={Link} to="#">
                        Convert to <em>Interview Stage</em>
                      </Dropdown.Item>
                      <Dropdown.Item as={Link} to="#">
                        Convert to <em>Review Stage</em>
                      </Dropdown.Item>
                      <Dropdown.Item as={Link} to="#">
                        Delete
                      </Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                </Col>
              </Row>
              <Row className="stage-row">
                <Col xs={1}>
                  <IoMdMore></IoMdMore>
                  <IoMdMore></IoMdMore>
                </Col>
                <Col xs={10}>
                  <div>
                    <span className="title-opening">Telephone Interview</span>
                    <span className="text-mute">·</span>
                    <span className="text-mute">
                      <FaUser style={{ fontSize: "12px" }}></FaUser>
                    </span>
                    <span style={{ marginRight: "10px" }} className="text-mute">
                      <strong>Cordinator:</strong>
                    </span>
                    <span className="text-mute">Nasrullah</span>
                  </div>
                  <div className="sub-content-opening">
                    <span className="text-mute">
                      <FaUser></FaUser>
                    </span>
                    <span>
                      <span>Interviewers: </span>
                      <span> You</span>
                    </span>
                    <span className="text-mute">·</span>
                    <span className="text-mute">Telephone (Direct call)</span>
                    <span className="text-mute">·</span>
                    <span className="text-mute">
                      <FaLock></FaLock>
                    </span>
                    <span className="text-mute">Private</span>
                    <span>
                      <Link
                        to="#"
                        name={"telephoneExapndable"}
                        onClick={this.handleExpansion}
                      >
                        ... show more
                      </Link>
                    </span>
                  </div>
                  <div
                    style={{
                      display: this.state.telephoneExapndable ? "block" : "none"
                    }}
                  >
                    <div className="sub-content-opening">
                      <span className="text-mute">
                        <FaRegClock></FaRegClock>
                      </span>
                      <span>Duration: </span>
                      <span> 30 minutes </span>
                    </div>
                    <div className="sub-content-opening">
                      <span className="text-mute">
                        <FaRegCalendarAlt></FaRegCalendarAlt>
                      </span>
                      <span className="text-mute"> Not Set </span>
                    </div>
                  </div>
                </Col>
                <Col xs={1} className="edit-flow text-mute">
                  <Dropdown className="icon-dropdown">
                    <Dropdown.Toggle
                      style={{ background: "transparent" }}
                      id="dropdown-basic"
                    >
                      <IoMdCreate className="edit-icon text-mute"></IoMdCreate>
                    </Dropdown.Toggle>
                    <Dropdown.Menu>
                      <Dropdown.Item
                        as={Link}
                        to="#"
                        onClick={() => {
                          this.openModal(OPENING_STAGE_TELEPHONIC_MODAL);
                        }}
                      >
                        Edit
                      </Dropdown.Item>
                      <Dropdown.Item as={Link} to="#">
                        Convert to <em>Plain Stage</em>
                      </Dropdown.Item>
                      <Dropdown.Item as={Link} to="#">
                        Delete
                      </Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                </Col>
              </Row>
              <Row className="stage-row">
                <Col xs={1}>
                  <IoMdMore></IoMdMore>
                  <IoMdMore></IoMdMore>
                </Col>
                <Col xs={10}>
                  <div>
                    <span className="title-opening">
                      Face to face Interview
                    </span>
                    <span className="text-mute">·</span>
                    <span className="text-mute">
                      <FaUser style={{ fontSize: "12px" }}></FaUser>
                    </span>
                    <span style={{ marginRight: "10px" }} className="text-mute">
                      <strong>Cordinator:</strong>
                    </span>
                    <span className="text-mute">Nasrullah</span>
                  </div>
                  <div>
                    <div className="sub-content-opening">
                      <span className="text-mute">
                        <FaUser></FaUser>
                      </span>
                      <span>
                        <span>Interviewers: </span>
                        <span> You</span>
                      </span>
                      <span className="text-mute">·</span>
                      <span className="text-mute">Face to Face</span>
                      <span className="text-mute">·</span>
                      <span className="text-mute">
                        <FaLock></FaLock>
                      </span>
                      <span className="text-mute">Private</span>
                      <span>
                        <Link
                          to="#"
                          name="faceInterviewExpandable"
                          onClick={this.handleExpansion}
                        >
                          ... show more
                        </Link>
                      </span>
                    </div>
                    <div
                      style={{
                        display: this.state.faceInterviewExpandable
                          ? "block"
                          : "none"
                      }}
                    >
                      <div className="sub-content-opening">
                        <span className="text-mute">
                          <FaRegClock></FaRegClock>
                        </span>
                        <span>Duration: </span>
                        <span> 30 minutes </span>
                      </div>
                      <div className="sub-content-opening">
                        <span className="text-mute">
                          <FaRegCalendarAlt></FaRegCalendarAlt>
                        </span>
                        <span className="text-mute"> Not Set </span>
                      </div>
                    </div>
                  </div>
                </Col>
                <Col xs={1} className="edit-flow">
                  <Dropdown className="icon-dropdown">
                    <Dropdown.Toggle
                      style={{ background: "transparent" }}
                      id="dropdown-basic"
                    >
                      <IoMdCreate className="edit-icon text-mute"></IoMdCreate>
                    </Dropdown.Toggle>
                    <Dropdown.Menu>
                      <Dropdown.Item as={Link} to="#">
                        Edit
                      </Dropdown.Item>
                      <Dropdown.Item as={Link} to="#">
                        Convert to <em>Plain Stage</em>
                      </Dropdown.Item>
                      <Dropdown.Item as={Link} to="#">
                        Delete
                      </Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                </Col>
              </Row>
              <Row className="stage-row">
                <Col xs={1}>
                  <IoMdMore></IoMdMore>
                  <IoMdMore></IoMdMore>
                </Col>
                <Col xs={10}>
                  <span className="title-opening">Make Offer</span>
                  <span className="text-mute">·</span>
                  <span className="text-mute">
                    <FaUser style={{ fontSize: "12px" }}></FaUser>
                  </span>
                  <span style={{ marginRight: "10px" }} className="text-mute">
                    <strong>Cordinator:</strong>
                  </span>
                  <span className="text-mute">Nasrullah</span>
                </Col>
                <Col xs={1} className="edit-flow text-mute">
                  <Dropdown className="icon-dropdown">
                    <Dropdown.Toggle
                      style={{ background: "transparent" }}
                      id="dropdown-basic"
                    >
                      <IoMdCreate className="edit-icon text-mute"></IoMdCreate>
                    </Dropdown.Toggle>
                    <Dropdown.Menu>
                      <Dropdown.Item as={Link} to="#">
                        Edit
                      </Dropdown.Item>
                      <Dropdown.Item as={Link} to="#">
                        Convert to <em>Interview Stage</em>
                      </Dropdown.Item>
                      <Dropdown.Item as={Link} to="#">
                        Convert to <em>Review Stage</em>
                      </Dropdown.Item>
                      <Dropdown.Item as={Link} to="#">
                        Delete
                      </Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                </Col>
              </Row>
              <Dropdown className="add-a-stage">
                <Dropdown.Toggle id="dropdown-basic">
                  + Add a Stage
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  <Dropdown.Item as={Link} to="#">
                    <FaRegCalendarAlt></FaRegCalendarAlt> Interview Stage
                  </Dropdown.Item>
                  <Dropdown.Item as={Link} to="#">
                    <FaListAlt></FaListAlt> Review Stage
                  </Dropdown.Item>
                  <hr style={{ margin: 0 }}></hr>
                  <Dropdown.Item as={Link} to="#">
                    Plain Stage
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
              {/* hired container  */}
              <div className="hired-container">
                <div className="vertical-bottom"></div>
                <div className="state-circle state-circle-success text-center">
                  <div className="state-name">
                    <span>&nbsp;Hired</span>
                  </div>
                </div>
              </div>
            </Col>
            <Col sm={2} className="text-center">
              <img
                className="hiring-setup-arrow"
                src={arrow}
                alt="arrow sign"
              ></img>
            </Col>
            <Col sm={3}>
              <div className="reject-state-container">
                <div className="states-wrapper">
                  <div className="state-wrapper state-rejected">
                    <div className="state-name">Rejected</div>
                  </div>
                  <div className="state-wrapper state-onhold">
                    <div className="state-name">On Hold</div>
                  </div>
                  <div className="state-wrapper state-archived">
                    <div className="state-name">Archived</div>
                  </div>
                  <div className="state-wrapper state-withdrew">
                    <div className="state-name">Candidate Withdrew</div>
                  </div>
                  <div className="state-wrapper state-declinedoffer">
                    <div className="state-name">Declined Offer</div>
                  </div>
                </div>
              </div>
            </Col>
          </Row>
        </div>
        <div className="form-action">
          <Link to="/add_opening/openings_details" className="btn btn-default">
            <span className="big-text">«</span> Back
          </Link>
          <Link
            to="/add_opening/opening_creation_success"
            className="btn btn-primary pull-right"
          >
            Next <span className="big-text">»</span>
          </Link>
        </div>
      </div>
    );
  }
}
export default connect(null, mapDispatchToProps([openingsThirdStageDispatchToProps]))(OpeningThirdStage);
