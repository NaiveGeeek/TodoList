import React, { Component } from 'react'
import SingleOpeningSidebar from './SingleOpeningSidebar'
import SingleOpeningMain from './SingleOpeningMain'

class SingleOpeningPage extends Component {
    render() {
        return (
            <div className="equal-height-content">
                <SingleOpeningSidebar></SingleOpeningSidebar>
                <SingleOpeningMain></SingleOpeningMain>
            </div>
        )
    }
}
export default SingleOpeningPage