import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import {FaQuestionCircle,FaUser } from "react-icons/fa"
import { OverlayTrigger, Tooltip } from 'react-bootstrap'
class SingleOpeningMain extends Component {
    render() {
        return (
            <div className="main-col">
                <div className="page-title-block-bleeding-left clearfix">
                    <h1 className="page-title">Abdulhannan Shaikh</h1>
                </div>
                <section className="dashboard-section dashboard-list-group-wrapper">
                    <div className="section-heading">
                        <h2 className="heading">Summary</h2>
                    </div>
                    <div className="dashboard-list-group">
                        <table className="table">
                            <colgroup>
                                <col width="25%" />
                                <col width="75%" />
                            </colgroup>
                            <tbody>
                                <tr>
                                    <td className="text-muted">Created</td>
                                    <td>
                                        28 Jun, 3:06 pm <span className="text-mute">by </span> <FaUser className="text-mute"></FaUser> Nasrullah
                                                        </td>
                                </tr>
                                <tr>
                                    <td className="text-muted">Status</td>
                                    <td>
                                        <i className="glyphicon glyphicon-ok text-success"></i> Active
                                                        </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </section>
                <section className="dashboard-section dashboard-list-group-wrapper">
                    <div className="section-heading">
                        <Link to="#" className="pull-right">Edit</Link>
                        <h2 className="heading">Users<span className="text-muted offset10px">Who's working on this opening?</span></h2>
                    </div>
                    <div className="dashboard-list-group">
                        <table className="table">
                            <colgroup>
                                <col width="25%" />
                                <col width="75%" />
                            </colgroup>
                            <tbody>
                                <tr>
                                    <td className="text-muted">Job Admins
                                                        <OverlayTrigger
                                            placement={"top"}
                                            overlay={
                                                <Tooltip id={`tooltip-${"top"}+${1}`} style={{ fontSize: "10px" }}>
                                                   Job Admins have access to manage everything in this opening irrespective of their user role.
                                              </Tooltip>
                                            }
                                        ><FaQuestionCircle style={{marginLeft:"5px"}}></FaQuestionCircle></OverlayTrigger>
                                    </td>
                                    <td>-</td>
                                </tr>
                                <tr>
                                    <td className="text-muted">Coordinators 
                                    <OverlayTrigger
                                            placement={"top"}
                                            overlay={
                                                <Tooltip id={`tooltip-${"top"}+${2}`} style={{ fontSize: "10px" }}>
                                                   Coordinators of a stage typically schedule interviews, collect evaluation from interviewers and communicate with the candidate.
                                              </Tooltip>
                                            }
                                        ><FaQuestionCircle style={{marginLeft:"5px"}}></FaQuestionCircle></OverlayTrigger>
                                    </td>
                                    <td>
                                       <FaUser className="text-mute"></FaUser>  Nasrullah <small className="text-muted">(creator)</small>
                                    </td>
                                </tr>
                                <tr>
                                    <td className="text-mute">Other members 
                                    <OverlayTrigger
                                            placement={"top"}
                                            overlay={
                                                <Tooltip id={`tooltip-$"top"}+${2}`} style={{ fontSize: "10px" }}>
                                                   These people get updates about the opening. The actions they can perform in the opening depends on their user role.
                                              </Tooltip>
                                            }
                                        ><FaQuestionCircle style={{marginLeft:"5px"}}></FaQuestionCircle></OverlayTrigger>
                                    </td>
                                    <td>-</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </section>
                <section className="dashboard-section dashboard-list-group-wrapper">
                    <div className="section-heading">
                        <Link to="#" className="pull-right">Edit</Link>
                        <h2 className="heading">Stages</h2>
                    </div>
                    <div className="dashboard-list-group">
                        <table className="table">
                            <colgroup>
                                <col width="25%" />
                                <col width="50%" />
                                <col width="25%" />
                            </colgroup>
                            <tbody>
                                <tr>
                                    <td>Telephone Interview</td>
                                    <td>
                                        <FaUser className="text-mute"></FaUser> Nasrullah
                                                        </td>
                                    <td>
                                        <div className="text-right">
                                            <Link to="#" className="subtle-link">0 candidates</Link>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Screening</td>
                                    <td>
                                    <FaUser className="text-mute"></FaUser> Nasrullah
                                                        </td>
                                    <td>
                                        <div className="text-right">
                                            <Link to="#" className="subtle-link">0 candidates</Link>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Face to face Interview</td>
                                    <td>
                                    <FaUser className="text-mute"></FaUser> Nasrullah
                                                        </td>
                                    <td>
                                        <div className="text-right">
                                            <Link to="#" className="subtle-link">0 candidates</Link>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Make Offer</td>
                                    <td>
                                    <FaUser className="text-mute"></FaUser> Nasrullah
                                                        </td>
                                    <td>
                                        <div className="text-right">
                                            <Link to="#" className="subtle-link">0 candidates</Link>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div className="states-wrapper">
                        <div className="state-wrapper candidate-state-hired">
                            <div className="state-wrapper-content">
                                <div className="state-name">Hired</div>
                                <div className="state-count">
                                    <Link to="#" className="subtle-link">0 candidates</Link>
                                </div>
                            </div>
                        </div>
                        <div className="state-wrapper candidate-state-onhold">
                            <div className="state-wrapper-content">
                                <div className="state-name">On Hold</div>
                                <div className="state-count">
                                    <Link to="#" className="subtle-link">0 candidates</Link>
                                </div>
                            </div>
                        </div>
                        <div className="state-wrapper candidate-state-rejected">
                            <div className="state-wrapper-content">
                                <div className="state-name">Rejected</div>
                                <div className="state-count">
                                    <Link to="#" className="subtle-link">0 candidates</Link>
                                </div>
                            </div>
                        </div>
                        <div className="state-wrapper candidate-state-declined_offer">
                            <div className="state-wrapper-content">
                                <div className="state-name">Declined Offer</div>
                                <div className="state-count">
                                    <Link to="#" className="subtle-link">0 candidates</Link>
                                </div>
                            </div>
                        </div>
                        <div className="state-wrapper candidate-state-withdrawn">
                            <div className="state-wrapper-content">
                                <div className="state-name">Withdrawn</div>
                                <div className="state-count">
                                    <Link to="#" className="subtle-link">0 candidates</Link>
                                </div>
                            </div>
                        </div>
                        <div className="state-wrapper candidate-state-archived">
                            <div className="state-wrapper-content">
                                <div className="state-name">Archived</div>
                                <div className="state-count">
                                    <Link to="#" className="subtle-link">0 candidates</Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section className="dashboard-section dashboard-list-group-wrapper">
                    <div className="section-heading">
                        <Link to="edit_openings_singal_view.php" className="pull-right">Edit</Link>
                        <h2 className="heading">Opening Details</h2>
                    </div>
                    <div className="dashboard-list-group">
                        <table className="table">
                            <colgroup>
                                <col width="25%" />
                                <col width="75%" />
                            </colgroup>
                            <tbody>
                                <tr>
                                    <td className="text-muted">Position Type</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td className="text-muted">Location</td>
                                    <td>Ahmedabad, Gujarat, India</td>
                                </tr>
                                <tr>
                                    <td className="text-muted">Team</td>
                                    <td><span className="text-muted">Not Set</span></td>
                                </tr>
                                <tr>
                                    <td className="text-muted">Job Description</td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </section>
                <section className="dashboard-section dashboard-list-group-wrapper">
                    <div className="section-heading">
                        <h2 className="heading">Recent Candidates Report</h2>
                    </div>
                    <div className="dashboard-list-group">
                        <table className="table">
                            <tbody>
                                <tr>
                                    <td>Candidates added to this opening in the last 8 weeks</td>
                                </tr>
                            </tbody>
                        </table>
                        <div className="" style={{ minHeight: "300px", display: "table", width: "100%", textAlign: "center" }}>
                            <p className="text-muted" style={{ display: "table-cell", verticalAlign: "middle" }}>Recent Candidates Report Chart Empty</p>
                        </div>
                    </div>
                </section>
            </div>
        )
    }
}
export default SingleOpeningMain