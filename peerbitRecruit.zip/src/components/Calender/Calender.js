import React, { Component } from 'react'

class Calender extends Component {
    render() {
        return (
            <div>
                Calender Page
            </div>
        )
    }
}

export default Calender