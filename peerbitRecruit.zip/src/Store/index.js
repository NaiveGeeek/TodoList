import dashboardStore from "../reducers/Dashboard/dashboardReducer";
import { combineReducers,applyMiddleware,createStore } from "redux";
import thunk from "redux-thunk";
import modalState from "../reducers/Modal/ModalReducer";
import loginState from "../reducers/Login/loginreducer";

const reducers = combineReducers({dashboardStore,modalState,loginState});
const store = createStore(reducers,applyMiddleware(thunk));
export default store;