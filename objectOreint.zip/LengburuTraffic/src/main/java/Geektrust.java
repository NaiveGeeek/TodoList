import Orbit.OrbitTypes;
import Result.Result;
import Vehicle.Vehicle;
import Weather.Weather;
import Weather.WeatherFactory;

import java.util.ArrayList;

public class Geektrust {
    public static void main(String [] args){
        OrbitTypes[] orbit = {OrbitTypes.ORBIT1,OrbitTypes.ORBIT2};
        int []trafficSpeed = {25,2};
        Weather weather = WeatherFactory.getWeather("RAINY");
        ArrayList<Result> results = new ArrayList<>();
        ArrayList<Vehicle> vehicles = weather.getUsableVehicleList();
        for(Vehicle vl :vehicles){
            results.add(vl.calculateMinTimeTakenToTravel(orbit,trafficSpeed,weather));
        }
        Result rl = Result.getCalculatedResult(results);
        System.out.println( rl.getVehicleName()+ " " + rl.getOrbitName());
    }
}
