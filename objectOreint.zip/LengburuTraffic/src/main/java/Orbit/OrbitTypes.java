package Orbit;

public enum OrbitTypes {
    ORBIT1(18,20),
    ORBIT2(20,10);
    private int orbitLength;
    private int craters;
    OrbitTypes(int orbitLength, int craters) {
        this.orbitLength =orbitLength;
        this.craters = craters;
    }
    public  int getOrbitLength(){
        return  this.orbitLength;
    }
    public int getCraters(){
        return this.craters;
    }
}
