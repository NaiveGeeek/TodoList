package Weather;

public enum WeatherTypes {

    SUNNY,WINDY,RAINY;
//    SUNNY(-0.1f),WINDY(0.0f),RAINY(+0.2f);
//    private float changeInCraters;
//    WeatherTypes(float changeInCraters) {
//        this.changeInCraters =changeInCraters;
//    }
//
//    public float getChangeInCraters() {
//        return changeInCraters;
//    }
}
