package Vehicle;

import Weather.WeatherTypes;

import java.util.ArrayList;

public class VehicleFactory {
    public static ArrayList<Vehicle> getVehicleObject(String name){
        ArrayList<Vehicle> vehicles = new ArrayList<>();
        if(name.equals(WeatherTypes.SUNNY.name())){
            vehicles.add(new Bike());
            vehicles.add(new Tuktuk());
            vehicles.add(new Car());

        }else if(name.equals(WeatherTypes.RAINY.name())){
            vehicles.add(new Tuktuk());
            vehicles.add(new Car());
        }else {
            vehicles.add(new Bike());
            vehicles.add(new Car());
        }
   return vehicles;
    }
}
