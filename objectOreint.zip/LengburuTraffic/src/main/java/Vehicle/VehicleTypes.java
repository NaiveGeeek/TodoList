package Vehicle;

public enum VehicleTypes {
    BIKE(10,2),
    TUKTUK(12,1),
    CAR(20,3);

    private int maxSpeed;
    private int timeToCrossSingleCrater;
    VehicleTypes(int maxSpeed, int timeToCrossSingleCrater){
        this.maxSpeed = maxSpeed;
        this.timeToCrossSingleCrater = timeToCrossSingleCrater;

    }

    public int getMaxSpeed() {
        return maxSpeed;
    }
    public int getTimeToCrossSingleCrater(){
        return timeToCrossSingleCrater;
    }
}
