package Vehicle;

import Orbit.OrbitTypes;
import Result.Result;
import Weather.Weather;

public class Car implements Vehicle {
    VehicleTypes vehicleType = VehicleTypes.CAR;
    @Override
    public Result calculateMinTimeTakenToTravel(OrbitTypes[] orbit, int[] trafficSpeed, Weather weather) {
        Result result = new Result(orbit[0].name(),this.vehicleType.name(),Float.MAX_VALUE);
        for(int i = 0;i<orbit.length;i++){
            float time = calculateTimeToTravelOnIndividualOrbit(orbit[i],trafficSpeed[i],weather);
            if(time<result.getTime()){
                result.setOrbitName(orbit[i].name());
                result.setTime(time);
            }
        }

        return result;
    }

    @Override
    public float calculateTimeToTravelOnIndividualOrbit(OrbitTypes orbit, int trafficSpeed, Weather weather) {
        int craters = orbit.getCraters();
        craters = weather.getCratersValue(craters);
        int vehicleSpeed = Math.min(this.vehicleType.getMaxSpeed(), trafficSpeed);
        float time = craters*this.vehicleType.getTimeToCrossSingleCrater() + ((orbit.getOrbitLength()*60)/vehicleSpeed);

        return time;
    }
}
