package Vehicle;
import Orbit.OrbitTypes;
import Result.Result;
import Weather.Weather;

public interface Vehicle {
  Result calculateMinTimeTakenToTravel(OrbitTypes[] orbit, int[] trafficSpeed, Weather weather);
  float calculateTimeToTravelOnIndividualOrbit(OrbitTypes orbit, int trafficSpeed,Weather weather);
}
